package com.example.servercraft.ViewModels.ServicioWeb;

import android.util.Log;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.ServicioWeb;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.JSONArray;
import org.json.JSONException;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class FormularioServicioWebViewModel extends ViewModel {
    private MutableLiveData<ArrayList<ServicioWeb>> mServicioWeb;

    // Constructor
    public FormularioServicioWebViewModel() {
        mServicioWeb = new MutableLiveData<>();

        loadHTTPServicioWebList();
    }

    // Getters
    public MutableLiveData<ArrayList<ServicioWeb>> getServicioWebList() {
        return mServicioWeb;
    }

    // Setters
    private void loadHTTPServicioWebList() {
        ServicioWeb servicioWeb = new ServicioWeb();

        servicioWeb.listar(10,1,null,null, response -> {
            try {
                JSONArray httpServicioWeb = response.getJSONArray("servicios");

                ArrayList<ServicioWeb> objectServicioWeb = mapServicioWebIntoObject(httpServicioWeb);

                mServicioWeb.setValue(objectServicioWeb);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<ServicioWeb> mapServicioWebIntoObject(JSONArray httpServicio) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type ServicioWebArray = new TypeToken<ArrayList<ServicioWeb>>() {
        }.getType();
        ArrayList<ServicioWeb> servicioWebList = gson.fromJson(httpServicio.toString(), ServicioWebArray);

        return servicioWebList;
    }
}
