package com.example.servercraft.UI.ServidoresRacksSalas.Servidores;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import com.chivorn.smartmaterialspinner.SmartMaterialSpinner;
import com.example.servercraft.Models.BaseDatos;
import com.example.servercraft.Models.Rack;
import com.example.servercraft.Models.Servidor;
import com.example.servercraft.Models.SistemaOperativo;
import com.example.servercraft.Models.TipoServidor;
import com.example.servercraft.Utils.AdapterMaterialSpinner;
import com.example.servercraft.ViewModels.ServidoresRacksSalas.Servidores.DetalleServidor.DetalleServidorViewModel;
import com.example.servercraft.ViewModels.ServidoresRacksSalas.Servidores.DetalleServidor.DetalleServidorViewModelFactory;
import com.example.servercraft.ViewModels.ServidoresRacksSalas.Servidores.FormularioServidorViewModel;
import com.example.servercraft.databinding.FragmentFormularioServidorBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.Email;
import com.mobsandgeeks.saripaar.annotation.Length;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class FormularioServidorFragment extends BottomSheetDialogFragment implements Validator.ValidationListener {
    // Configuración de View Model
    private static final String ARG_ID_SERVIDOR = "id_servidor";
    private DetalleServidorViewModel detalleViewModel;
    private FormularioServidorViewModel formularioViewModel;
    private FragmentFormularioServidorBinding binding;
    private View root;
    private Validator validator;

    // Validaciones
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etServidorNombre;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etServidorIp;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etServidorAlmacenamiento;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etServidorMemoria;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etServidorUsuario;

    @NonNull
    @Length(min = 6)
    @NotEmpty(message = "Campo obligatorio")
    EditText etServidorContrasena;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etServidorNombreCompleto;

    @NonNull
    @Email
    @NotEmpty(message = "Campo obligatorio")
    EditText etServidorEmail;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etServidorTelefomono;

    // Spinners
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    SmartMaterialSpinner<TipoServidor> spTipo;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    SmartMaterialSpinner<BaseDatos> spBaseDatos;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    SmartMaterialSpinner<SistemaOperativo> spSistemaOperativo;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    SmartMaterialSpinner<Rack> spRack;

    public static FormularioServidorFragment newInstance(@Nullable Integer idServidor) {
        FormularioServidorFragment fragment = new FormularioServidorFragment();

        if (idServidor != null) {
            Bundle bundle = new Bundle();

            bundle.putInt(ARG_ID_SERVIDOR, idServidor);
            fragment.setArguments(bundle);
        }

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            Integer serverId = getArguments().getInt(ARG_ID_SERVIDOR);

            detalleViewModel = new ViewModelProvider(this, new DetalleServidorViewModelFactory(serverId)).get(DetalleServidorViewModel.class);
        }

        formularioViewModel = new ViewModelProvider(this).get(FormularioServidorViewModel.class);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentFormularioServidorBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.registerAdapter(SmartMaterialSpinner.class, new AdapterMaterialSpinner());
        validator.setValidationListener(this);

        // Intanciamiento de los campos a validar
        etServidorNombre = binding.etNombre;
        etServidorIp = binding.etIp;
        etServidorAlmacenamiento = binding.etDisco;
        etServidorMemoria = binding.etMemoria;
        etServidorNombreCompleto = binding.etNombreMantencion;
        etServidorEmail = binding.etEmailMantencion;
        etServidorTelefomono= binding.etTelefonoMantencion;
        etServidorContrasena=binding.etContrasenaAcceso;
        etServidorUsuario=binding.etUsuarioAcceso;

    // Loading Status
        binding.clLoadingRackForm.setVisibility(View.VISIBLE);
        binding.llServerForm.setVisibility(View.GONE);

        // Referenciación de Spinners
        spTipo = binding.spTipo;
        spBaseDatos = binding.spBaseDatos;
        spSistemaOperativo = binding.spSistemaOperativo;
        spRack = binding.spRack;

        // Inicialización de spinners con API.
        formularioViewModel.getTipoServidorList().observe(getViewLifecycleOwner(), tiposServidor -> {
            spTipo.setItem(tiposServidor);

            spTipo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (tiposServidor.get(position).id == 2 || tiposServidor.get(position).id == 3) {
                        binding.lControlBaseDatos.setVisibility(View.VISIBLE);
                    } else {
                        spBaseDatos.clearSelection();
                        binding.lControlBaseDatos.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        });

        formularioViewModel.getBaseDatosList().observe(getViewLifecycleOwner(), baseDatos -> {
            spBaseDatos.setItem(baseDatos);
        });

        formularioViewModel.getSistemaOperativoList().observe(getViewLifecycleOwner(), sistemasOperativos -> {
            spSistemaOperativo.setItem(sistemasOperativos);
        });

        formularioViewModel.getRackList().observe(getViewLifecycleOwner(), racks -> {
            spRack.setItem(racks);

            spRack.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    // Rack seleccionado
                    Rack selectedRack = racks.get(position);

                    // Seteo de valores
                    binding.tvSala.setText(selectedRack.sala.nombre);
                    binding.tvRegion.setText(selectedRack.sala.region.nombre);
                    binding.tvPais.setText(selectedRack.sala.region.pais.nombre);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });
        });

        // Limpieza de errores al seleccionar
        spBaseDatos.setOnItemSelectedListener(AdapterMaterialSpinner.clearSpinner(spBaseDatos));
        spRack.setOnItemSelectedListener(AdapterMaterialSpinner.clearSpinner(spRack));
        spTipo.setOnItemSelectedListener(AdapterMaterialSpinner.clearSpinner(spTipo));
        spSistemaOperativo.setOnItemSelectedListener(AdapterMaterialSpinner.clearSpinner(spSistemaOperativo));

        // Configuración de botón de creación
        binding.btnCrearServidor.setOnClickListener(v -> {
            validator.validate();

        });

        // Modificar título en caso de que se esté intentando editar un servidor
        if (detalleViewModel != null && detalleViewModel.hasServer()) {
            binding.tvServerFormTitle.setText("Editar servidor");
            binding.btnCrearServidor.setText("Actualizar servidor");
        }

        return root;
    }

    private void updateServerList() {
        getActivity().finish();
        getActivity().overridePendingTransition(0, 0);
        getActivity().startActivity(getActivity().getIntent());
        getActivity().overridePendingTransition(0, 0);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Solo cargar datos cuando el formulario sea de edición.
        if (detalleViewModel != null && detalleViewModel.hasServer()) {
            detalleViewModel.getServer().observe(getViewLifecycleOwner(), servidor -> {
                // 1 - Información General
                binding.etNombre.setText(servidor.nombre);
                binding.etIp.setText(servidor.ip);


                formularioViewModel.getTipoServidorList().observe(getViewLifecycleOwner(), tiposServidor -> {
                    spTipo.setSelection(tiposServidor.indexOf(servidor.tipoServidor));
                });

                if (servidor.baseDatos != null) {
                    formularioViewModel.getBaseDatosList().observe(getViewLifecycleOwner(), basesDatos -> {
                        if (servidor.tipoServidor.id == 2 || servidor.tipoServidor.id == 3) {
                            binding.lControlBaseDatos.setVisibility(View.VISIBLE);
                            spBaseDatos.setSelection(basesDatos.indexOf(servidor.baseDatos));
                        } else {
                            binding.lControlBaseDatos.setVisibility(View.GONE);
                        }
                    });
                }

                formularioViewModel.getSistemaOperativoList().observe(getViewLifecycleOwner(), sistemasOperativos -> {
                    spSistemaOperativo.setSelection(sistemasOperativos.indexOf(servidor.sistemaOperativo));
                });

                binding.etDisco.setText(String.valueOf(servidor.disco));
                binding.etMemoria.setText(String.valueOf(servidor.memoria));

                // 2 - Ubicación Física
                formularioViewModel.getRackList().observe(getViewLifecycleOwner(), racks -> {
                    spRack.setSelection(racks.indexOf(servidor.rack));
                });

                // 3 - Credenciales Acceso
                binding.etUsuarioAcceso.setText(servidor.usuarioIngreso);

                binding.etContrasenaAcceso.setText(servidor.contrasenaIngreso);

                // 4 - Contacto Mantención
                binding.etNombreMantencion.setText(servidor.nombreContactoMantencion);
                binding.etEmailMantencion.setText(servidor.emailContactoMantencion);
                binding.etTelefonoMantencion.setText(servidor.telefonoContactoMantencion);
                binding.sGarantiaMantencion.setChecked(servidor.poseeGarantia);

                binding.clLoadingRackForm.setVisibility(View.GONE);
                binding.llServerForm.setVisibility(View.VISIBLE);
            });
        } else {
            binding.clLoadingRackForm.setVisibility(View.GONE);
            binding.llServerForm.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onValidationSucceeded() {
        // Se muestra animación de cargando
        binding.clLoadingRackForm.setVisibility(View.VISIBLE);
        binding.llServerForm.setVisibility(View.GONE);
        binding.tvLoadingServer.setText("Guardando datos");

        // Manejo de datos
        Gson gson = new Gson();
        Servidor servidor = new Servidor();

        servidor.nombre = binding.etNombre.getText().toString();
        servidor.ip = binding.etIp.getText().toString();
        servidor.disco = Integer.parseInt(binding.etDisco.getText().toString());
        servidor.memoria = Integer.parseInt(binding.etMemoria.getText().toString());
        servidor.idTipoServidor = spTipo.getSelectedItem().id;

        if (spTipo.getSelectedItem().id == 2 || spTipo.getSelectedItem().id == 3) {
            servidor.idBaseDatos = spTipo.getSelectedItem().id;
        } else {
            servidor.idBaseDatos = null;
        }

        servidor.idSistemaOperativo = spSistemaOperativo.getSelectedItem().id;
        servidor.idRack = spRack.getSelectedItem().id;
        servidor.usuarioIngreso = binding.etUsuarioAcceso.getText().toString();
        servidor.contrasenaIngreso = binding.etContrasenaAcceso.getText().toString();
        servidor.nombreContactoMantencion = binding.etNombreMantencion.getText().toString();
        servidor.emailContactoMantencion = binding.etEmailMantencion.getText().toString();
        servidor.telefonoContactoMantencion = binding.etTelefonoMantencion.getText().toString();
        servidor.poseeGarantia = binding.sGarantiaMantencion.isChecked();

        JSONObject request = new JSONObject();

        try {
            request.put("servidor", new JSONObject(gson.toJson(servidor)));
        } catch (JSONException ignored) {
        }

        if (detalleViewModel != null && detalleViewModel.hasServer()) {
            servidor.actualizar(detalleViewModel.getServerId(), request, response -> {
                binding.clLoadingRackForm.setVisibility(View.GONE);
                binding.llServerForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateServerList();
            }, error -> {
                binding.clLoadingRackForm.setVisibility(View.GONE);
                binding.llServerForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al actualizar servidor", Toast.LENGTH_SHORT).show();
            });
        } else {
            servidor.crear(request, response -> {
                binding.clLoadingRackForm.setVisibility(View.GONE);
                binding.llServerForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateServerList();
            }, error -> {
                binding.clLoadingRackForm.setVisibility(View.GONE);
                binding.llServerForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al crear servidor", Toast.LENGTH_SHORT).show();
            });
        }

    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        AdapterMaterialSpinner.onErrorChanges(errors);

    }
}