package com.example.servercraft.ViewModels.UsuariosEquipos.EquiposTrabajo.FormularioEquipoTrabajo;

import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import com.example.servercraft.Models.EquipoTrabajo;

public class FormularioEquipoTrabajoViewModelFactory implements ViewModelProvider.Factory {
    private EquipoTrabajo mEquipoTrabajo;

    public FormularioEquipoTrabajoViewModelFactory(@Nullable EquipoTrabajo equipoTrabajo) {
        if (equipoTrabajo != null) {
            this.mEquipoTrabajo = equipoTrabajo;
        }
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        return (T) new FormularioEquipoTrabajoViewModel(mEquipoTrabajo);
    }
}
