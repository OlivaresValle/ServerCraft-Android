package com.example.servercraft.UI.Ubicacion.Paises;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.renderscript.ScriptGroup;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.example.servercraft.R;
import com.example.servercraft.UI.LenguajesProgramacion.LenguajeItemAdapter;
import com.example.servercraft.ViewModels.Ubicacion.Pais.ListarPaisViewModel;
import com.example.servercraft.databinding.FragmentListarPaisesBinding;


public class ListarPaisesFragment extends Fragment {
    public ListarPaisViewModel listarViewModel;
    private FragmentListarPaisesBinding binding;
    private PaisItemAdapter paisItemAdapter;

    public static ListarPaisesFragment newInstance() {
        ListarPaisesFragment fragment = new ListarPaisesFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        listarViewModel = new ViewModelProvider(this).get(ListarPaisViewModel.class);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        Activity parent = getActivity();
        binding = FragmentListarPaisesBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Elements
        ProgressBar spinner = parent.findViewById(R.id.pbHttpUbicacionLoading);


        // Configuración inicial de elementos
        spinner.setVisibility(View.VISIBLE);
        binding.rvPaises.setLayoutManager(new LinearLayoutManager(root.getContext()));
        binding.pbHttpLoadingPais.setVisibility(View.INVISIBLE);


        // Observador de consulta HTTP
        listarViewModel.getPaisList().observe(getViewLifecycleOwner(), pais -> {
            if (paisItemAdapter == null) {
                paisItemAdapter = new PaisItemAdapter(root.getContext(), pais, getChildFragmentManager());

                binding.rvPaises.setAdapter(paisItemAdapter);
                binding.rvPaises.setAdapter(paisItemAdapter);
                spinner.setVisibility(View.INVISIBLE);
                binding.pbHttpLoadingPais.setVisibility(View.INVISIBLE);
            } else {
                binding.rvPaises.post(new Runnable() {
                    public void run() {
                        paisItemAdapter.notifyItemRangeChanged(0,pais.size() - 1);
                    }
                });
            }
        });

        binding.btnBuscarPais.setOnClickListener(v -> {
            Log.d("Boton", "apretado");
            binding.pbHttpLoadingPais.setVisibility(View.VISIBLE);
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etBuscarPais.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arPais.clear();
            listarViewModel.loadHTTPPaisList();
            paisItemAdapter = null;
        });


        binding.rvPaises.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                if (!listarViewModel.cargandoDatos) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == listarViewModel.arPais.size() - 1) {
                        listarViewModel.cargandoDatos = true;
                        listarViewModel.loadHTTPPaisList();
                    }
                }
            }
        });
        return  root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}