package com.example.servercraft.UI.ClientesProveedores.EquipoProveedor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.servercraft.Models.EquipoProveedor;
import com.example.servercraft.R;
import com.example.servercraft.Utils.UserInfo;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class EquipoProveedorItemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    LayoutInflater inflater;
    ArrayList<EquipoProveedor> model;
    FragmentManager fragmentManager;
    Context context;

    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;


    public EquipoProveedorItemAdapter(Context context, ArrayList<EquipoProveedor> model, FragmentManager fm) {
        this.inflater = LayoutInflater.from(context);
        this.model = model;
        this.fragmentManager = fm;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        if (viewType == VIEW_TYPE_ITEM) {
            View view = inflater.inflate(R.layout.item_list_general, parent, false);

            return new EquipoProveedorItemAdapter.ItemViewHolder(view);
        } else {
            View view = inflater.inflate(R.layout.item_list_loading, parent, false);

            return new EquipoProveedorItemAdapter.LoadingViewHolder(view);
        }
    }


    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof EquipoProveedorItemAdapter.ItemViewHolder) {
            populateItemRows((EquipoProveedorItemAdapter.ItemViewHolder) holder, position);
        } else if (holder instanceof EquipoProveedorItemAdapter.LoadingViewHolder) {
            showLoadingView((EquipoProveedorItemAdapter.LoadingViewHolder) holder, position);
        }
    }


    @Override
    public int getItemCount() {
        return model == null ? 0 : model.size();
    }

    @Override
    public int getItemViewType(int position) {
        return model.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }


    public class ItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ConstraintLayout clItemData, clItemActions;
        TextView nombre, tipo;
        Button btnView, btnEdit, btnDelete;

        int userRol = new UserInfo().getUserRol();

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);

            nombre = itemView.findViewById(R.id.tvItemTitle);
            tipo = itemView.findViewById(R.id.tvItemDescription);
            clItemData = itemView.findViewById(R.id.clItemData);
            clItemActions = itemView.findViewById(R.id.clItemActions);
            btnView = itemView.findViewById(R.id.btnView);
            btnEdit = itemView.findViewById(R.id.btnUpdate);
            btnDelete = itemView.findViewById(R.id.btnDelete);

            if (userRol == 2 || userRol == 3) {
                btnDelete.setVisibility(View.GONE);
            }

            if (userRol == 3) {
                btnEdit.setVisibility(View.GONE);
            }

            clItemData.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int adapterPosition = getAbsoluteAdapterPosition();
            EquipoProveedor equipoProveedor = model.get(adapterPosition);
            equipoProveedor.isFullyVisible = !equipoProveedor.isFullyVisible;

            notifyItemChanged(adapterPosition);
        }
    }


    private class LoadingViewHolder extends RecyclerView.ViewHolder {

        public LoadingViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    private void showLoadingView(EquipoProveedorItemAdapter.LoadingViewHolder viewHolder, int position) {
        //ProgressBar would be displayed

    }
    private void populateItemRows(EquipoProveedorItemAdapter.ItemViewHolder holder, int position) {
        // Obtención de objeto
        EquipoProveedor equipoProveedor = model.get(position);

        // Seteo de valores en view holder
        holder.nombre.setText(equipoProveedor.nombre);
        holder.tipo.setText(equipoProveedor.proveedorSistema.nombre);
        holder.clItemActions.setVisibility(equipoProveedor.isFullyVisible ? View.VISIBLE : View.GONE);

        // Click listeners
        holder.btnView.setOnClickListener(v -> {
            DetalleEquipoProveedorFragment detalleEquipoProveedor = DetalleEquipoProveedorFragment.newInstance(equipoProveedor.id);
            detalleEquipoProveedor.show(fragmentManager, detalleEquipoProveedor.getTag());
        });

        holder.btnEdit.setOnClickListener(v -> {
            FormularioEquipoProveedorFragment formEquipo = FormularioEquipoProveedorFragment.newInstance(equipoProveedor.id);
            formEquipo.show(fragmentManager, formEquipo.getTag());
        });

        holder.btnDelete.setOnClickListener(v -> {
            AlertDialog.Builder confirmation = new AlertDialog.Builder(context);
            confirmation.setTitle("Advertencia")
                    .setMessage("¿Estás seguro de qué deseas eliminar el equipo del proveedor: \""+equipoProveedor.nombre+"\"?")
                    .setCancelable(false)
                    .setPositiveButton("Eliminar", (dialog, which) -> {
                        equipoProveedor.eliminar(equipoProveedor.id, response -> {
                            ((Activity) context).finish();
                            ((Activity) context).overridePendingTransition(0, 0);
                            ((Activity) context).startActivity(((Activity) context).getIntent());
                            ((Activity) context).overridePendingTransition(0, 0);
                        }, error -> {
                            Toast.makeText(context, "Error al eliminar equipo de proveedor.", Toast.LENGTH_SHORT).show();
                        });
                    }).setNegativeButton("Cancelar", (dialog, which) -> {
                dialog.dismiss();
            });

            confirmation.create().show();
        });
}
}
