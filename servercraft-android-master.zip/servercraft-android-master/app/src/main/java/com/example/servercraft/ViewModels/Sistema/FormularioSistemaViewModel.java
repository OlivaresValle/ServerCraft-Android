package com.example.servercraft.ViewModels.Sistema;

import android.util.Log;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.EquipoProveedor;
import com.example.servercraft.Models.NivelSeguridad;
import com.example.servercraft.Models.NivelSensibilidad;
import com.example.servercraft.Models.Servidor;
import com.example.servercraft.Models.TipoServidor;
import com.example.servercraft.Models.Usuario;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class FormularioSistemaViewModel extends ViewModel {
    private MutableLiveData<ArrayList<Servidor>> mServidor;
    private MutableLiveData<ArrayList<EquipoProveedor>> mEquipoProveedor;
    private MutableLiveData<ArrayList<NivelSeguridad>> mNivelSeguridad;
    private MutableLiveData<ArrayList<NivelSensibilidad>> mNivelSensibilidad;
    private MutableLiveData<ArrayList<Usuario>> mUsuario;

    // Constructor
    public FormularioSistemaViewModel() {
        mServidor = new MutableLiveData<>();
        mEquipoProveedor = new MutableLiveData<>();
        mNivelSeguridad = new MutableLiveData<>();
        mNivelSensibilidad = new MutableLiveData<>();
        mUsuario = new MutableLiveData<>();

        loadHTTPServidorBDList();
        loadHTTPEquipoProveedorList();
        loadHTTPNivelSeguridadList();
        loadHTTPNivelSensibilidadList();
        loadHTTPUsuarioList();
    }

    // Getters
    public MutableLiveData<ArrayList<Servidor>> getServidorBDList() {
        return mServidor;
    }

    public MutableLiveData<ArrayList<EquipoProveedor>> getEquipoProveedorList() {
        ArrayList<EquipoProveedor> test = mEquipoProveedor.getValue();
        return mEquipoProveedor;
    }

    public MutableLiveData<ArrayList<NivelSeguridad>> getNivelSeguridadList() {
        return mNivelSeguridad;
    }

    public MutableLiveData<ArrayList<NivelSensibilidad>> getNivelSensibilidadList() {
        return mNivelSensibilidad;
    }

    public MutableLiveData<ArrayList<Usuario>> getUsuarioList() {
        return mUsuario;
    }

    // Setters

    // 1 - Servidores Base de Datos
    private void loadHTTPServidorBDList() {
        TipoServidor tipo = new TipoServidor();
        Servidor servidor = new Servidor();
        JSONObject request = new JSONObject();

        try {
            request.put("tipo", 2);
        } catch (Exception e) {

        }

        servidor.listar(1000, 1, null, request, response -> {
            try {
                JSONArray httpServidor = response.getJSONArray("servidores");

                ArrayList<Servidor> objectServidor = mapServidorIntoObject(httpServidor);

                mServidor.setValue(objectServidor);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<Servidor> mapServidorIntoObject(JSONArray httpServidor) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type ServidorArray = new TypeToken<ArrayList<Servidor>>() {
        }.getType();
        ArrayList<Servidor> servidorList = gson.fromJson(httpServidor.toString(), ServidorArray);

        return servidorList;
    }

    // 2 - Equipo del Proveedor
    private void loadHTTPEquipoProveedorList() {
        EquipoProveedor equipoProveedor = new EquipoProveedor();

        equipoProveedor.listar(1000,1, null, null, response -> {
            try {
                JSONArray httpEquipoProveedor = response.getJSONArray("equipos_encargados");

                ArrayList<EquipoProveedor> objectEquipoProveedorList = mapEquipoProveedorIntoObject(httpEquipoProveedor);

                mEquipoProveedor.setValue(objectEquipoProveedorList);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<EquipoProveedor> mapEquipoProveedorIntoObject(JSONArray httpEquipoProveedor) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type EquipoProveedorArray = new TypeToken<ArrayList<EquipoProveedor>>() {
        }.getType();
        ArrayList<EquipoProveedor> equipoProveedorList = gson.fromJson(httpEquipoProveedor.toString(), EquipoProveedorArray);

        return equipoProveedorList;
    }

    // 3 - Nivel de Seguridad
    private void loadHTTPNivelSeguridadList() {
        NivelSeguridad nivelSeguridad = new NivelSeguridad();

        nivelSeguridad.listar(null, response -> {
            try {
                JSONArray httpNivelSeguridad = response.getJSONArray("niveles_seguridad");

                ArrayList<NivelSeguridad> objectNivelSeguridadList = mapNivelSeguridadIntoObject(httpNivelSeguridad);

                mNivelSeguridad.setValue(objectNivelSeguridadList);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<NivelSeguridad> mapNivelSeguridadIntoObject(JSONArray httpNivelSeguridad) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type NivelSeguridadArray = new TypeToken<ArrayList<NivelSeguridad>>() {
        }.getType();
        ArrayList<NivelSeguridad> nivelSeguridadList = gson.fromJson(httpNivelSeguridad.toString(), NivelSeguridadArray);

        return nivelSeguridadList;
    }

    // 4 - Nivel de Sensibilidad
    private void loadHTTPNivelSensibilidadList() {
        NivelSensibilidad nivelSensibilidad = new NivelSensibilidad();

        nivelSensibilidad.listar(null, response -> {
            try {
                JSONArray httpNivelSensibilidad = response.getJSONArray("niveles_sensibilidad");

                ArrayList<NivelSensibilidad> objectNivelSensibilidad = mapNivelSensibilidadIntoObject(httpNivelSensibilidad);

                mNivelSensibilidad.setValue(objectNivelSensibilidad);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<NivelSensibilidad> mapNivelSensibilidadIntoObject(JSONArray httpNivelSensibilidad) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type NivelSensibilidadArray = new TypeToken<ArrayList<NivelSensibilidad>>() {
        }.getType();
        ArrayList<NivelSensibilidad> nivelSensibilidadList = gson.fromJson(httpNivelSensibilidad.toString(), NivelSensibilidadArray);

        return nivelSensibilidadList;
    }

    // 5 - Racks
    private void loadHTTPUsuarioList() {
        Usuario usuario = new Usuario();

        usuario.listar(1000,1, null, null, response -> {
            try {
                JSONArray httpUsuario = response.getJSONArray("usuarios");

                ArrayList<Usuario> objectUsuario = mapUsuarioIntoObject(httpUsuario);

                mUsuario.setValue(objectUsuario);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<Usuario> mapUsuarioIntoObject(JSONArray httpUsuario) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type UsuarioArray = new TypeToken<ArrayList<Usuario>>() {
        }.getType();
        ArrayList<Usuario> usuarioList = gson.fromJson(httpUsuario.toString(), UsuarioArray);

        return usuarioList;
    }
}
