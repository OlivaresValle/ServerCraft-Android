package com.example.servercraft.UI.Incidentes.Incidentes;

import android.graphics.Typeface;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.example.servercraft.R;
import com.example.servercraft.ViewModels.Incidentes.Incidentes.DetalleIncidente.DetalleIncidenteViewModel;
import com.example.servercraft.ViewModels.Incidentes.Incidentes.DetalleIncidente.DetalleIncidenteViewModelFactory;
import com.example.servercraft.databinding.FragmentDetalleIncidenteBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class DetalleIncidenteFragment extends BottomSheetDialogFragment {
    private static final String ARG_ID_INCIDENTE = "id_incidente";
    private DetalleIncidenteViewModel detalleViewModel;
    private FragmentDetalleIncidenteBinding binding;

    public static DetalleIncidenteFragment newInstance(int idIncidente) {
        DetalleIncidenteFragment fragment = new DetalleIncidenteFragment();
        Bundle bundle = new Bundle();

        bundle.putInt(ARG_ID_INCIDENTE, idIncidente);
        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int incidenteId = 1;

        if (getArguments() != null) {
            incidenteId = getArguments().getInt(ARG_ID_INCIDENTE);
        }

        detalleViewModel = new ViewModelProvider(this, new DetalleIncidenteViewModelFactory(incidenteId)).get(DetalleIncidenteViewModel.class);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentDetalleIncidenteBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Observador de consulta HTTP
        detalleViewModel.getIncidente().observe(getViewLifecycleOwner(), incidente -> {
            // Cargar datos cuando estén disponibles
            // 1 - Información general
            binding.tvIncidenteTitle.setText(incidente.instanciaSistema.sistema.nombre);
            binding.tvEstadoIncidente.setText(incidente.estadoIncidente.nombre);
            binding.tvTipoInstancia.setText(incidente.instanciaSistema.tipoInstancia.nombre);
            binding.tvServidorIncidente.setText(incidente.instanciaSistema.servidor.nombre);
            binding.tvEncargadoIncidenteSistema.setText(incidente.instanciaSistema.sistema.usuario.nombre);

            binding.tvEstadoIncidente.setTypeface(null, Typeface.BOLD);
            switch (incidente.estadoIncidente.nombre) {
                case "Sin acciones":
                    binding.tvEstadoIncidente.setTextColor(getResources().getColor(R.color.danger_400));
                    break;

                case "En revisión":
                    binding.tvEstadoIncidente.setTextColor(getResources().getColor(R.color.warning_400));
                    break;

                case "Corregido":
                    binding.tvEstadoIncidente.setTextColor(getResources().getColor(R.color.success_500));
                    break;
            }

            // 2 - Información Problema
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yy HH:mm:ss");
            String timestamp = ZonedDateTime.parse(incidente.fechaHoraProblema).format(formatter);

            binding.tvFechaHoraIncidente.setText(timestamp);
            binding.tvTipoIncidente.setText(incidente.tipoProblema.nombre);
            binding.tvDetalleProblema.setText(incidente.detalleProblema);

            // 3 - Información Solución
            String timeStampSolucion = null;

            if (incidente.fechaHoraSolucion != null) {
                timeStampSolucion = ZonedDateTime.parse(incidente.fechaHoraSolucion).format(formatter);
            }

            binding.tvFechaHoraSolucion.setText(timeStampSolucion != null ? timeStampSolucion : "Solución pendiente");
            binding.tvTipoSolucion.setText(incidente.tipoSolucion != null ? incidente.tipoSolucion.nombre : "Solución pendiente");
            binding.tvDetalleSolucion.setText(incidente.detalleSolucion != null ? incidente.detalleSolucion : "Solución pendiente");

            // Ocultar vista de "cargando..."
            binding.clLoadingIncidente.setVisibility(View.GONE);
            binding.lIncidenteDetalle.setVisibility(View.VISIBLE);
        });

        return root;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}