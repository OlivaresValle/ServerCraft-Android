package com.example.servercraft.UI.ClientesProveedores.Proveedores;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import com.example.servercraft.R;
import com.example.servercraft.UI.LenguajesProgramacion.LenguajeItemAdapter;
import com.example.servercraft.ViewModels.ClientesProveedores.Proveedores.ListarProveedoresViewModel;
import com.example.servercraft.databinding.ActivityClientesProveedoresBinding;
import com.example.servercraft.databinding.FragmentListarProveedoresBinding;

public class ListarProveedoresFragment extends Fragment {
    public ListarProveedoresViewModel listarViewModel;
    private FragmentListarProveedoresBinding binding;
    private ActivityClientesProveedoresBinding bindingProoveedor;
    public ProveedorItemAdapter proveedorAdapter;

    public static ListarProveedoresFragment newInstance() {
        return new ListarProveedoresFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        listarViewModel = new ViewModelProvider(this).get(ListarProveedoresViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        Activity parent = getActivity();
        binding = FragmentListarProveedoresBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Elements
        ProgressBar spinner = parent.findViewById(R.id.pbHttpProveedorLoading);


        // Configuración inicial de elementos

        spinner.setVisibility(View.VISIBLE);
        binding.pbHttpLoadingProveedor.setVisibility(View.INVISIBLE);
        binding.rvProveedores.setLayoutManager(new LinearLayoutManager(root.getContext()));

        // Observador de consulta HTTP
        listarViewModel.getProveedorList().observe(getViewLifecycleOwner(), proveedores -> {


            if (proveedorAdapter == null) {
                proveedorAdapter = new ProveedorItemAdapter( root.getContext(), proveedores, getChildFragmentManager());

                binding.rvProveedores.setAdapter(proveedorAdapter);
                spinner.setVisibility(View.INVISIBLE);
                binding.pbHttpLoadingProveedor.setVisibility(View.INVISIBLE);

            } else {
                binding.rvProveedores.post(new Runnable() {
                    public void run() {
                        proveedorAdapter.notifyItemRangeChanged(0,proveedores.size() - 1);
                    }
                });
            }
        });


        binding.rvProveedores.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                if (!listarViewModel.cargandoDatos) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == listarViewModel.arProveedor.size() - 1) {
                        listarViewModel.cargandoDatos = true;
                        listarViewModel.loadHTTPProveedorList();
                    }
                }
            }
        });

        binding.btnBuscarProveedor.setOnClickListener(v -> {
            binding.pbHttpLoadingProveedor.setVisibility(View.VISIBLE);
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etBuscarProveedor.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arProveedor.clear();
            listarViewModel.loadHTTPProveedorList();
            proveedorAdapter = null;
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}