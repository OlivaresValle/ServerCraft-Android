package com.example.servercraft.UI.Sistema;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.chivorn.smartmaterialspinner.SmartMaterialSpinner;
import com.example.servercraft.Models.EquipoProveedor;
import com.example.servercraft.Models.NivelSeguridad;
import com.example.servercraft.Models.NivelSensibilidad;
import com.example.servercraft.Models.Servidor;
import com.example.servercraft.Models.Sistema;
import com.example.servercraft.Models.Usuario;
import com.example.servercraft.Utils.AdapterMaterialSpinner;
import com.example.servercraft.ViewModels.Sistema.DetalleSistema.DetalleSistemaViewModel;
import com.example.servercraft.ViewModels.Sistema.DetalleSistema.DetalleSistemaViewModelFactory;
import com.example.servercraft.ViewModels.Sistema.FormularioSistemaViewModel;
import com.example.servercraft.databinding.FragmentFormularioSistemaBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;

import org.jetbrains.annotations.Nullable;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class FormularioSistemaFragment extends BottomSheetDialogFragment implements Validator.ValidationListener {
    // Configuración de View Model
    private static final String ARG_ID_SISTEMA = "id_sistema";
    private DetalleSistemaViewModel detalleViewModel;
    private FormularioSistemaViewModel formularioViewModel;
    private FragmentFormularioSistemaBinding binding;
    private View root;
    private Validator validator;

    // Validaciones
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etNombreCrearSistema;

    // Spinners
    @NonNull
    SmartMaterialSpinner<Servidor> spServidor;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    SmartMaterialSpinner<EquipoProveedor> spEquipoProveedor;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    SmartMaterialSpinner<NivelSeguridad> spNivelSeguridad;

    @NonNull
    SmartMaterialSpinner<NivelSensibilidad> spNivelSensibilidad;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    SmartMaterialSpinner<Usuario> spUsuario;

    public static FormularioSistemaFragment newInstance(@Nullable Integer idSistema) {
        FormularioSistemaFragment fragment = new FormularioSistemaFragment();

        if (idSistema != null) {
            Bundle bundle = new Bundle();

            bundle.putInt(ARG_ID_SISTEMA, idSistema);
            fragment.setArguments(bundle);
        }
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            Integer sistemaId = getArguments().getInt(ARG_ID_SISTEMA);

            detalleViewModel = new ViewModelProvider(this, new DetalleSistemaViewModelFactory(sistemaId)).get(DetalleSistemaViewModel.class);
        }

        formularioViewModel = new ViewModelProvider(this).get(FormularioSistemaViewModel.class);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentFormularioSistemaBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.registerAdapter(SmartMaterialSpinner.class, new AdapterMaterialSpinner());
        validator.setValidationListener(this);

        // Intanciamiento de los campos a validar
        etNombreCrearSistema = binding.etNombreCrearSistema;

        // Loading Status
        binding.clLoadingCrearSistemaForm.setVisibility(View.VISIBLE);
        binding.llSistemaFormCrearSistema.setVisibility(View.GONE);

        // Referenciación de elementos
        spEquipoProveedor = binding.spEquipoProveedorCrearSistema;
        spServidor = binding.spServidorCrearSistema;
        spNivelSeguridad = binding.spNivelSeguridadCrearSistema;
        spNivelSensibilidad = binding.spNivelSensibilidadCrearSistema;
        spUsuario = binding.spUsuarioCrearSistema;

        // Inicialización de spinners con API.
        formularioViewModel.getEquipoProveedorList().observe(getViewLifecycleOwner(), equipoProveedor -> {
            spEquipoProveedor.setItem(equipoProveedor);
        });

        formularioViewModel.getServidorBDList().observe(getViewLifecycleOwner(), servidor -> {
            spServidor.setItem(servidor);
        });

        formularioViewModel.getNivelSeguridadList().observe(getViewLifecycleOwner(), nivelSeguridad -> {
            spNivelSeguridad.setItem(nivelSeguridad);
        });

        formularioViewModel.getNivelSensibilidadList().observe(getViewLifecycleOwner(), nivelSensibilidad -> {
            spNivelSensibilidad.setItem(nivelSensibilidad);
        });

        formularioViewModel.getUsuarioList().observe(getViewLifecycleOwner(), usuario -> {
            spUsuario.setItem(usuario);
        });

        // Limpieza de errores al seleccionar
        spServidor.setOnItemSelectedListener(AdapterMaterialSpinner.clearSpinner(spServidor));
        spEquipoProveedor.setOnItemSelectedListener(AdapterMaterialSpinner.clearSpinner(spEquipoProveedor));
        spNivelSeguridad.setOnItemSelectedListener(AdapterMaterialSpinner.clearSpinner(spNivelSeguridad));
        spNivelSensibilidad.setOnItemSelectedListener(AdapterMaterialSpinner.clearSpinner(spNivelSensibilidad));
        spUsuario.setOnItemSelectedListener(AdapterMaterialSpinner.clearSpinner(spUsuario));

        // Configuración de botón de creación
        binding.btnSistemaCrear.setOnClickListener(v -> {

            validator.validate();
        });

        // Modificar título en caso de que se esté intentando editar un sistema
        if (detalleViewModel != null && detalleViewModel.hasSistema()) {
            binding.tvSistemaFormTitleCrearSistema.setText("Editar sistema");
            binding.btnSistemaCrear.setText("Actualizar sistema");
        }

        return root;
    }

    private void updateSistemaList() {
        getActivity().finish();
        getActivity().overridePendingTransition(0, 0);
        getActivity().startActivity(getActivity().getIntent());
        getActivity().overridePendingTransition(0, 0);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Solo cargar datos cuando el formulario sea de edición.
        if (detalleViewModel != null && detalleViewModel.hasSistema()) {
            detalleViewModel.getSistema().observe(getViewLifecycleOwner(), sistema -> {
                binding.etNombreCrearSistema.setText(sistema.nombre);

                formularioViewModel.getEquipoProveedorList().observe(getViewLifecycleOwner(), equipoProveedor -> {
                    spEquipoProveedor.setSelection(equipoProveedor.indexOf(sistema.equipoProveedor));
                });

                if (sistema.servidorDb != null) {
                    formularioViewModel.getServidorBDList().observe(getViewLifecycleOwner(), servidor -> {
                        spServidor.setSelection(servidor.indexOf(sistema.servidorDb));
                    });
                }

                formularioViewModel.getNivelSeguridadList().observe(getViewLifecycleOwner(), nivelSeguridad -> {
                    spNivelSeguridad.setSelection(nivelSeguridad.indexOf(sistema.nivelSeguridad));
                });

                if (sistema.nivelSensibilidad != null) {
                    formularioViewModel.getNivelSensibilidadList().observe(getViewLifecycleOwner(), nivelSensibilidad -> {
                        spNivelSensibilidad.setSelection(nivelSensibilidad.indexOf(sistema.nivelSensibilidad));
                    });
                }

                formularioViewModel.getUsuarioList().observe(getViewLifecycleOwner(), usuario -> {
                    spUsuario.setSelection(usuario.indexOf(sistema.usuario));
                });

                binding.clLoadingCrearSistemaForm.setVisibility(View.GONE);
                binding.llSistemaFormCrearSistema.setVisibility(View.VISIBLE);
            });
        } else {
            binding.clLoadingCrearSistemaForm.setVisibility(View.GONE);
            binding.llSistemaFormCrearSistema.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onValidationSucceeded() {
        // Se muestra animación de cargando
        binding.clLoadingCrearSistemaForm.setVisibility(View.VISIBLE);
        binding.llSistemaFormCrearSistema.setVisibility(View.GONE);
        binding.tvLoadingCrearSistema.setText("Guardando datos");

        // Manejo de datos
        Gson gson = new Gson();
        Sistema sistema = new Sistema();

        sistema.nombre = binding.etNombreCrearSistema.getText().toString();
        sistema.idEquipoProveedor = spEquipoProveedor.getSelectedItem().id;
        sistema.idNivelSeguridad = spNivelSeguridad.getSelectedItem().id;
        sistema.idUsuario = spUsuario.getSelectedItem().id;

        try {
            sistema.idServidorBd = spServidor.getSelectedItem().id;
        } catch (Exception e) {
            sistema.idServidorBd = null;
        }

        try {
            sistema.idNivelSensibilidad = spNivelSensibilidad.getSelectedItem().id;
        } catch (Exception e) {
            sistema.idNivelSensibilidad = null;
        }

        JSONObject request = new JSONObject();

        try {
            request.put("sistema", new JSONObject(gson.toJson(sistema)));
        } catch (JSONException ignored) {
        }

        if (detalleViewModel != null && detalleViewModel.hasSistema()) {
            sistema.actualizar(detalleViewModel.getSistemaId(), request, response -> {
                binding.clLoadingCrearSistemaForm.setVisibility(View.GONE);
                binding.llSistemaFormCrearSistema.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateSistemaList();
            }, error -> {
                binding.clLoadingCrearSistemaForm.setVisibility(View.GONE);
                binding.llSistemaFormCrearSistema.setVisibility(View.VISIBLE);

                Toast.makeText(root.getContext(), "Error al actualizar sistema", Toast.LENGTH_SHORT).show();
            });
        } else {
            sistema.crear(request, response -> {
                binding.clLoadingCrearSistemaForm.setVisibility(View.GONE);
                binding.llSistemaFormCrearSistema.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateSistemaList();
            }, error -> {
                binding.clLoadingCrearSistemaForm.setVisibility(View.GONE);
                binding.llSistemaFormCrearSistema.setVisibility(View.VISIBLE);

                Toast.makeText(root.getContext(), "Error al crear sistema", Toast.LENGTH_SHORT).show();
            });
        }

    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        AdapterMaterialSpinner.onErrorChanges(errors);
    }
}