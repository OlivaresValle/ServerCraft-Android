package com.example.servercraft.UI.ServidoresRacksSalas.Salas;

import android.os.Bundle;
import androidx.lifecycle.ViewModelProvider;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.example.servercraft.Models.Sala;
import com.example.servercraft.ViewModels.ServidoresRacksSalas.Salas.DetalleSala.DetalleSalaViewModel;
import com.example.servercraft.ViewModels.ServidoresRacksSalas.Salas.DetalleSala.DetalleSalaViewModelFactory;
import com.example.servercraft.databinding.FragmentDetalleSalaBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;

public class DetalleSalaFragment extends BottomSheetDialogFragment {
    private static final String ARG_SALA = "sala";
    private DetalleSalaViewModel detalleViewModel;
    private FragmentDetalleSalaBinding binding;

    public static DetalleSalaFragment newInstance(Sala sala) {
        DetalleSalaFragment fragment = new DetalleSalaFragment();
        Bundle bundle = new Bundle();
        Gson gson = new Gson();

        bundle.putString(ARG_SALA, gson.toJson(sala));
        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Sala sala = null;

        if (getArguments() != null) {
            Gson gson = new Gson();
            String jsonSala = getArguments().getString(ARG_SALA);

            sala = gson.fromJson(jsonSala, Sala.class);
        }

        detalleViewModel = new ViewModelProvider(this, new DetalleSalaViewModelFactory(sala)).get(DetalleSalaViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentDetalleSalaBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Observador de consulta HTTP
        detalleViewModel.getSala().observe(getViewLifecycleOwner(), sala -> {
            // Cargar datos cuando estén disponibles
            binding.tvSalaTitle.setText(sala.nombre);
            binding.tvSDDescripcion.setText(sala.descripcion);
            binding.tvSDRegion.setText(sala.region.nombre);
            binding.tvSDPais.setText(sala.region.pais.nombre);

            // Ocultar vista de "cargando..."
            binding.clLoadingSala.setVisibility(View.GONE);
            binding.llSalaData.setVisibility(View.VISIBLE);
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}