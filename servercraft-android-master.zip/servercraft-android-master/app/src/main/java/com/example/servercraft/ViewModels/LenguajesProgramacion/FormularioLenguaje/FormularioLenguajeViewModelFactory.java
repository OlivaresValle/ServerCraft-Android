package com.example.servercraft.ViewModels.LenguajesProgramacion.FormularioLenguaje;

import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import com.example.servercraft.Models.Lenguaje;

public class FormularioLenguajeViewModelFactory implements ViewModelProvider.Factory {
    private Lenguaje mLenguaje;

    public FormularioLenguajeViewModelFactory(@Nullable Lenguaje lenguaje) {
        if (lenguaje != null) {
            this.mLenguaje = lenguaje;
        }
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        return (T) new FormularioLenguajeViewModel(mLenguaje);
    }
}
