package com.example.servercraft.UI.ClientesProveedores.EquipoProveedor;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.chivorn.smartmaterialspinner.SmartMaterialSpinner;
import com.example.servercraft.Models.EquipoProveedor;
import com.example.servercraft.Models.ProveedorSistema;
import com.example.servercraft.Utils.AdapterMaterialSpinner;
import com.example.servercraft.ViewModels.ClientesProveedores.EquiposProveedores.DetalleEquipoProveedor.DetalleEquipoProveedorViewModel;
import com.example.servercraft.ViewModels.ClientesProveedores.EquiposProveedores.DetalleEquipoProveedor.DetalleEquipoProveedorViewModelFactory;
import com.example.servercraft.ViewModels.ClientesProveedores.EquiposProveedores.FormularioEquipoProveedorViewModel;
import com.example.servercraft.databinding.FragmentFormularioEquipoProveedorBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.Email;
import com.mobsandgeeks.saripaar.annotation.Length;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Pattern;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class FormularioEquipoProveedorFragment extends BottomSheetDialogFragment implements Validator.ValidationListener {
    private static final String ARG_ID_EQUIPO_PROVEEDOR = "id_equipo_proveedor";
    private DetalleEquipoProveedorViewModel detalleViewModel;
    private FormularioEquipoProveedorViewModel formularioViewModel;
    private FragmentFormularioEquipoProveedorBinding binding;
    private View root;
    private Validator validator;

    // Validaciones
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etNombreProveedorCrear;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etNombreRepresentanteCrear;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    @Email(message = "email inválido ")
    EditText etEmail;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    @Length(min = 9, max = 9, message = "Debe ser de 9 dígitos")
    EditText etTelefono;

    // Spinner
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    SmartMaterialSpinner<ProveedorSistema> spProveedor;

    public static FormularioEquipoProveedorFragment newInstance(@Nullable Integer idEquipoProveedor) {
        FormularioEquipoProveedorFragment fragment = new FormularioEquipoProveedorFragment();

        if (idEquipoProveedor != null) {
            Bundle bundle = new Bundle();

            bundle.putInt(ARG_ID_EQUIPO_PROVEEDOR, idEquipoProveedor);
            fragment.setArguments(bundle);
        }

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            Integer equipoProveedorId = getArguments().getInt(ARG_ID_EQUIPO_PROVEEDOR);

            detalleViewModel = new ViewModelProvider(this, new DetalleEquipoProveedorViewModelFactory(equipoProveedorId)).get(DetalleEquipoProveedorViewModel.class);
        }

        formularioViewModel = new ViewModelProvider(this).get(FormularioEquipoProveedorViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentFormularioEquipoProveedorBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.registerAdapter(SmartMaterialSpinner.class, new AdapterMaterialSpinner());
        validator.setValidationListener(this);

        // Intanciamiento de los campos a validar
        etNombreProveedorCrear = binding.etEPNombre;
        etNombreRepresentanteCrear = binding.etFormEPRepresentante;
        etTelefono = binding.etFormEPPhone;
        etEmail = binding.etFormEPEmail;

        // Loading Status
        binding.clLoadingEquipoProveedorForm.setVisibility(View.VISIBLE);
        binding.lSubmitEPForm.setVisibility(View.GONE);

        // Referenciación de elementos
        spProveedor = binding.spEPProveedor;

        // Carga de Spinners
        formularioViewModel.getProveedorList().observe(getViewLifecycleOwner(), proveedoresSistemas -> {
            spProveedor.setItem(proveedoresSistemas);
        });

        // Limpieza de errores al seleccionar
        spProveedor.setOnItemSelectedListener(AdapterMaterialSpinner.clearSpinner(spProveedor));

        // Configuración de botón de creación
        binding.btnCrearEPForm.setOnClickListener(v -> {
            validator.validate();

        });

        // Modificar título en caso de que se esté intentando editar un servidor
        if (detalleViewModel != null && detalleViewModel.hasEquipoProveedor()) {
            binding.tvEPFormTitle.setText("Editar equipo del proveedor");
            binding.btnCrearEPForm.setText("Actualizar equipo");
        }

        return root;
    }

    private void updateEquipoProveedorList() {
        getActivity().finish();
        getActivity().overridePendingTransition(0, 0);
        getActivity().startActivity(getActivity().getIntent());
        getActivity().overridePendingTransition(0, 0);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Solo cargar datos cuando el formulario sea de edición.
        if (detalleViewModel != null && detalleViewModel.hasEquipoProveedor()) {
            detalleViewModel.getEquipoProveedor().observe(getViewLifecycleOwner(), equipoProveedor -> {
                binding.etEPNombre.setText(equipoProveedor.nombre);
                binding.etFormEPRepresentante.setText(equipoProveedor.nombreRepresentante);
                binding.etFormEPEmail.setText(equipoProveedor.emailContacto);
                binding.etFormEPPhone.setText(equipoProveedor.telefonoContacto);

                formularioViewModel.getProveedorList().observe(getViewLifecycleOwner(), proveedorSistemas -> {
                    spProveedor.setSelection(proveedorSistemas.indexOf(equipoProveedor.proveedorSistema));
                });

                binding.clLoadingEquipoProveedorForm.setVisibility(View.GONE);
                binding.lSubmitEPForm.setVisibility(View.VISIBLE);
            });
        } else {
            binding.clLoadingEquipoProveedorForm.setVisibility(View.GONE);
            binding.lSubmitEPForm.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onValidationSucceeded() {
        // Se muestra animación de cargando
        binding.clLoadingEquipoProveedorForm.setVisibility(View.VISIBLE);
        binding.lSubmitEPForm.setVisibility(View.GONE);
        binding.tvLoadingEquipoProveedorForm.setText("Guardando datos");

        // Manejo de datos
        Gson gson = new Gson();
        EquipoProveedor equipoProveedor = new EquipoProveedor();

        equipoProveedor.nombre = binding.etEPNombre.getText().toString();
        equipoProveedor.idProveedorSistema = spProveedor.getSelectedItem().id;
        equipoProveedor.nombreRepresentante = binding.etFormEPRepresentante.getText().toString();
        equipoProveedor.emailContacto = binding.etFormEPEmail.getText().toString();
        equipoProveedor.telefonoContacto = binding.etFormEPPhone.getText().toString();

        JSONObject request = new JSONObject();

        try {
            request.put("equipoEncargado", new JSONObject(gson.toJson(equipoProveedor)));
        } catch (JSONException ignored) {
        }

        if (detalleViewModel != null && detalleViewModel.hasEquipoProveedor()) {
            equipoProveedor.actualizar(detalleViewModel.getEquipoProveedorId(), request, response -> {
                binding.clLoadingEquipoProveedorForm.setVisibility(View.GONE);
                binding.lSubmitEPForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateEquipoProveedorList();
            }, error -> {
                binding.clLoadingEquipoProveedorForm.setVisibility(View.GONE);
                binding.lSubmitEPForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al actualizar equipo de proveedor", Toast.LENGTH_SHORT).show();
            });
        } else {
            equipoProveedor.crear(request, response -> {
                binding.clLoadingEquipoProveedorForm.setVisibility(View.GONE);
                binding.lSubmitEPForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateEquipoProveedorList();
            }, error -> {
                binding.clLoadingEquipoProveedorForm.setVisibility(View.GONE);
                binding.lSubmitEPForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al crear equipo de proveedor", Toast.LENGTH_SHORT).show();
            });
        }

    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        AdapterMaterialSpinner.onErrorChanges(errors);

    }
}