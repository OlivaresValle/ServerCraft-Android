package com.example.servercraft.Utils;

import com.example.servercraft.Models.UsuarioResponse;
import com.example.servercraft.UI.MenuPrincipalUsuario.PerfilUsuario.ImageInterface;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Images {
    public byte[] getBytes(InputStream is) throws IOException {
        ByteArrayOutputStream byteBuff = new ByteArrayOutputStream();

        int buffSize = 1024;
        byte[] buff = new byte[buffSize];

        int len = 0;
        while ((len = is.read(buff)) != -1) {
            byteBuff.write(buff, 0, len);
        }

        return byteBuff.toByteArray();
    }

    public void uploadImage(byte[] imageBytes) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://servercraft-api.herokuapp.com")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ImageInterface retrofitInterface = retrofit.create(ImageInterface.class);

        RequestBody requestFile = RequestBody.create(MediaType.parse("image/jpeg"), imageBytes);

        MultipartBody.Part body = MultipartBody.Part.createFormData("imagen", "image.jpg", requestFile);
        Call<UsuarioResponse> call = retrofitInterface.uploadImage(body, "Bearer " + new Preferences("auth").getString("token"));

        call.enqueue(new Callback<UsuarioResponse>() {
            @Override
            public void onResponse(Call<UsuarioResponse> call, retrofit2.Response<UsuarioResponse> response) {
            }

            @Override
            public void onFailure(Call<UsuarioResponse> call, Throwable t) {
            }
        });
    }
}
