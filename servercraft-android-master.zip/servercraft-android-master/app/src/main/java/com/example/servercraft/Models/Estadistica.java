package com.example.servercraft.Models;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.servercraft.Utils.ServercraftApplication;

import org.json.JSONObject;

import java.util.Map;

public class Estadistica extends BaseHTTP {
    // Constants
    private final String ENDPOINT_BASE = super.HOST + "/estadistica";

    // Constructor
    public Estadistica() {
        super();
    }

    public void obtenerClientesNuevos(Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/clientes";

        JsonObjectRequest obtenerIncidente = new JsonObjectRequest(Request.Method.GET, ENDPOINT_DETAIL, null, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() {
                return Estadistica.super.headers;
            }
        };

        queue.add(obtenerIncidente);
    }

    public void obtenerIncidentesActivos(Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/incidentes";

        JsonObjectRequest obtenerIncidente = new JsonObjectRequest(Request.Method.GET, ENDPOINT_DETAIL, null, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() {
                return Estadistica.super.headers;
            }
        };

        queue.add(obtenerIncidente);
    }
}
