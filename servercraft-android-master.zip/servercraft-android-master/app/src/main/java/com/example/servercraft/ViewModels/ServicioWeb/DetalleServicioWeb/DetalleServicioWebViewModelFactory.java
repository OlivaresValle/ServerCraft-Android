package com.example.servercraft.ViewModels.ServicioWeb.DetalleServicioWeb;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import com.example.servercraft.Models.ServicioWeb;
import org.jetbrains.annotations.Nullable;

public class DetalleServicioWebViewModelFactory implements ViewModelProvider.Factory {
    private ServicioWeb mServicioWeb;

    public DetalleServicioWebViewModelFactory(@Nullable ServicioWeb servicioWeb) {
        if (servicioWeb != null) {
            this.mServicioWeb = servicioWeb;
        }
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        return (T) new DetalleServicioWebViewModel(mServicioWeb);
    }
}
