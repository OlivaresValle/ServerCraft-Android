package com.example.servercraft.UI.UsuariosEquipos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.servercraft.UI.UsuariosEquipos.EquiposTrabajo.FormularioEquipoTrabajoFragment;
import com.example.servercraft.UI.UsuariosEquipos.UnidadesNegocio.FormularioUnidadNegocioFragment;
import com.example.servercraft.UI.UsuariosEquipos.Usuarios.FormularioUsuarioFragment;
import com.example.servercraft.Utils.UserInfo;
import com.example.servercraft.databinding.ActivityUsuariosEquiposBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;

import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import java.util.Objects;

public class UsuariosEquipos extends AppCompatActivity {
    private ActivityUsuariosEquiposBinding binding;
    FloatingActionButton btnCrear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Configuración binding de layout
        binding = ActivityUsuariosEquiposBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        int userRol = new UserInfo().getUserRol();

        // Botón flotante
        btnCrear = binding.btnCrearUsuarioEquipo;

        btnCrear.setOnClickListener(v -> {
            FormularioUsuarioFragment formulario = FormularioUsuarioFragment.newInstance(null);
            formulario.show(getSupportFragmentManager(), formulario.getTag());
        });

        // Toolbar
        Toolbar tbMain = binding.tbMainUsuario.tbMain;
        TextView tbTitle = binding.tbMainUsuario.tvTbTitle;

        setSupportActionBar(tbMain);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        binding.tbMainUsuario.cvUsuarioMenuPrincipal.setVisibility(View.GONE);
        tbTitle.setText("Administrar usuarios");
        tbMain.setContentInsetStartWithNavigation(0);
        tbMain.setNavigationOnClickListener(v -> {
            finish();
        });

        // Configuración Tabs
        UsuariosEquiposPagerAdapter sectionsPagerAdapter = new UsuariosEquiposPagerAdapter(this, getSupportFragmentManager());

        ViewPager viewPager = binding.vpUsuariosEquiposTabs;
        viewPager.setAdapter(sectionsPagerAdapter);


        TabLayout tabs = binding.tabUsuarioEquipoUnidad;
        tabs.setupWithViewPager(viewPager);

        if (userRol != 1) {
            Objects.requireNonNull(tabs.getTabAt(0)).view.setVisibility(View.GONE);
            tabs.selectTab(tabs.getTabAt(1));
            btnCrear.setVisibility(View.GONE);
        }

        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                switch (position) {
                    case 0:
                        tbTitle.setText("Administrar usuarios");

                        btnCrear.setOnClickListener(v -> {
                            FormularioUsuarioFragment formulario = FormularioUsuarioFragment.newInstance(null);
                            formulario.show(getSupportFragmentManager(), formulario.getTag());
                        });

                        break;
                    case 1:
                        tbTitle.setText("Equipos de trabajo");

                        btnCrear.setOnClickListener(v -> {
                            FormularioEquipoTrabajoFragment formulario = FormularioEquipoTrabajoFragment.newInstance(null);
                            formulario.show(getSupportFragmentManager(), formulario.getTag());
                        });

                        break;
                    case 2:
                        tbTitle.setText("Unidades de negocio");

                        btnCrear.setOnClickListener(v -> {
                            FormularioUnidadNegocioFragment formulario = FormularioUnidadNegocioFragment.newInstance(null);
                            formulario.show(getSupportFragmentManager(), formulario.getTag());
                        });

                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}
