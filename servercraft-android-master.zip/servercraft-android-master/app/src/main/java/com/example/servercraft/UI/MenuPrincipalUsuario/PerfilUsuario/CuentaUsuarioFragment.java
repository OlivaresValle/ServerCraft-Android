package com.example.servercraft.UI.MenuPrincipalUsuario.PerfilUsuario;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.servercraft.UI.Login.LoginActivity;
import com.example.servercraft.Utils.Preferences;
import com.example.servercraft.Utils.UserInfo;
import com.example.servercraft.databinding.FragmentCuentaUsuarioBinding;


public class CuentaUsuarioFragment extends Fragment {
    FragmentCuentaUsuarioBinding binding;
    View root;

    public CuentaUsuarioFragment() {
    }

    public static CuentaUsuarioFragment newInstance() {
        CuentaUsuarioFragment fragment = new CuentaUsuarioFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentCuentaUsuarioBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        binding.btnCerrarSesion.setOnClickListener(view -> {
            AlertDialog.Builder confirmation = new AlertDialog.Builder(getContext());
            confirmation.setTitle("Cerrar sesión")
                    .setMessage("¿Estás seguro de qué deseas cerrar sesión?")
                    .setCancelable(false)
                    .setPositiveButton("Cerrar sesión", (dialog, which) -> {
                        Intent login = new Intent(getActivity(), LoginActivity.class);
                        new UserInfo().setUserImage("");
                        new UserInfo().setUserRol(0);
                        new Preferences("auth").addValue("token", "");

                        startActivity(login);
                        getActivity().finish();
                    }).setNegativeButton("Cancelar", (dialog, which) -> {
                dialog.dismiss();
            });

            confirmation.create().show();

        });

        return root;
    }
}