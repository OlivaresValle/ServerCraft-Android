package com.example.servercraft.ViewModels.UsuariosEquipos.UnidadesNegocio.FormularioUnidadNegocio;

import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.UnidadNegocio;

public class FormularioUnidadNegocioViewModel extends ViewModel {
    private MutableLiveData<UnidadNegocio> mUnidadNegocio;

    // Constructor
    public FormularioUnidadNegocioViewModel(@Nullable UnidadNegocio unidadNegocio) {
        mUnidadNegocio = new MutableLiveData<>();

        if (unidadNegocio != null) {
            mUnidadNegocio.setValue(unidadNegocio);
        }
    }

    // Getters
    public MutableLiveData<UnidadNegocio> getUnidadNegocio() {
        return mUnidadNegocio;
    }

    public Integer getUnidadNegocioId() {
        return mUnidadNegocio.getValue().id;
    }

    public boolean hasUnidadNegocio() {
        return mUnidadNegocio.getValue() != null;
    }
}
