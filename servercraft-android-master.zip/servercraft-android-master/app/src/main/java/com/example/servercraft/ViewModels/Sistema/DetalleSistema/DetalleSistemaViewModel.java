package com.example.servercraft.ViewModels.Sistema.DetalleSistema;

import android.util.Log;
import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.DocumentoSistema;
import com.example.servercraft.Models.Instancia;
import com.example.servercraft.Models.Lenguaje;
import com.example.servercraft.Models.ServicioWeb;
import com.example.servercraft.Models.Sistema;
import com.example.servercraft.Models.Usuario;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class DetalleSistemaViewModel extends ViewModel {
    private MutableLiveData<Integer> sistemaId;
    private MutableLiveData<Sistema> mSistema;
    public int pagina = 0;
    public String busqueda = "";

    private MutableLiveData<ArrayList<Instancia>> mInstancia;
    private MutableLiveData<ArrayList<DocumentoSistema>> mDocumento;
    private MutableLiveData<ArrayList<Lenguaje>> mLenguaje;
    private MutableLiveData<ArrayList<ServicioWeb>> mServicioWeb;
    private MutableLiveData<ArrayList<Usuario>> mUsuario;

    // Constructor
    public DetalleSistemaViewModel(@Nullable Integer idSistema) {
        sistemaId = new MutableLiveData<>();
        mSistema = new MutableLiveData<>();

        mInstancia = new MutableLiveData<>();
        mDocumento = new MutableLiveData<>();
        mLenguaje = new MutableLiveData<>();
        mServicioWeb = new MutableLiveData<>();
        mUsuario = new MutableLiveData<>();

        if (idSistema != null) {
            sistemaId.setValue(idSistema);
            loadHTTPSistem();
        }

        loadHTTPInstanciaList();
        loadHTTPDocumentoList();
        loadHTTPLenguajeList(1, "");
        loadHTTPServicioWebList();
        loadHTTPUSuarioList();
    }

    // Getters
    public MutableLiveData<Sistema> getSistema() {
        return mSistema;
    }

    public Integer getSistemaId() {
        return sistemaId.getValue();
    }

    public boolean hasSistema() {
        return !sistemaId.getValue().equals(null);
    }

    public MutableLiveData<ArrayList<Instancia>> getInstanciaList() {
        return mInstancia;
    }

    public MutableLiveData<ArrayList<DocumentoSistema>> getDocumentoList() {
        return mDocumento;
    }

    public MutableLiveData<ArrayList<Lenguaje>> getLenguajeList() {
        return mLenguaje;
    }

    public MutableLiveData<ArrayList<ServicioWeb>> getServicioWebList() {
        return mServicioWeb;
    }

    // Setters
    private void loadHTTPSistem() {
        Sistema sistema = new Sistema();

        sistema.obtener(sistemaId.getValue(), response -> {
            try {
                JSONObject httpSistema = response.getJSONObject("sistema");
                Sistema objectSistema = mapSistemaIntoObject(httpSistema);

                mSistema.setValue(objectSistema);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private Sistema mapSistemaIntoObject(JSONObject httpSistema) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Sistema sistema = gson.fromJson(httpSistema.toString(), Sistema.class);

        return sistema;
    }

    // 1 - Instancia
    private void loadHTTPInstanciaList() {
        Instancia instancia = new Instancia();

        instancia.listar(null, response -> {
            try {
                JSONArray httpInstancia = response.getJSONArray("instancias");

                ArrayList<Instancia> objectInstanciaList = mapInstanciaIntoObject(httpInstancia);

                mInstancia.setValue(objectInstanciaList);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()),10000,1);
    }

    private ArrayList<Instancia> mapInstanciaIntoObject(JSONArray httpInstancia) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type InstanciaArray = new TypeToken<ArrayList<Instancia>>() {
        }.getType();
        ArrayList<Instancia> instanciaList = gson.fromJson(httpInstancia.toString(), InstanciaArray);

        return instanciaList;
    }

    // 2 - Documento
    private void loadHTTPDocumentoList() {
        DocumentoSistema documentoSistema = new DocumentoSistema();

        documentoSistema.listar(null, response -> {
            try {
                JSONArray httpDocumento = response.getJSONArray("documentos");

                ArrayList<DocumentoSistema> objectDocumentoSistemaList = mapDocumentoIntoObject(httpDocumento);

                mDocumento.setValue(objectDocumentoSistemaList);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<DocumentoSistema> mapDocumentoIntoObject(JSONArray httpDocumento) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type DocumentoArray = new TypeToken<ArrayList<DocumentoSistema>>() {
        }.getType();
        ArrayList<DocumentoSistema> documentoSistemaList = gson.fromJson(httpDocumento.toString(), DocumentoArray);

        return documentoSistemaList;
    }

    // 3 - Lenguaje
    private void loadHTTPLenguajeList(int pagina, @Nullable String q) {
        Lenguaje lenguaje = new Lenguaje();

        lenguaje.listar(1000, pagina, q, null, response -> {
            try {
                JSONArray httpLenguaje = response.getJSONArray("lenguajes_programacion");

                ArrayList<Lenguaje> objectLenguajeList = mapLenguajeIntoObject(httpLenguaje);

                mLenguaje.setValue(objectLenguajeList);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<Lenguaje> mapLenguajeIntoObject(JSONArray httpLenguaje) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type LenguajeArray = new TypeToken<ArrayList<Lenguaje>>() {
        }.getType();
        ArrayList<Lenguaje> lenguajeList = gson.fromJson(httpLenguaje.toString(), LenguajeArray);

        return lenguajeList;
    }

    // 4 - Servicio Web
    private void loadHTTPServicioWebList() {
        ServicioWeb servicioWeb = new ServicioWeb();

        servicioWeb.listar(1000, 1,null,null, response -> {
            try {
                JSONArray httpServicioWeb = response.getJSONArray("servicios");

                ArrayList<ServicioWeb> objectServicioWebList = mapServicioWebIntoObject(httpServicioWeb);

                mServicioWeb.setValue(objectServicioWebList);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<ServicioWeb> mapServicioWebIntoObject(JSONArray httpServicioWeb) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type ServicioWebArray = new TypeToken<ArrayList<ServicioWeb>>() {
        }.getType();
        ArrayList<ServicioWeb> servicioWebList = gson.fromJson(httpServicioWeb.toString(), ServicioWebArray);

        return servicioWebList;
    }

    // 5 - Usuario
    private void loadHTTPUSuarioList() {
        Usuario usuario = new Usuario();

        usuario.listar(10,pagina,busqueda,null, response -> {
            try {
                JSONArray httpUsuario = response.getJSONArray("usuarios");

                ArrayList<Usuario> objectUsuarioList = mapUSuarioIntoObject(httpUsuario);

                mUsuario.setValue(objectUsuarioList);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<Usuario> mapUSuarioIntoObject(JSONArray httpUSer) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type UsuarioArray = new TypeToken<ArrayList<Usuario>>() {
        }.getType();
        ArrayList<Usuario> usuarioList = gson.fromJson(httpUSer.toString(), UsuarioArray);

        return usuarioList;
    }
}
