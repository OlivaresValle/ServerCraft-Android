package com.example.servercraft.UI.BaseDeDatos;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import com.example.servercraft.ViewModels.BaseDatos.ListarBaseDatosViewModel;
import com.example.servercraft.databinding.ActivityListarBaseDatosBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;


public class ListarBaseDatos extends AppCompatActivity {
    private ActivityListarBaseDatosBinding binding;
    private ListarBaseDatosViewModel listarViewModel;
    private BaseDatosItemAdapter baseDatosItemAdapter;
    FloatingActionButton btnCrear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Configuración binding de layout
        binding = ActivityListarBaseDatosBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Configuración View Model
        listarViewModel = new ViewModelProvider(this).get(ListarBaseDatosViewModel.class);

        // Botón flotante
        binding.btnCrearBaseDatos.setOnClickListener(v -> {
            FormularioBaseDatosFragment formularioBaseDatosFragment = FormularioBaseDatosFragment.newInstance(null);
            formularioBaseDatosFragment.show(getSupportFragmentManager(), formularioBaseDatosFragment.getTag());
        });

        // Toolbar
        Toolbar toolbar = binding.tbMainBaseDatos.tbMain;

        TextView tvTbTitle = binding.tbMainBaseDatos.tvTbTitle;
        TextView tvTbDescripcion = binding.tbMainBaseDatos.tvTbDescripcion;

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        binding.tbMainBaseDatos.cvUsuarioMenuPrincipal.setVisibility(View.GONE);
        tvTbTitle.setText("Motores Base de Datos");
        tvTbDescripcion.setText("Gestionar motores base de datos");
        toolbar.setContentInsetStartWithNavigation(0);
        toolbar.setNavigationOnClickListener(v -> {
            finish();
        });

        // Elements
        binding.pbHttpLoadingBaseDatos.setVisibility(View.VISIBLE);
        binding.rvBaseDeDatos.setLayoutManager(new LinearLayoutManager(this));

        // Observador de consulta HTTP
        listarViewModel.getBaseDatosList().observe(this, baseDatos -> {

            if (baseDatosItemAdapter == null) {
                baseDatosItemAdapter = new BaseDatosItemAdapter(this, baseDatos, getSupportFragmentManager());

                binding.rvBaseDeDatos.setAdapter(baseDatosItemAdapter);

                binding.pbHttpLoadingBaseDatos.setVisibility(View.INVISIBLE);
            } else {
                binding.rvBaseDeDatos.post(new Runnable() {
                    public void run() {
                        baseDatosItemAdapter.notifyItemRangeChanged(0,baseDatos.size() - 1);
                    }
                });
            }
        });

        binding.btnBuscarBaseDeDatos.setOnClickListener(v -> {
            Log.d("Boton", "apretado");
            binding.pbHttpLoadingBaseDatos.setVisibility(View.VISIBLE);
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etBaseDeDatosBusqueda.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arBaseDeDatos.clear();
            listarViewModel.loadHTTPBaseDatosList();
            baseDatosItemAdapter = null;
        });

        // Listener de scroll para cargar siguientes páginas
        binding.rvBaseDeDatos.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                if (!listarViewModel.cargandoDatos) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == listarViewModel.arBaseDeDatos.size() - 1) {
                        listarViewModel.cargandoDatos = true;
                        listarViewModel.loadHTTPBaseDatosList();
                    }
                }
            }
        });
    }
}