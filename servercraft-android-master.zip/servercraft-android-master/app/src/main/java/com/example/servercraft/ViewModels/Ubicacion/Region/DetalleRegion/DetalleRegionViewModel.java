package com.example.servercraft.ViewModels.Ubicacion.Region.DetalleRegion;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.servercraft.Models.Region;

import org.jetbrains.annotations.Nullable;

public class DetalleRegionViewModel extends ViewModel {
    private MutableLiveData<Region> mRegion;

    //Constructor
    public DetalleRegionViewModel(@Nullable Region region){
        mRegion = new MutableLiveData<>();

        mRegion.setValue(region);
    }

    //Getters
    public MutableLiveData<Region> getRegion(){return mRegion;}

    public boolean hasRegion(){return mRegion != null;}

}
