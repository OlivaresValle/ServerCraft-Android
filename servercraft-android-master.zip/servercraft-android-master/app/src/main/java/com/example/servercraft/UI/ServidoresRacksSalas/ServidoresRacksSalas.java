package com.example.servercraft.UI.ServidoresRacksSalas;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;
import com.example.servercraft.UI.ServidoresRacksSalas.Racks.FormularioRackFragment;
import com.example.servercraft.UI.ServidoresRacksSalas.Salas.FormularioSalaFragment;
import com.example.servercraft.UI.ServidoresRacksSalas.Servidores.FormularioServidorFragment;
import com.example.servercraft.Utils.UserInfo;
import com.example.servercraft.databinding.ActivityServidoresRacksSalasBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;

import java.util.Objects;

public class ServidoresRacksSalas extends AppCompatActivity {
    private ActivityServidoresRacksSalasBinding binding;
    FloatingActionButton btnCrear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Configuración binding de layout
        binding = ActivityServidoresRacksSalasBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        int userRol = new UserInfo().getUserRol();


        // Botón flotante
        btnCrear = binding.btnCrearSSR;

        btnCrear.setOnClickListener(v -> {
            FormularioServidorFragment formulario = FormularioServidorFragment.newInstance(null);
            formulario.show(getSupportFragmentManager(), formulario.getTag());
        });

        // Toolbar
        Toolbar tbMain = binding.tbMainServer.tbMain;
        TextView tbTitle = binding.tbMainServer.tvTbTitle;

        setSupportActionBar(tbMain);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        binding.tbMainServer.cvUsuarioMenuPrincipal.setVisibility(View.GONE);
        tbTitle.setText("Servidores");
        tbMain.setContentInsetStartWithNavigation(0);
        tbMain.setNavigationOnClickListener(v -> {
            finish();
        });

        // Configuración Tabs
        ServidoresRacksSalasPagerAdapter sectionsPagerAdapter = new ServidoresRacksSalasPagerAdapter(this, getSupportFragmentManager());

        ViewPager viewPager = binding.vpServidoresRacksSalasTabs;
        viewPager.setAdapter(sectionsPagerAdapter);

        TabLayout tabs = binding.tabServerRackSala;
        tabs.setupWithViewPager(viewPager);


        if (userRol == 2 || userRol == 3){
            binding.btnCrearSSR.setVisibility(View.GONE);
        }


        if (userRol == 3 ) {
            Objects.requireNonNull(tabs.getTabAt(1)).view.setVisibility(View.GONE);
            Objects.requireNonNull(tabs.getTabAt(2)).view.setVisibility(View.GONE);
        }


        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                switch (position) {
                    case 0:
                        tbTitle.setText("Servidores");

                        btnCrear.setOnClickListener(v -> {
                            FormularioServidorFragment formulario = FormularioServidorFragment.newInstance(null);
                            formulario.show(getSupportFragmentManager(), formulario.getTag());
                        });

                        break;
                    case 1:
                        tbTitle.setText("Racks");

                        btnCrear.setOnClickListener(v -> {
                            FormularioRackFragment formulario = FormularioRackFragment.newInstance(null);
                            formulario.show(getSupportFragmentManager(), formulario.getTag());
                        });

                        break;
                    case 2:
                        tbTitle.setText("Salas");

                        btnCrear.setOnClickListener(v -> {
                            FormularioSalaFragment formulario = FormularioSalaFragment.newInstance(null);
                            formulario.show(getSupportFragmentManager(), formulario.getTag());
                        });

                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}

