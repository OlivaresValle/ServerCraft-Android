package com.example.servercraft.ViewModels.LenguajesProgramacion;

import android.util.Log;

import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.servercraft.Models.Lenguaje;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Objects;

public class ListarLenguajesViewModel extends ViewModel {
    private MutableLiveData<ArrayList<Lenguaje>> mLenguajes;
    public ArrayList<Lenguaje> arLenguajes = new ArrayList<>();

    public boolean cargandoDatos = false;
    public boolean blPuedeCargarMas = true;
    public int pagina = 0;
    public String busqueda = "";

    // Constructor
    public ListarLenguajesViewModel() {
        mLenguajes = new MutableLiveData<>();
        loadHTTPLenguajeList();
    }

    // Getters
    public MutableLiveData<ArrayList<Lenguaje>> getLenguajeList() {
        return mLenguajes;
    }

    // Setters
    public void loadHTTPLenguajeList() {
        if (blPuedeCargarMas) {
            Lenguaje lenguaje = new Lenguaje();

            pagina = pagina + 1;

            if (arLenguajes.size() != 0) {
                arLenguajes.add(null);
                mLenguajes.setValue(arLenguajes);
            }

            Log.d("Busqueda", busqueda);

            lenguaje.listar(10, pagina, busqueda, null, response -> {
                try {
                    JSONArray httpLenguajes = response.getJSONArray("lenguajes_programacion");
                    JSONObject httpMeta = response.getJSONObject("meta");

                    Log.d("Resultados",httpLenguajes.toString());

                    arLenguajes.removeIf(Objects::isNull);


                    if (httpMeta.getInt("last_page") == pagina) {
                        blPuedeCargarMas = false;
                    }

                    arLenguajes.addAll(mapLenguajesIntoObject(httpLenguajes));

                    mLenguajes.setValue(arLenguajes);

                    cargandoDatos = false;
                } catch (JSONException e) {
                    Log.e("Listar leng", e.toString());
                }
            }, error -> Log.d("Error de ", error.toString()));
        }
    }

    private ArrayList<Lenguaje> mapLenguajesIntoObject(JSONArray httpLenguajes) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type LenguajeArray = new TypeToken<ArrayList<Lenguaje>>() {
        }.getType();
        ArrayList<Lenguaje> lenguajeList = gson.fromJson(httpLenguajes.toString(), LenguajeArray);

        return lenguajeList;
    }
}
