package com.example.servercraft.Utils;

import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Toast;

import com.chivorn.smartmaterialspinner.SmartMaterialSpinner;
import com.example.servercraft.R;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.adapter.ViewDataAdapter;
import com.mobsandgeeks.saripaar.exception.ConversionException;

import java.util.List;


public class AdapterMaterialSpinner implements ViewDataAdapter<SmartMaterialSpinner, String> {

    public static AdapterView.OnItemSelectedListener clearSpinner(SmartMaterialSpinner spinner) {
        return new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                spinner.setEnableErrorLabel(false);
                spinner.setUnderlineColor(R.color.primary_500);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        };
    }

    public static void onErrorChanges (List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(ServercraftApplication.getAppContext());

            // Display error messages ;)
            if (view instanceof EditText) {
                ((EditText) view).setError(message);
            } else if (view instanceof SmartMaterialSpinner) {
                ((SmartMaterialSpinner<?>) view).setEnableErrorLabel(true);
                ((SmartMaterialSpinner<?>) view).setErrorText(message);
                ((SmartMaterialSpinner<?>) view).setUnderlineColor(R.color.danger_500);
            } else {
                Toast.makeText(ServercraftApplication.getAppContext(), message, Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public String getData(SmartMaterialSpinner spSpinner) throws ConversionException {
        if (spSpinner.getSelectedItem() != null) {
            return spSpinner.getSelectedItem().toString();
        } else {
            return "";
        }
    }
}
