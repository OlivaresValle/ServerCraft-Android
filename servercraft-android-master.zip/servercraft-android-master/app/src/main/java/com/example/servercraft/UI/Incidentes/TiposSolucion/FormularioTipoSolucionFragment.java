package com.example.servercraft.UI.Incidentes.TiposSolucion;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.example.servercraft.Models.TipoSolucion;
import com.example.servercraft.Utils.AdapterMaterialSpinner;
import com.example.servercraft.ViewModels.Incidentes.TiposSolucion.FormularioTipoSolucion.FormularioTipoSolucionViewModel;
import com.example.servercraft.ViewModels.Incidentes.TiposSolucion.FormularioTipoSolucion.FormularioTipoSolucionViewModelFactory;
import com.example.servercraft.databinding.FragmentFormularioTipoSolucionBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class FormularioTipoSolucionFragment extends BottomSheetDialogFragment implements Validator.ValidationListener {
    // Configuración de View Model
    private static final String ARG_TIPO_SOLUCION = "tipo_solucion";
    private FormularioTipoSolucionViewModel formularioViewModel;
    private FragmentFormularioTipoSolucionBinding binding;
    private Validator validator;
    private View root;

    // Validaciones
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etTipoSolucion;

    public static FormularioTipoSolucionFragment newInstance(@Nullable TipoSolucion tipoSolucion) {
        FormularioTipoSolucionFragment fragment = new FormularioTipoSolucionFragment();

        if (tipoSolucion != null) {
            Bundle bundle = new Bundle();
            Gson gson = new Gson();

            bundle.putString(ARG_TIPO_SOLUCION, gson.toJson(tipoSolucion));
            fragment.setArguments(bundle);
        }

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TipoSolucion tipoSolucion = null;

        if (getArguments() != null) {
            Gson gson = new Gson();

            tipoSolucion = gson.fromJson(getArguments().getString(ARG_TIPO_SOLUCION), TipoSolucion.class);
        }

        formularioViewModel = new ViewModelProvider(this, new FormularioTipoSolucionViewModelFactory(tipoSolucion)).get(FormularioTipoSolucionViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentFormularioTipoSolucionBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.setValidationListener(this);

        // Intanciamiento de los campos a validar
        etTipoSolucion = binding.etTipoSolucion;


        // Loading Status
        binding.clLoadingTipoSolucionForm.setVisibility(View.VISIBLE);
        binding.lSubmitTipoSolucionForm.setVisibility(View.GONE);

        // Configuración de botón de creación
        binding.btnCrearTipoSolucionForm.setOnClickListener(v -> {
            validator.validate();
        });

        // Modificar título en caso de que se esté intentando editar un servidor
        if (formularioViewModel != null && formularioViewModel.hasTipoSolucion()) {
            binding.tvTipoSolucionFormTitle.setText("Editar tipo de solución");
            binding.btnCrearTipoSolucionForm.setText("Actualizar tipo de solución");
        }

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Solo cargar datos cuando el formulario sea de edición.
        if (formularioViewModel != null && formularioViewModel.hasTipoSolucion()) {
            formularioViewModel.getTipoSolucion().observe(getViewLifecycleOwner(), tipoSolucion -> {
                binding.etTipoSolucion.setText(tipoSolucion.nombre);
            });
        }

        binding.clLoadingTipoSolucionForm.setVisibility(View.GONE);
        binding.lSubmitTipoSolucionForm.setVisibility(View.VISIBLE);
    }

    private void updateTipoProblemaList() {
        getActivity().finish();
        getActivity().overridePendingTransition(0, 0);
        getActivity().startActivity(getActivity().getIntent());
        getActivity().overridePendingTransition(0, 0);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }


    @Override
    public void onValidationSucceeded() {
        // Se muestra animación de cargando
        binding.clLoadingTipoSolucionForm.setVisibility(View.VISIBLE);
        binding.lSubmitTipoSolucionForm.setVisibility(View.GONE);
        binding.tvLoadingTipoSolucionForm.setText("Guardando datos");

        // Manejo de datos
        Gson gson = new Gson();
        TipoSolucion tipoSolucion = new TipoSolucion();

        tipoSolucion.nombre = binding.etTipoSolucion.getText().toString();

        JSONObject request = new JSONObject();

        try {
            request.put("tipoSolucion", new JSONObject(gson.toJson(tipoSolucion)));
        } catch (JSONException ignored) {
        }

        if (formularioViewModel != null && formularioViewModel.hasTipoSolucion()) {
            tipoSolucion.actualizar(formularioViewModel.getTipoSolucion().getValue().id, request, response -> {
                binding.clLoadingTipoSolucionForm.setVisibility(View.GONE);
                binding.lSubmitTipoSolucionForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateTipoProblemaList();
            }, error -> {
                binding.clLoadingTipoSolucionForm.setVisibility(View.GONE);
                binding.lSubmitTipoSolucionForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al actualizar tipo de solución", Toast.LENGTH_SHORT).show();
            });
        } else {
            tipoSolucion.crear(request, response -> {
                binding.clLoadingTipoSolucionForm.setVisibility(View.GONE);
                binding.lSubmitTipoSolucionForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateTipoProblemaList();
            }, error -> {
                binding.clLoadingTipoSolucionForm.setVisibility(View.GONE);
                binding.lSubmitTipoSolucionForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al crear tipo de problema", Toast.LENGTH_SHORT).show();
            });
        }
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        AdapterMaterialSpinner.onErrorChanges(errors);
    }
}