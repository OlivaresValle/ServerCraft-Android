package com.example.servercraft.UI.MenuPrincipalUsuario;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.servercraft.UI.ActividadAuditoria.ListarActividadAuditoria;
import com.example.servercraft.UI.Estadisticas.VisualizarEstadisticas;
import com.example.servercraft.UI.Incidentes.IncidentesTab;
import com.example.servercraft.ViewModels.MenuPrincipalUsuario.IncidentesMenuViewModel;
import com.example.servercraft.databinding.FragmentMenuIncidentesBinding;

public class IncidentesMenuFragment extends Fragment {
    private IncidentesMenuViewModel incidentesMenuViewModel;
    private FragmentMenuIncidentesBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Configuración Binding
        incidentesMenuViewModel = new ViewModelProvider(this).get(IncidentesMenuViewModel.class);
        binding = FragmentMenuIncidentesBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Elementos
        incidentesMenuViewModel.getMenuList().observe(getViewLifecycleOwner(), menus -> {
            MenuItemAdapter menuAdapter = new MenuItemAdapter(root.getContext(), menus);
            binding.rvMenuIncidentes.setLayoutManager(new LinearLayoutManager(root.getContext()));

            menuAdapter.setOnClickListener(v -> {
                String titulo = menus.get(binding.rvMenuIncidentes.getChildAdapterPosition(v)).getTitulo();

                switch (titulo) {
                    case "Incidentes": {
                        Intent i = new Intent(root.getContext(), IncidentesTab.class);
                        startActivity(i);

                        break;
                    }

                    case "Estadísticas": {
                        Intent i = new Intent(root.getContext(), VisualizarEstadisticas.class);
                        startActivity(i);
                        break;
                    }

                    case "Registro de actividad": {
                        Intent i = new Intent(root.getContext(), ListarActividadAuditoria.class);
                        startActivity(i);
                        break;
                    }
                }
            });

            binding.rvMenuIncidentes.setAdapter(menuAdapter);
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}