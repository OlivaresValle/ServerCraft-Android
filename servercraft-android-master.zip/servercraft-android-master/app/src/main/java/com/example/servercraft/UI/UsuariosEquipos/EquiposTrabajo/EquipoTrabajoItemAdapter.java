package com.example.servercraft.UI.UsuariosEquipos.EquiposTrabajo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.servercraft.Models.EquipoTrabajo;
import com.example.servercraft.Models.Lenguaje;
import com.example.servercraft.R;
import com.example.servercraft.UI.LenguajesProgramacion.FormularioLenguajeProgramacionFragment;
import com.example.servercraft.UI.LenguajesProgramacion.LenguajeItemAdapter;
import com.example.servercraft.Utils.UserInfo;

import java.util.ArrayList;

public class EquipoTrabajoItemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;

    LayoutInflater inflater;
    ArrayList<EquipoTrabajo> model;
    FragmentManager fragmentManager;
    Context context;

    public EquipoTrabajoItemAdapter(Context context, ArrayList<EquipoTrabajo> model, FragmentManager fm) {
        this.inflater = LayoutInflater.from(context);
        this.model = model;
        this.fragmentManager = fm;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = inflater.inflate(R.layout.item_list_general_no_view, parent, false);

            return new EquipoTrabajoItemAdapter.ItemViewHolder(view);
        } else {
            View view = inflater.inflate(R.layout.item_list_loading, parent, false);

            return new EquipoTrabajoItemAdapter.LoadingViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof EquipoTrabajoItemAdapter.ItemViewHolder) {
            populateItemRows((EquipoTrabajoItemAdapter.ItemViewHolder) holder, position);
        } else if (holder instanceof EquipoTrabajoItemAdapter.LoadingViewHolder) {
            showLoadingView((EquipoTrabajoItemAdapter.LoadingViewHolder) holder, position);
        }
    }

    @Override
    public int getItemCount() {
        return model == null ? 0 : model.size();
    }

    @Override
    public int getItemViewType(int position) {
        return model.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ConstraintLayout clItemData, clItemActions;
        TextView nombre, tipo;
        Button btnEdit, btnDelete;
        ImageView ivChevronDown;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            int userRol = new UserInfo().getUserRol();

            nombre = itemView.findViewById(R.id.tvItemTitle);
            tipo = itemView.findViewById(R.id.tvItemDescription);
            clItemData = itemView.findViewById(R.id.clItemData);
            clItemActions = itemView.findViewById(R.id.clItemActions);
            btnEdit = itemView.findViewById(R.id.btnUpdate);
            btnDelete = itemView.findViewById(R.id.btnDelete);
            ivChevronDown = itemView.findViewById(R.id.ivChevronDown);

            if (userRol == 2 || userRol == 3) {
                btnEdit.setVisibility(View.GONE);
                btnDelete.setVisibility(View.GONE);
                ivChevronDown.setVisibility(View.GONE);
            }


            clItemData.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int adapterPosition = getBindingAdapterPosition();
            EquipoTrabajo equipoTrabajo = model.get(adapterPosition);
            equipoTrabajo.isFullyVisible = !equipoTrabajo.isFullyVisible;

            notifyItemChanged(adapterPosition);
        }
    }


    private class LoadingViewHolder extends RecyclerView.ViewHolder {

        public LoadingViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    private void showLoadingView(EquipoTrabajoItemAdapter.LoadingViewHolder viewHolder, int position) {
        //ProgressBar would be displayed

    }

    private void populateItemRows(EquipoTrabajoItemAdapter.ItemViewHolder holder, int position) {
        // Obtención de objeto
        EquipoTrabajo equipoTrabajo = model.get(position);

        // Seteo de valores en view holder
        holder.nombre.setText(equipoTrabajo.nombre);
        holder.tipo.setText(equipoTrabajo.unidadNegocio.nombre);
        holder.clItemActions.setVisibility(equipoTrabajo.isFullyVisible ? View.VISIBLE : View.GONE);

        // Click listeners
        holder.btnEdit.setOnClickListener(v -> {
            FormularioEquipoTrabajoFragment formServidor = FormularioEquipoTrabajoFragment.newInstance(equipoTrabajo);
            formServidor.show(fragmentManager, formServidor.getTag());
        });

        holder.btnDelete.setOnClickListener(v -> {
            AlertDialog.Builder confirmation = new AlertDialog.Builder(context);
            confirmation.setTitle("Advertencia")
                    .setMessage("¿Estás seguro de qué deseas eliminar el equipo de trabajo: \""+equipoTrabajo.nombre+"\"?")
                    .setCancelable(false)
                    .setPositiveButton("Eliminar", (dialog, which) -> {
                        equipoTrabajo.eliminar(equipoTrabajo.id, response -> {
                            ((Activity) context).finish();
                            ((Activity) context).overridePendingTransition(0, 0);
                            ((Activity) context).startActivity(((Activity) context).getIntent());
                            ((Activity) context).overridePendingTransition(0, 0);
                        }, error -> {
                            Toast.makeText(context, "Error al eliminar equipo de trabajo.", Toast.LENGTH_SHORT).show();
                        });
                    }).setNegativeButton("Cancelar", (dialog, which) -> {
                dialog.dismiss();
            });

            confirmation.create().show();
        });
    }
}

