package com.example.servercraft.ViewModels.BaseDatos;

import android.util.Log;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.BaseDatos;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.JSONArray;
import org.json.JSONException;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class FormularioBaseDatosViewModel extends ViewModel {
    private MutableLiveData<ArrayList<BaseDatos>> mBaseDatos;

    // Constructor
    public FormularioBaseDatosViewModel() {
        mBaseDatos = new MutableLiveData<>();

        loadHTTPBaseDatosList();
    }

    // Getters
    public MutableLiveData<ArrayList<BaseDatos>> getBaseDatosList() {
        return mBaseDatos;
    }

    // Setters
    private void loadHTTPBaseDatosList() {
        BaseDatos baseDatos = new BaseDatos();

        baseDatos.listar(100,1,null,null, response -> {
            try {
                JSONArray httpBaseDatos = response.getJSONArray("bases_de_datos");

                ArrayList<BaseDatos> objectBaseDatos = mapBaseDatosIntoObject(httpBaseDatos);

                mBaseDatos.setValue(objectBaseDatos);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<BaseDatos> mapBaseDatosIntoObject(JSONArray httpBase) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type BaseDatosArray = new TypeToken<ArrayList<BaseDatos>>() {
        }.getType();
        ArrayList<BaseDatos> baseDatosList = gson.fromJson(httpBase.toString(), BaseDatosArray);

        return baseDatosList;
    }
}
