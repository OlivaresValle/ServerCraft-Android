package com.example.servercraft.UI.Ubicacion.Paises;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.example.servercraft.Models.Pais;
import com.example.servercraft.Utils.AdapterMaterialSpinner;
import com.example.servercraft.ViewModels.Ubicacion.Pais.FormularioPais.FormularioPaisViewModel;
import com.example.servercraft.ViewModels.Ubicacion.Pais.FormularioPais.FormularioPaisViewModelFactory;
import com.example.servercraft.databinding.FragmentFormularioPaisBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class FormularioPaisFragment extends BottomSheetDialogFragment implements Validator.ValidationListener {
    private static final String ARG_PAIS = "ubicacion/pais";
    private FormularioPaisViewModel formularioViewModel;
    private FragmentFormularioPaisBinding binding;
    private View root;
    private Validator validator;

    // Validaciones
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etPaisNombre;

    public static FormularioPaisFragment newInstance(@Nullable Pais pais) {
        FormularioPaisFragment fragment = new FormularioPaisFragment();

        if (pais != null) {
            Bundle bundle = new Bundle();
            Gson gson = new Gson();

            bundle.putString(ARG_PAIS, gson.toJson(pais));
            fragment.setArguments(bundle);
        }
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Pais pais = null;

        if (getArguments() != null) {
            Gson gson = new Gson();
            pais = gson.fromJson(getArguments().getString(ARG_PAIS), Pais.class);
        }

        formularioViewModel = new ViewModelProvider(this, new FormularioPaisViewModelFactory(pais)).get(FormularioPaisViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentFormularioPaisBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.setValidationListener(this);

        // Intanciamiento de los campos a validar
        etPaisNombre = binding.etPaisNombre;

        // Loading Status
        binding.clLoadingPaisForm.setVisibility(View.VISIBLE);
        binding.lSubmitPaisForm.setVisibility(View.GONE);

        // Configuración de botón de creación
        binding.btnCrearPais.setOnClickListener(v -> {
            validator.validate();

        });

        // Modificar título en caso de que se esté intentando editar un servidor
        if (formularioViewModel != null && formularioViewModel.hasPais()) {
            binding.tvLoadingPais.setText("Editar país");
            binding.btnCrearPais.setText("Actualizar país");
        }

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Solo cargar datos cuando el formulario sea de edición.
        if (formularioViewModel != null && formularioViewModel.hasPais()) {
            formularioViewModel.getPais().observe(getViewLifecycleOwner(), pais -> {
                binding.etPaisNombre.setText(pais.nombre);
            });
        }

        binding.clLoadingPaisForm.setVisibility(View.GONE);
        binding.lSubmitPaisForm.setVisibility(View.VISIBLE);
    }

    private void updatePaisList() {
        getActivity().finish();
        getActivity().overridePendingTransition(0, 0);
        getActivity().startActivity(getActivity().getIntent());
        getActivity().overridePendingTransition(0, 0);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onValidationSucceeded() {
        // Se muestra animación de cargando
        binding.clLoadingPaisForm.setVisibility(View.VISIBLE);
        binding.lSubmitPaisForm.setVisibility(View.GONE);
        binding.tvLoadingPais.setText("Guardando datos");

        // Manejo de datos
        Gson gson = new Gson();
        Pais pais = new Pais();

        pais.nombre = binding.etPaisNombre.getText().toString();

        JSONObject request = new JSONObject();

        try {
            request.put("pais", new JSONObject(gson.toJson(pais)));
        } catch (JSONException ignored) {
        }

        if (formularioViewModel != null && formularioViewModel.hasPais()) {
            pais.actualizar(formularioViewModel.getPais().getValue().id, request, response -> {
                binding.clLoadingPaisForm.setVisibility(View.GONE);
                binding.lSubmitPaisForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updatePaisList();
            }, error -> {
                binding.clLoadingPaisForm.setVisibility(View.GONE);
                binding.lSubmitPaisForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al actualizar país", Toast.LENGTH_SHORT).show();
            });
        } else {
            pais.crear(request, response -> {
                binding.clLoadingPaisForm.setVisibility(View.GONE);
                binding.lSubmitPaisForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updatePaisList();
            }, error -> {
                binding.clLoadingPaisForm.setVisibility(View.GONE);
                binding.lSubmitPaisForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al crear país", Toast.LENGTH_SHORT).show();
            });
        }
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        AdapterMaterialSpinner.onErrorChanges(errors);
    }
}