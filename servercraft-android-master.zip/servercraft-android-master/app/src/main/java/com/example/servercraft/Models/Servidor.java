package com.example.servercraft.Models;

import androidx.annotation.Nullable;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.servercraft.Utils.ServercraftApplication;
import org.json.JSONObject;
import java.util.Map;

public class Servidor extends BaseHTTP {
    // Constants
    private final String ENDPOINT_BASE = super.HOST + "/servidor";

    // Attributes
    public int id;
    public String nombre;
    public String ip;
    public String usuarioIngreso;
    public String contrasenaIngreso;
    public int disco;
    public int memoria;
    public boolean poseeGarantia;
    public String nombreContactoMantencion;
    public String telefonoContactoMantencion;
    public String emailContactoMantencion;
    public int idRack;
    public int idTipoServidor;
    public int idSistemaOperativo;
    public Integer idBaseDatos = null;

    // Relaciones
    public BaseDatos baseDatos;
    public SistemaOperativo sistemaOperativo;
    public TipoServidor tipoServidor;
    public Rack rack;

    public boolean isFullyVisible = false;

    // To String
    @Override
    public String toString() {
        return nombre;
    }

    // Equals
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        Servidor that = (Servidor) o;

        return id == that.id;
    }

    // Constructor
    public Servidor() {
        super();
    }

    // HTTP Methods
    public void listar (int por_pagina, int pagina, @Nullable String q,@Nullable JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_INDEX = ENDPOINT_BASE + "?limit="+ por_pagina +"&page=" + pagina +  (q != null ? "&q="+q : "");

        JsonObjectRequest listarServidor = new JsonObjectRequest(Request.Method.GET, ENDPOINT_INDEX, request, onSuccess, onError){
            @Override
            public Map<String, String> getHeaders() {
                return Servidor.super.headers;
            }
        };

        queue.add(listarServidor);
    }

    public void obtener (int idServidor, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/" + idServidor;

        JsonObjectRequest obtenerServidor = new JsonObjectRequest (Request.Method.GET, ENDPOINT_DETAIL, null, onSuccess, onError){
            @Override
            public Map<String, String> getHeaders() {
                return Servidor.super.headers;
            }
        };

        queue.add(obtenerServidor);
    }

    public void crear (JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());

        JsonObjectRequest crearServidor = new JsonObjectRequest (Request.Method.POST, ENDPOINT_BASE, request, onSuccess, onError){
            @Override
            public Map<String, String> getHeaders() {
                return Servidor.super.headers;
            }
        };

        queue.add(crearServidor);
    }

    public void actualizar (int idServidor, JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/" + idServidor;

        JsonObjectRequest actualizarServidor = new JsonObjectRequest (Request.Method.PUT, ENDPOINT_DETAIL, request, onSuccess, onError){
            @Override
            public Map<String, String> getHeaders() {
                return Servidor.super.headers;
            }
        };

        queue.add(actualizarServidor);
    }

    public void eliminar (int idServidor, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/" + idServidor;

        JsonObjectRequest eliminarServidor = new JsonObjectRequest (Request.Method.DELETE, ENDPOINT_DETAIL, null, onSuccess, onError){
            @Override
            public Map<String, String> getHeaders() {
                return Servidor.super.headers;
            }
        };

        queue.add(eliminarServidor);
    }
}
