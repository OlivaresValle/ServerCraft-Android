package com.example.servercraft.UI.Ubicacion;

import android.content.Context;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.servercraft.UI.Ubicacion.Paises.ListarPaisesFragment;
import com.example.servercraft.UI.Ubicacion.Regiones.ListarRegionesFragment;

public class UbicacionPagerAdapter extends FragmentPagerAdapter {
    private static final String[] TAB_TITLES = new String[]{"Paises", "Regiones"};

    public UbicacionPagerAdapter(Context context, FragmentManager fm){super(fm);}

    @Override
    public Fragment getItem(int position){
        Fragment fragment = null;

        switch (position){
            case 0:
                fragment = ListarPaisesFragment.newInstance();
                break;
            case 1:
                fragment = ListarRegionesFragment.newInstance();
                break;
        }
        return fragment;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return TAB_TITLES[position];
    }

    @Override
    public int getCount() {
        return 2;
    }
}
