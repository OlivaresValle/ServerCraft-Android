package com.example.servercraft.ViewModels.ClientesProveedores.EquiposProveedores;

import android.util.Log;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.servercraft.Models.EquipoProveedor;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Objects;

public class ListarEquiposProveedoresViewModel extends ViewModel {
    private MutableLiveData<ArrayList<EquipoProveedor>> mEquipoProveedorList;
    public ArrayList<EquipoProveedor> arEquipoProveedor = new ArrayList<>();

    public boolean cargandoDatos = false;
    public boolean blPuedeCargarMas = true;
    public int pagina = 0;
    public String busqueda = "";

    // Constructor
    public ListarEquiposProveedoresViewModel() {
        mEquipoProveedorList = new MutableLiveData<>();
        loadHTTPEquipoProveedorList();

    }

    // Getters
    public MutableLiveData<ArrayList<EquipoProveedor>> getEquipoProveedorList() {
        return mEquipoProveedorList;
    }

    // Setters
    public void loadHTTPEquipoProveedorList() {
        if (blPuedeCargarMas) {
            EquipoProveedor equipoProveedor = new EquipoProveedor();

            pagina = pagina + 1;

            if (arEquipoProveedor.size() != 0) {
                arEquipoProveedor.add(null);
                mEquipoProveedorList.setValue(arEquipoProveedor);
            }

            equipoProveedor.listar(10, pagina, busqueda, null, response -> {
                try {
                    JSONArray httpLenguajes = response.getJSONArray("equipos_encargados");
                    JSONObject httpMeta = response.getJSONObject("meta");

                    Log.d("Resultados",httpLenguajes.toString());

                    arEquipoProveedor.removeIf(Objects::isNull);


                    if (httpMeta.getInt("last_page") == pagina) {
                        blPuedeCargarMas = false;
                    }

                    arEquipoProveedor.addAll(mapEquiposIntoObject(httpLenguajes));

                    mEquipoProveedorList.setValue(arEquipoProveedor);

                    cargandoDatos = false;
                } catch (JSONException e) {
                    Log.e("Listar leng", e.toString());
                }
            }, error -> Log.d("Error de ", error.toString()));
        }
    }


    private ArrayList<EquipoProveedor> mapEquiposIntoObject(JSONArray httpEquipos) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type EquipoProveedorArray = new TypeToken<ArrayList<EquipoProveedor>>() {
        }.getType();
        ArrayList<EquipoProveedor> equiposList = gson.fromJson(httpEquipos.toString(), EquipoProveedorArray);

        return equiposList;
    }
}
