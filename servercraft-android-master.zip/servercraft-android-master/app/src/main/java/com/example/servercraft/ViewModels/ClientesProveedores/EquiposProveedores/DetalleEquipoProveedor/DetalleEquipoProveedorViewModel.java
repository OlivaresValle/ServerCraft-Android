package com.example.servercraft.ViewModels.ClientesProveedores.EquiposProveedores.DetalleEquipoProveedor;

import android.util.Log;
import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.EquipoProveedor;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.json.JSONException;
import org.json.JSONObject;

public class DetalleEquipoProveedorViewModel extends ViewModel {
    private MutableLiveData<Integer> equipoId;
    private MutableLiveData<EquipoProveedor> mEquipo;

    // Constructor
    public DetalleEquipoProveedorViewModel(@Nullable Integer idEquipo) {
        equipoId = new MutableLiveData<>();
        mEquipo = new MutableLiveData<>();

        if (idEquipo != null) {
            equipoId.setValue(idEquipo);
            loadHTTPEquipoProveedor();
        }
    }

    // Getters
    public MutableLiveData<EquipoProveedor> getEquipoProveedor() {
        return mEquipo;
    }

    public Integer getEquipoProveedorId() {
        return equipoId.getValue();
    }

    public boolean hasEquipoProveedor() {
        return equipoId.getValue() != null;
    }

    // Setters
    private void loadHTTPEquipoProveedor() {
        EquipoProveedor equipoProveedor = new EquipoProveedor();

        equipoProveedor.obtener(equipoId.getValue(), response -> {
            try {
                JSONObject httpEquipo = response.getJSONObject("equipo_encargado");
                EquipoProveedor objectEquipo = mapEquipoIntoObject(httpEquipo);

                mEquipo.setValue(objectEquipo);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private EquipoProveedor mapEquipoIntoObject(JSONObject httpEquipo) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        EquipoProveedor equipoProveedor = gson.fromJson(httpEquipo.toString(), EquipoProveedor.class);

        return equipoProveedor;
    }
}
