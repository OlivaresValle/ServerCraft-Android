package com.example.servercraft.UI.ServidoresRacksSalas.Racks;

import android.os.Bundle;
import androidx.lifecycle.ViewModelProvider;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.example.servercraft.Models.Rack;
import com.example.servercraft.ViewModels.ServidoresRacksSalas.Racks.DetalleRack.DetalleRackViewModel;
import com.example.servercraft.ViewModels.ServidoresRacksSalas.Racks.DetalleRack.DetalleRackViewModelFactory;
import com.example.servercraft.databinding.FragmentDetalleRackBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;

public class DetalleRackFragment extends BottomSheetDialogFragment {
    private static final String ARG_RACK = "id_rack";
    private DetalleRackViewModel detalleViewModel;
    private FragmentDetalleRackBinding binding;

    public static DetalleRackFragment newInstance(Rack rack) {
        DetalleRackFragment fragment = new DetalleRackFragment();
        Bundle bundle = new Bundle();
        Gson gson = new Gson();

        bundle.putString(ARG_RACK, gson.toJson(rack));
        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Rack rack = null;

        if (getArguments() != null) {
            Gson gson = new Gson();
            String jsonRack = getArguments().getString(ARG_RACK);

            rack = gson.fromJson(jsonRack, Rack.class);
        }

        detalleViewModel = new ViewModelProvider(this, new DetalleRackViewModelFactory(rack)).get(DetalleRackViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentDetalleRackBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Observador de consulta HTTP
        detalleViewModel.getRack().observe(getViewLifecycleOwner(), rack -> {
            // Cargar datos cuando estén disponibles
            binding.tvRackTitle.setText(rack.nombre);
            binding.tvRDSala.setText(rack.sala.nombre);
            binding.tvRDRegion.setText(rack.sala.region.nombre);
            binding.tvRDPais.setText(rack.sala.region.pais.nombre);

            // Ocultar vista de "cargando..."
            binding.clLoadingRack.setVisibility(View.GONE);
            binding.llRackData.setVisibility(View.VISIBLE);
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}