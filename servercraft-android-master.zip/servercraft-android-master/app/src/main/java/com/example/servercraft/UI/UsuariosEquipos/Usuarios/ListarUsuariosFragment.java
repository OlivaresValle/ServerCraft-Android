package com.example.servercraft.UI.UsuariosEquipos.Usuarios;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.servercraft.UI.LenguajesProgramacion.LenguajeItemAdapter;
import com.example.servercraft.databinding.FragmentListarUsuariosBinding;
import com.example.servercraft.R;
import com.example.servercraft.ViewModels.UsuariosEquipos.Usuarios.ListarUsuariosViewModel;

public class ListarUsuariosFragment extends Fragment {
    public ListarUsuariosViewModel listarViewModel;
    private FragmentListarUsuariosBinding binding;
    private UsuarioItemAdapter usuarioItemAdapter;
    private boolean iniciado = false;

    public static ListarUsuariosFragment newInstance() {
        return new ListarUsuariosFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        listarViewModel = new ViewModelProvider(this).get(ListarUsuariosViewModel.class);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        Activity parent = getActivity();
        binding = FragmentListarUsuariosBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Elements
        ProgressBar spinner = parent.findViewById(R.id.pbHttpUsuariosLoading);
        RecyclerView rvUsuarios = binding.rvUsuarios;

        if (iniciado) {
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etBuscarUsuario.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arUsuario.clear();
            listarViewModel.loadHTTPUserList();
            usuarioItemAdapter = null;
            binding.pbHttpLoadingUsuario.setVisibility(View.VISIBLE);
        }

        // Configuración inicial de elementos
        spinner.setVisibility(View.INVISIBLE);
        rvUsuarios.setLayoutManager(new LinearLayoutManager(root.getContext()));
        binding.pbHttpLoadingUsuario.setVisibility(View.INVISIBLE);

        // Observador de consulta HTTP
        listarViewModel.getUserList().observe(getViewLifecycleOwner(), usuarios -> {
            iniciado = true;
            if (usuarioItemAdapter == null) {
                usuarioItemAdapter = new UsuarioItemAdapter(root.getContext(), usuarios, getChildFragmentManager());

                binding.rvUsuarios.setAdapter(usuarioItemAdapter);
                spinner.setVisibility(View.INVISIBLE);
                binding.pbHttpLoadingUsuario.setVisibility(View.INVISIBLE);
            } else {
                binding.rvUsuarios.post(new Runnable() {
                    public void run() {
                        usuarioItemAdapter.notifyItemRangeChanged(0,usuarios.size() - 1);
                    }
                });
            }
        });

        binding.btnBuscarUsuario.setOnClickListener(v -> {
            Log.d("Boton", "apretado");
            binding.pbHttpLoadingUsuario.setVisibility(View.VISIBLE);
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etBuscarUsuario.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arUsuario.clear();
            listarViewModel.loadHTTPUserList();
            usuarioItemAdapter = null;
        });

        // Listener de scroll para cargar siguientes páginas
        binding.rvUsuarios.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                if (!listarViewModel.cargandoDatos) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == listarViewModel.arUsuario.size() - 1) {
                        listarViewModel.cargandoDatos = true;
                        listarViewModel.loadHTTPUserList();
                    }
                }
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
