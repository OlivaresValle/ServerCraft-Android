package com.example.servercraft.ViewModels.MenuPrincipalUsuario;

import android.util.Log;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.servercraft.Models.Usuario;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONException;
import org.json.JSONObject;

public class PerfilViewModel extends ViewModel {
    private MutableLiveData<Usuario> mUsuario;

    // Constructor
    public PerfilViewModel() {
        mUsuario = new MutableLiveData<>();

        loadHTTPUsuario();
    }

    // Getters
    public MutableLiveData<Usuario> getUser() {
        return mUsuario;
    }

    // Setters
    private void loadHTTPUsuario() {
        Usuario usuario = new Usuario();

        usuario.obtener(0, response -> {
            try {
                JSONObject httpUsuario = response.getJSONObject("usuario");
                Usuario objectUsuario = mapUsuarioIntoObject(httpUsuario);

                mUsuario.setValue(objectUsuario);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()), null);
    }

    private Usuario mapUsuarioIntoObject(JSONObject httpUsuario) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Usuario usuario = gson.fromJson(httpUsuario.toString(), Usuario.class);

        return usuario;
    }
}