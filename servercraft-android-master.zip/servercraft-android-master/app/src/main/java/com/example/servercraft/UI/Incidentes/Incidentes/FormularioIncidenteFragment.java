package com.example.servercraft.UI.Incidentes.Incidentes;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;
import com.chivorn.smartmaterialspinner.SmartMaterialSpinner;
import com.example.servercraft.Models.EquipoTrabajo;
import com.example.servercraft.Models.EstadoIncidente;
import com.example.servercraft.Models.Incidente;
import com.example.servercraft.Models.Instancia;
import com.example.servercraft.Models.TipoProblema;
import com.example.servercraft.Models.TipoSolucion;
import com.example.servercraft.Utils.AdapterMaterialSpinner;
import com.example.servercraft.ViewModels.Incidentes.Incidentes.DetalleIncidente.DetalleIncidenteViewModel;
import com.example.servercraft.ViewModels.Incidentes.Incidentes.DetalleIncidente.DetalleIncidenteViewModelFactory;
import com.example.servercraft.ViewModels.Incidentes.Incidentes.FormularioIncidenteViewModel;
import com.example.servercraft.databinding.FragmentFormularioIncidenteBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class FormularioIncidenteFragment extends BottomSheetDialogFragment implements Validator.ValidationListener {
    // Configuración de View Model
    private static final String ARG_ID_INCIDENTE = "id_incidente";
    private DetalleIncidenteViewModel detalleViewModel;
    private FormularioIncidenteViewModel formularioViewModel;
    private FragmentFormularioIncidenteBinding binding;
    private View root;
    private Validator validator;

    // Validaciones
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etDescripcion;

    // Spinners
    @NotEmpty(message = "Campo obligatorio")
    SmartMaterialSpinner<Instancia> spInstancias;

    @NotEmpty(message = "Campo obligatorio")
    SmartMaterialSpinner<TipoProblema> spTipoIncidente;

    SmartMaterialSpinner<EstadoIncidente> spEstados;
    SmartMaterialSpinner<TipoSolucion> spTipoSolucion;
    SmartMaterialSpinner<EquipoTrabajo> spEquipoEncargado;

    public static FormularioIncidenteFragment newInstance(@Nullable Integer idIncidente) {
        FormularioIncidenteFragment fragment = new FormularioIncidenteFragment();

        if (idIncidente != null) {
            Bundle bundle = new Bundle();

            bundle.putInt(ARG_ID_INCIDENTE, idIncidente);
            fragment.setArguments(bundle);
        }

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            Integer incidenteId = getArguments().getInt(ARG_ID_INCIDENTE);

            detalleViewModel = new ViewModelProvider(this, new DetalleIncidenteViewModelFactory(incidenteId)).get(DetalleIncidenteViewModel.class);
        }

        formularioViewModel = new ViewModelProvider(this).get(FormularioIncidenteViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentFormularioIncidenteBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.registerAdapter(SmartMaterialSpinner.class, new AdapterMaterialSpinner());
        validator.setValidationListener(this);

        // Inicialización de variables
        etDescripcion = binding.etDetalleIncidenteForm;

        // Loading Status
        binding.clLoadingIncidenteForm.setVisibility(View.VISIBLE);
        binding.lSubmitIncidenteForm.setVisibility(View.GONE);

        // Referenciación de Spinners
        spInstancias = binding.spSistemaIncidente;
        spEstados = binding.spEstadoIncidente;
        spTipoIncidente = binding.spTipoProblema;
        spTipoSolucion = binding.spTipoSolucion;
        spEquipoEncargado = binding.spEquipoSolucion;

        // Inicialización de spinners con API.
        formularioViewModel.getInstanciaList().observe(getViewLifecycleOwner(), instancias -> {
            spInstancias.setItem(instancias);
        });

        formularioViewModel.getEstadoIncidenteList().observe(getViewLifecycleOwner(), estados -> {
            spEstados.setItem(estados);
        });

        formularioViewModel.getTipoProblemaList().observe(getViewLifecycleOwner(), tiposProblema -> {
            spTipoIncidente.setItem(tiposProblema);
        });

        formularioViewModel.getTipoSolucionList().observe(getViewLifecycleOwner(), tiposSolucion -> {
            spTipoSolucion.setItem(tiposSolucion);
        });

        formularioViewModel.getEquipoTrabajoList().observe(getViewLifecycleOwner(), equipos -> {
            spEquipoEncargado.setItem(equipos);
        });

        // Limpieza de errores al seleccionar
        spInstancias.setOnItemSelectedListener(AdapterMaterialSpinner.clearSpinner(spInstancias));
        spTipoIncidente.setOnItemSelectedListener(AdapterMaterialSpinner.clearSpinner(spTipoIncidente));

        // Configuración de botón de creación
        binding.btnCrearIncidente.setOnClickListener(v -> {
            validator.validate();
        });

        // Modificar título en caso de que se esté intentando editar un servidor
        if (detalleViewModel != null && detalleViewModel.hasIncidente()) {
            binding.tvIncidenteFormTitle.setText("Editar incidente");
            binding.btnCrearIncidente.setText("Actualizar incidente");
        }

        return root;
    }

    private void updateIncidenteList() {
        getActivity().finish();
        getActivity().overridePendingTransition(0, 0);
        getActivity().startActivity(getActivity().getIntent());
        getActivity().overridePendingTransition(0, 0);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Solo cargar datos cuando el formulario sea de edición.
        if (detalleViewModel != null && detalleViewModel.hasIncidente()) {
            // Mostrar Controles de actualizacion
            binding.lControlEstadoIncidente.setVisibility(View.VISIBLE);
            binding.dividerSolucion.setVisibility(View.VISIBLE);
            binding.lSolucionIncidenteInfo.setVisibility(View.VISIBLE);

            // Cargar información
            detalleViewModel.getIncidente().observe(getViewLifecycleOwner(), incidente -> {
                // 1 - Información General
                formularioViewModel.getInstanciaList().observe(getViewLifecycleOwner(), instancias -> {
                    spInstancias.setSelection(instancias.indexOf(incidente.instanciaSistema));
                });

                formularioViewModel.getEstadoIncidenteList().observe(getViewLifecycleOwner(), estadosIncidente -> {
                    spEstados.setSelection(estadosIncidente.indexOf(incidente.estadoIncidente));
                });

                // 2 - Información Problema
                formularioViewModel.getTipoProblemaList().observe(getViewLifecycleOwner(), tiposProblema -> {
                    spTipoIncidente.setSelection(tiposProblema.indexOf(incidente.tipoProblema));
                });

                binding.etDetalleIncidenteForm.setText(incidente.detalleProblema);

                // 3 - Información Solución
                formularioViewModel.getTipoSolucionList().observe(getViewLifecycleOwner(), tiposSolucion -> {
                    spTipoSolucion.setSelection(tiposSolucion.indexOf(incidente.tipoSolucion));
                });

                formularioViewModel.getEquipoTrabajoList().observe(getViewLifecycleOwner(), equipos -> {
                    spEquipoEncargado.setSelection(equipos.indexOf(incidente.equipoTrabajo));
                });

                binding.etDetalleSolucion.setText(incidente.detalleSolucion);
                binding.clLoadingIncidenteForm.setVisibility(View.GONE);
                binding.lSubmitIncidenteForm.setVisibility(View.VISIBLE);
            });
        } else {
            binding.clLoadingIncidenteForm.setVisibility(View.GONE);
            binding.lSubmitIncidenteForm.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onValidationSucceeded() {
        // Se muestra animación de cargando
        binding.clLoadingIncidenteForm.setVisibility(View.VISIBLE);
        binding.lSubmitIncidenteForm.setVisibility(View.GONE);
        binding.tvLoadingIncidenteForm.setText("Guardando datos");

        // Manejo de datos
        Gson gson = new Gson();
        Incidente incidente = new Incidente();

        // 1 - Información General
        incidente.idSistema = spInstancias.getSelectedItem().id;

        try {
            incidente.idEstadoIncidente = spEstados.getSelectedItem().id;
        } catch (Exception e) {
            incidente.idEstadoIncidente = null;
        }

        // 2 - Información Problema
        incidente.idTipoProblema = spTipoIncidente.getSelectedItem().id;
        incidente.detalleProblema = binding.etDetalleIncidenteForm.getText().toString();

        // 3 - Información Solución
        try {
            incidente.idTipoSolucion = spTipoSolucion.getSelectedItem().id;
        } catch (Exception e) {
            incidente.idTipoSolucion = null;
        }

        try {
            incidente.idEquipoSolucion = spEquipoEncargado.getSelectedItem().id;
        } catch (Exception e) {
            incidente.idEquipoSolucion = null;
        }

        incidente.detalleSolucion = binding.etDetalleSolucion.getText().toString();

        JSONObject request = new JSONObject();

        try {
            request.put("incidente", new JSONObject(gson.toJson(incidente)));
        } catch (JSONException ignored) {
        }

        if (detalleViewModel != null && detalleViewModel.hasIncidente()) {
            incidente.actualizar(detalleViewModel.getIncidenteId(), request, response -> {
                binding.clLoadingIncidenteForm.setVisibility(View.GONE);
                binding.lSubmitIncidenteForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateIncidenteList();
            }, error -> {
                binding.clLoadingIncidenteForm.setVisibility(View.GONE);
                binding.lSubmitIncidenteForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al actualizar incidente", Toast.LENGTH_SHORT).show();
            });
        } else {
            incidente.crear(request, response -> {
                binding.clLoadingIncidenteForm.setVisibility(View.GONE);
                binding.lSubmitIncidenteForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateIncidenteList();
            }, error -> {
                binding.clLoadingIncidenteForm.setVisibility(View.GONE);
                binding.lSubmitIncidenteForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al crear incidente", Toast.LENGTH_SHORT).show();
            });
        }
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        AdapterMaterialSpinner.onErrorChanges(errors);
    }
}