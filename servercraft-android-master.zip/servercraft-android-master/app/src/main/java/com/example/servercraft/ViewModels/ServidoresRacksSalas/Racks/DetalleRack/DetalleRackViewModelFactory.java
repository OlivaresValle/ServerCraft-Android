package com.example.servercraft.ViewModels.ServidoresRacksSalas.Racks.DetalleRack;

import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import com.example.servercraft.Models.Rack;

public class DetalleRackViewModelFactory implements ViewModelProvider.Factory {
    private Rack mRack;

    public DetalleRackViewModelFactory(@Nullable Rack rack) {
        if (rack != null) {
            this.mRack = rack;
        }
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        return (T) new DetalleRackViewModel(mRack);
    }
}
