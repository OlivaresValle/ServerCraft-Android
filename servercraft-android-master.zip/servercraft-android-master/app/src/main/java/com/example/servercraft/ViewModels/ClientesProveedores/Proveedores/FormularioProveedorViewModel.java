package com.example.servercraft.ViewModels.ClientesProveedores.Proveedores;

import androidx.lifecycle.ViewModel;

public class FormularioProveedorViewModel extends ViewModel {
}
