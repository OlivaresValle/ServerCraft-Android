package com.example.servercraft.UI.MenuPrincipalUsuario.PerfilUsuario;

import com.example.servercraft.Models.UsuarioResponse;
import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.PUT;
import retrofit2.http.Part;

public interface ImageInterface {
    @Multipart
    @PUT("/usuario/imagen")
    Call<UsuarioResponse> uploadImage(@Part MultipartBody.Part image, @Header("Authorization") String auth);
}
