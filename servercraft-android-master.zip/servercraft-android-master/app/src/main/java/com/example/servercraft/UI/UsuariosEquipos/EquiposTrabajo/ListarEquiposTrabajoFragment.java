package com.example.servercraft.UI.UsuariosEquipos.EquiposTrabajo;

import android.app.Activity;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import com.example.servercraft.R;
import com.example.servercraft.ViewModels.UsuariosEquipos.EquiposTrabajo.ListarEquiposTrabajoViewModel;
import com.example.servercraft.databinding.FragmentListarEquiposTrabajoBinding;

public class ListarEquiposTrabajoFragment extends Fragment {
    public ListarEquiposTrabajoViewModel listarViewModel;
    private FragmentListarEquiposTrabajoBinding binding;
    public EquipoTrabajoItemAdapter equipoTrabajoAdapter;
    private boolean iniciado = false;

    public static ListarEquiposTrabajoFragment newInstance() {
        return new ListarEquiposTrabajoFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        listarViewModel = new ViewModelProvider(this).get(ListarEquiposTrabajoViewModel.class);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        Activity parent = getActivity();
        binding = FragmentListarEquiposTrabajoBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Elements
        ProgressBar spinner = parent.findViewById(R.id.pbHttpUsuariosLoading);
        RecyclerView rvEquiposTrabajo = binding.rvEquiposTrabajo;

        // Configuración inicial de elementos
        spinner.setVisibility(View.INVISIBLE);
        rvEquiposTrabajo.setLayoutManager(new LinearLayoutManager(root.getContext()));
        binding.pbHttpLoadingEquipo.setVisibility(View.INVISIBLE);

        if (iniciado) {
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etBuscarEquipo.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arEquipo.clear();
            listarViewModel.loadHTTPEquiposList();
            equipoTrabajoAdapter = null;
            binding.pbHttpLoadingEquipo.setVisibility(View.VISIBLE);
        }

        // Observador de consulta HTTP
        listarViewModel.getEquiposTrabajoList().observe(getViewLifecycleOwner(), equiposTrabajo -> {

            if (equipoTrabajoAdapter == null) {
                equipoTrabajoAdapter = new EquipoTrabajoItemAdapter(root.getContext(), equiposTrabajo, getChildFragmentManager());

                binding.rvEquiposTrabajo.setAdapter(equipoTrabajoAdapter);
                spinner.setVisibility(View.INVISIBLE);
                binding.pbHttpLoadingEquipo.setVisibility(View.INVISIBLE);
            } else {
                binding.rvEquiposTrabajo.post(new Runnable() {
                    public void run() {
                        equipoTrabajoAdapter.notifyItemRangeChanged(0,equiposTrabajo.size() - 1);
                    }
                });
            }
        });

        binding.btnBuscarEquipo.setOnClickListener(v -> {
            binding.pbHttpLoadingEquipo.setVisibility(View.VISIBLE);
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etBuscarEquipo.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arEquipo.clear();
            listarViewModel.loadHTTPEquiposList();
            equipoTrabajoAdapter = null;
        });

        // Listener de scroll para cargar siguientes páginas


        binding.rvEquiposTrabajo.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                if (!listarViewModel.cargandoDatos) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == listarViewModel.arEquipo.size() - 1) {
                        listarViewModel.cargandoDatos = true;
                        listarViewModel.loadHTTPEquiposList();
                    }
                }
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}