package com.example.servercraft.UI.LenguajesProgramacion;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.servercraft.Models.Lenguaje;
import com.example.servercraft.Utils.UserInfo;
import com.example.servercraft.ViewModels.LenguajesProgramacion.ListarLenguajesViewModel;
import com.example.servercraft.databinding.ActivityListarLenguajesProgramacionBinding;

import java.util.ArrayList;
import java.util.Objects;

public class ListarLenguajesProgramacion extends AppCompatActivity {
    private ActivityListarLenguajesProgramacionBinding binding;
    private ListarLenguajesViewModel listarViewModel;
    private LenguajeItemAdapter lenguajeItemAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Configuración binding de layout
        binding = ActivityListarLenguajesProgramacionBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        int userRol = new UserInfo().getUserRol();

        // Configuración View Model
        listarViewModel = new ViewModelProvider(this).get(ListarLenguajesViewModel.class);

        // Botón flotante
        binding.btnCrearLP.setOnClickListener(v -> {
            FormularioLenguajeProgramacionFragment form = FormularioLenguajeProgramacionFragment.newInstance(null);
            form.show(getSupportFragmentManager(), form.getTag());
        });

        // Toolbar
        Toolbar toolbar = binding.tbMainLenguajes.tbMain;
        ImageView ivToolbarImage = binding.tbMainLenguajes.ivTbUsuario;
        TextView tvTbTitle = binding.tbMainLenguajes.tvTbTitle;

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        if (userRol == 3) {
            binding.btnCrearLP.setVisibility(View.GONE);
        }

        binding.tbMainLenguajes.cvUsuarioMenuPrincipal.setVisibility(View.GONE);
        tvTbTitle.setText("Lenguajes de programación");
        toolbar.setContentInsetStartWithNavigation(0);
        toolbar.setNavigationOnClickListener(v -> {
            finish();
        });

        // Elements
        binding.pbHttpLoadingLenguajes.setVisibility(View.VISIBLE);
        binding.rvLenguajes.setLayoutManager(new LinearLayoutManager(this));

        // Observador de consulta HTTP
        listarViewModel.getLenguajeList().observe(this, lenguajes -> {
            Log.d("Lenguajes", lenguajes.toString());
            if (lenguajeItemAdapter == null) {
                lenguajeItemAdapter = new LenguajeItemAdapter(this, lenguajes, getSupportFragmentManager());

                binding.rvLenguajes.setAdapter(lenguajeItemAdapter);

                binding.pbHttpLoadingLenguajes.setVisibility(View.INVISIBLE);
            } else {
                binding.rvLenguajes.post(new Runnable() {
                    public void run() {
                        lenguajeItemAdapter.notifyItemInserted(lenguajes.size() - 1);
                    }
                });
            }
        });

        binding.btnBuscarLenguaje.setOnClickListener(v -> {
            Log.d("Boton", "apretado");
            binding.pbHttpLoadingLenguajes.setVisibility(View.VISIBLE);
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etLenguajeBusqueda.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arLenguajes.clear();
            listarViewModel.loadHTTPLenguajeList();
            lenguajeItemAdapter = null;
        });

        // Listener de scroll para cargar siguientes páginas
        binding.rvLenguajes.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                if (!listarViewModel.cargandoDatos) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == listarViewModel.arLenguajes.size() - 1) {
                        listarViewModel.cargandoDatos = true;
                        listarViewModel.loadHTTPLenguajeList();
                    }
                }
            }
        });
    }
}