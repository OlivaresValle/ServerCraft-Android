package com.example.servercraft.ViewModels.ServidoresRacksSalas.Servidores;

import android.util.Log;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.BaseDatos;
import com.example.servercraft.Models.Rack;
import com.example.servercraft.Models.SistemaOperativo;
import com.example.servercraft.Models.TipoServidor;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.JSONArray;
import org.json.JSONException;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class FormularioServidorViewModel extends ViewModel {
    private MutableLiveData<ArrayList<TipoServidor>> mTiposServidor;
    private MutableLiveData<ArrayList<SistemaOperativo>> mSistemasOperativos;
    private MutableLiveData<ArrayList<BaseDatos>> mBasesDatos;
    private MutableLiveData<ArrayList<Rack>> mRacks;

    // Constructor
    public FormularioServidorViewModel() {
        mTiposServidor = new MutableLiveData<>();
        mSistemasOperativos = new MutableLiveData<>();
        mBasesDatos = new MutableLiveData<>();
        mRacks = new MutableLiveData<>();

        loadHTTPTipoServidorList();
        loadHTTPSistemaOperativoList();
        loadHTTPBDList();
        loadHTTPRackList();
    }

    // Getters
    public MutableLiveData<ArrayList<TipoServidor>> getTipoServidorList() {
        return mTiposServidor;
    }

    public MutableLiveData<ArrayList<SistemaOperativo>> getSistemaOperativoList() {
        return mSistemasOperativos;
    }

    public MutableLiveData<ArrayList<BaseDatos>> getBaseDatosList() {
        return mBasesDatos;
    }

    public MutableLiveData<ArrayList<Rack>> getRackList() {
        return mRacks;
    }

    // Setters

    // 1 - Tipos de Servidores
    private void loadHTTPTipoServidorList() {
        TipoServidor tipo = new TipoServidor();

        tipo.listar(null, response -> {
            try {
                JSONArray httpTipos = response.getJSONArray("tipos_servidor");

                ArrayList<TipoServidor> objectTipos = mapTipoIntoObject(httpTipos);

                mTiposServidor.setValue(objectTipos);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<TipoServidor> mapTipoIntoObject(JSONArray httpTipos) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type TipoServidorArray = new TypeToken<ArrayList<TipoServidor>>() {
        }.getType();
        ArrayList<TipoServidor> tiposList = gson.fromJson(httpTipos.toString(), TipoServidorArray);

        return tiposList;
    }

    // 2 - Sistemas Operativos
    private void loadHTTPSistemaOperativoList() {
        SistemaOperativo sistema = new SistemaOperativo();

        sistema.listar(null, response -> {
            try {
                JSONArray httpSistemasOperativos = response.getJSONArray("sistemas_operativos");

                ArrayList<SistemaOperativo> objectSOList = mapSOIntoObject(httpSistemasOperativos);

                mSistemasOperativos.setValue(objectSOList);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<SistemaOperativo> mapSOIntoObject(JSONArray httpSO) {
        Gson gson = new Gson();

        Type SistemaOperativoArray = new TypeToken<ArrayList<SistemaOperativo>>() {
        }.getType();
        ArrayList<SistemaOperativo> soList = gson.fromJson(httpSO.toString(), SistemaOperativoArray);

        return soList;
    }

    // 3 - Bases de Datos
    private void loadHTTPBDList() {
        BaseDatos baseDatos = new BaseDatos();

        baseDatos.listar(1000,1,null,null, response -> {
            try {
                JSONArray httpBaseDatos = response.getJSONArray("bases_de_datos");

                ArrayList<BaseDatos> objectBDList = mapBDIntoObject(httpBaseDatos);

                mBasesDatos.setValue(objectBDList);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<BaseDatos> mapBDIntoObject(JSONArray httpBD) {
        Gson gson = new Gson();

        Type BDArray = new TypeToken<ArrayList<BaseDatos>>() {
        }.getType();
        ArrayList<BaseDatos> soList = gson.fromJson(httpBD.toString(), BDArray);

        return soList;
    }

    // 4 - Racks
    private void loadHTTPRackList() {
        Rack rack = new Rack();

        rack.listar(1000,1,null,null, response -> {
            try {
                JSONArray httpRacks = response.getJSONArray("racks");

                ArrayList<Rack> objectRacks = mapRacksIntoObject(httpRacks);

                mRacks.setValue(objectRacks);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<Rack> mapRacksIntoObject(JSONArray httpRack) {
        Gson gson = new Gson();

        Type RackArray = new TypeToken<ArrayList<Rack>>() {
        }.getType();
        ArrayList<Rack> soList = gson.fromJson(httpRack.toString(), RackArray);

        return soList;
    }
}
