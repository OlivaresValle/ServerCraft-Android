package com.example.servercraft.UI.ClientesProveedores.Proveedores;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;
import com.example.servercraft.Models.ProveedorSistema;
import com.example.servercraft.ViewModels.ClientesProveedores.Proveedores.DetalleProveedor.DetalleProveedorViewModel;
import com.example.servercraft.ViewModels.ClientesProveedores.Proveedores.DetalleProveedor.DetalleProveedorViewModelFactory;
import com.example.servercraft.ViewModels.ClientesProveedores.Proveedores.FormularioProveedorViewModel;
import com.example.servercraft.databinding.FragmentFormularioProveedorBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.Email;
import com.mobsandgeeks.saripaar.annotation.Length;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Pattern;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class FormularioProveedorFragment extends BottomSheetDialogFragment  implements Validator.ValidationListener {
    private static final String ARG_ID_PROVEEDOR = "id_proveedor";
    private DetalleProveedorViewModel detalleViewModel;
    private FormularioProveedorViewModel formularioViewModel;
    private FragmentFormularioProveedorBinding binding;
    private Validator validator;
    private View root;

    // Validaciones
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etNombreProveedorCrear;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etNombreRepresentanteCrear;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    @Email(message = "email inválido ")
    EditText etEmail;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    @Length(min = 9, max = 9, message = "Debe ser de 9 dígitos")
    EditText etTelefono;


    public static FormularioProveedorFragment newInstance(@Nullable Integer idProveedor) {
        FormularioProveedorFragment fragment = new FormularioProveedorFragment();

        if (idProveedor != null) {
            Bundle bundle = new Bundle();

            bundle.putInt(ARG_ID_PROVEEDOR, idProveedor);
            fragment.setArguments(bundle);
        }

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            Integer proveedorId = getArguments().getInt(ARG_ID_PROVEEDOR);

            detalleViewModel = new ViewModelProvider(this, new DetalleProveedorViewModelFactory(proveedorId)).get(DetalleProveedorViewModel.class);
        }

        formularioViewModel = new ViewModelProvider(this).get(FormularioProveedorViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentFormularioProveedorBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.setValidationListener(this);

        // Intanciamiento de los campos a validar
        etNombreProveedorCrear = binding.etProveedorNombre;
        etNombreRepresentanteCrear = binding.etProveedorRepresentante;
        etEmail = binding.etProveedorEmail;
        etTelefono= binding.etProveedorPhone;

        // Loading Status
        binding.clLoadingProveedorForm.setVisibility(View.VISIBLE);
        binding.lSubmitProveedorForm.setVisibility(View.GONE);

        // Configuración de botón de creación
        binding.btnCrearProveedorForm.setOnClickListener(v -> {
            validator.validate();

        });

        // Modificar título en caso de que se esté intentando editar un servidor
        if (detalleViewModel != null && detalleViewModel.hasProveedor()) {
            binding.tvProveedorFormTitle.setText("Editar proveedor");
            binding.btnCrearProveedorForm.setText("Actualizar proveedor");
        }

        return root;
    }

    private void updateProveedorList() {
        getActivity().finish();
        getActivity().overridePendingTransition(0, 0);
        getActivity().startActivity(getActivity().getIntent());
        getActivity().overridePendingTransition(0, 0);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Solo cargar datos cuando el formulario sea de edición.
        if (detalleViewModel != null && detalleViewModel.hasProveedor()) {
            detalleViewModel.getProveedor().observe(getViewLifecycleOwner(), proveedorSistema -> {
                binding.etProveedorNombre.setText(proveedorSistema.nombre);
                binding.etProveedorRepresentante.setText(proveedorSistema.nombreRepresentante);
                binding.etProveedorEmail.setText(proveedorSistema.emailContacto);
                binding.etProveedorPhone.setText(proveedorSistema.telefonoContacto);

                binding.clLoadingProveedorForm.setVisibility(View.GONE);
                binding.lSubmitProveedorForm.setVisibility(View.VISIBLE);
            });
        } else {
            binding.clLoadingProveedorForm.setVisibility(View.GONE);
            binding.lSubmitProveedorForm.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onValidationSucceeded() {
        // Se muestra animación de cargando
        binding.clLoadingProveedorForm.setVisibility(View.VISIBLE);
        binding.lSubmitProveedorForm.setVisibility(View.GONE);
        binding.tvLoadingProveedorForm.setText("Guardando datos");

        // Manejo de datos
        Gson gson = new Gson();
        ProveedorSistema proveedorSistema = new ProveedorSistema();

        proveedorSistema.nombre = binding.etProveedorNombre.getText().toString();
        proveedorSistema.nombreRepresentante = binding.etProveedorRepresentante.getText().toString();
        proveedorSistema.emailContacto = binding.etProveedorEmail.getText().toString();
        proveedorSistema.telefonoContacto = binding.etProveedorPhone.getText().toString();

        JSONObject request = new JSONObject();

        try {
            request.put("proveedorSistema", new JSONObject(gson.toJson(proveedorSistema)));
        } catch (JSONException ignored) {
        }

        if (detalleViewModel != null && detalleViewModel.hasProveedor()) {
            proveedorSistema.actualizar(detalleViewModel.getProveedorId(), request, response -> {
                binding.clLoadingProveedorForm.setVisibility(View.GONE);
                binding.lSubmitProveedorForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateProveedorList();
            }, error -> {
                binding.clLoadingProveedorForm.setVisibility(View.GONE);
                binding.lSubmitProveedorForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al actualizar proveedor de sistema", Toast.LENGTH_SHORT).show();
            });
        } else {
            proveedorSistema.crear(request, response -> {
                binding.clLoadingProveedorForm.setVisibility(View.GONE);
                binding.lSubmitProveedorForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateProveedorList();
            }, error -> {
                binding.clLoadingProveedorForm.setVisibility(View.GONE);
                binding.lSubmitProveedorForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al crear proveedor de sistema", Toast.LENGTH_SHORT).show();
            });
        }

    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(getContext());

            // Display error messages ;)
            if (view instanceof EditText) {
                ((EditText) view).setError(message);
            } else {
                Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show();
            }
        }

    }
}