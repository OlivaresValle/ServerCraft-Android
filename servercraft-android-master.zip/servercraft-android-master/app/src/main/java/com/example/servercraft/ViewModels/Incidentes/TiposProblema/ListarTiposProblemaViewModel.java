package com.example.servercraft.ViewModels.Incidentes.TiposProblema;

import android.util.Log;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.TipoProblema;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Objects;

public class ListarTiposProblemaViewModel extends ViewModel {
    private MutableLiveData<ArrayList<TipoProblema>> mTiposProblema;
    public ArrayList<TipoProblema> arTipoProblema= new ArrayList<>();

    public boolean cargandoDatos = false;
    public boolean blPuedeCargarMas = true;
    public int pagina = 0;
    public String busqueda = "";

    // Constructor
    public ListarTiposProblemaViewModel() {
        mTiposProblema = new MutableLiveData<>();
        loadHTTPTiposList();
    }

    // Getters
    public MutableLiveData<ArrayList<TipoProblema>> getTipoProblemaList() {
        return mTiposProblema;
    }

    // Setters
    public void loadHTTPTiposList() {
        if (blPuedeCargarMas) {
            TipoProblema tipoProblema = new TipoProblema();

            pagina = pagina + 1;

            if (arTipoProblema.size() != 0) {
                arTipoProblema.add(null);
                mTiposProblema.setValue(arTipoProblema);
            }

            tipoProblema.listar(10, pagina, busqueda, null, response -> {
                try {
                    JSONArray httpTipoProblema = response.getJSONArray("tipos_problema");
                    JSONObject httpMeta = response.getJSONObject("meta");

                    Log.d("Resultados",httpTipoProblema.toString());

                    arTipoProblema.removeIf(Objects::isNull);

                    if (httpMeta.getInt("last_page") == pagina) {
                        blPuedeCargarMas = false;
                    }

                    arTipoProblema.addAll(mapTiposIntoObject(httpTipoProblema));

                    mTiposProblema.setValue(arTipoProblema);
                    cargandoDatos = false;
                } catch (JSONException e) {
                    Log.e("Listar leng", e.toString());
                }
            }, error -> Log.d("Error de ", error.toString()));
        }
    }


    private ArrayList<TipoProblema> mapTiposIntoObject(JSONArray httpTipos) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type TipoProblemaArray = new TypeToken<ArrayList<TipoProblema>>() {
        }.getType();
        ArrayList<TipoProblema> tipoList = gson.fromJson(httpTipos.toString(), TipoProblemaArray);

        return tipoList;
    }
}
