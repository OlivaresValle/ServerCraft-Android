package com.example.servercraft.Utils;

import android.content.Context;
import android.content.SharedPreferences;

public class Preferences {
    // Attributes
    private String storeName;
    SharedPreferences preferences;

    // Constructor
    public Preferences(String store) {
        this.storeName = store;
    }

    // Methods
    public void addValue(String key, String value) {
        SharedPreferences.Editor editor;

        preferences = ServercraftApplication.getAppContext().getSharedPreferences(storeName, Context.MODE_PRIVATE);
        editor = preferences.edit();

        editor.putString(key, value);
        editor.commit();
    }

    public void addValue(String key, int value) {
        SharedPreferences.Editor editor;

        preferences = ServercraftApplication.getAppContext().getSharedPreferences(storeName, Context.MODE_PRIVATE);
        editor = preferences.edit();

        editor.putInt(key, value);
        editor.commit();
    }

    public String getString(String key) {
        preferences = ServercraftApplication.getAppContext().getSharedPreferences(storeName, Context.MODE_PRIVATE);
        String value = preferences.getString(key, "");

        return value;
    }

    public int getInt(String key) {
        preferences = ServercraftApplication.getAppContext().getSharedPreferences(storeName, Context.MODE_PRIVATE);
        int value = preferences.getInt(key, 0);

        return value;
    }
}
