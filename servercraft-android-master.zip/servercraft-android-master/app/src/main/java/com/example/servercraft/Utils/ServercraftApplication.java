package com.example.servercraft.Utils;

import android.app.Application;
import android.content.Context;

public class ServercraftApplication extends Application {
    private static ServercraftApplication mInstance;

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
    }

    public static synchronized ServercraftApplication getInstance() {
        return mInstance;
    }

    public static Context getAppContext() {
        return mInstance.getApplicationContext();
    }
}
