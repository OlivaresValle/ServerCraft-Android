package com.example.servercraft.ViewModels.UsuariosEquipos.UnidadesNegocio;

import android.util.Log;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.servercraft.Models.Lenguaje;
import com.example.servercraft.Models.UnidadNegocio;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Objects;

public class ListarUnidadesNegocioViewModel extends ViewModel {
    private MutableLiveData<ArrayList<UnidadNegocio>> mUnidadesList;
    public ArrayList<UnidadNegocio> arUnidad = new ArrayList<>();

    public boolean cargandoDatos = false;
    public boolean blPuedeCargarMas = true;
    public int pagina = 0;
    public String busqueda = "";

    // Constructor
    public ListarUnidadesNegocioViewModel() {
        mUnidadesList = new MutableLiveData<>();


        loadHTTPUnidadesList();
    }

    // Getters
    public MutableLiveData<ArrayList<UnidadNegocio>> getUnidadesNegocioList() {
        return mUnidadesList;
    }

    // Setters
    public void loadHTTPUnidadesList() {
        if (blPuedeCargarMas) {
            UnidadNegocio unidadNegocio = new UnidadNegocio();

            pagina = pagina + 1;

            if (arUnidad.size() != 0) {
                arUnidad.add(null);
                mUnidadesList.setValue(arUnidad);
            }

        unidadNegocio.listar(10,pagina,busqueda,null, response -> {
            try {
                JSONArray httpUnidades = response.getJSONArray("unidades_negocio");
                JSONObject httpMeta = response.getJSONObject("meta");

                Log.d("Resultados",httpUnidades.toString());

                arUnidad.removeIf(Objects::isNull);


                if (httpMeta.getInt("last_page") == pagina) {
                    blPuedeCargarMas = false;
                }

                arUnidad.addAll(mapUnidadesIntoObject(httpUnidades));

                mUnidadesList.setValue(arUnidad);

                cargandoDatos = false;
            } catch (JSONException e) {
                Log.e("Listar leng", e.toString());
            }
        }, error -> Log.d("Error de ", error.toString()));
        }
    }

    private ArrayList<UnidadNegocio> mapUnidadesIntoObject(JSONArray httpUnidades) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type UnidadNegocioArray = new TypeToken<ArrayList<UnidadNegocio>>() {}.getType();
        ArrayList<UnidadNegocio> unidadNegocioList = gson.fromJson(httpUnidades.toString(), UnidadNegocioArray);

        return unidadNegocioList;
    }
}
