package com.example.servercraft.UI.Sistema;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.servercraft.Utils.UserInfo;
import com.example.servercraft.ViewModels.Sistema.ListarSistemasViewModel;
import com.example.servercraft.databinding.ActivityListarSistemasBinding;

import java.util.Objects;

public class ListarSistemas extends AppCompatActivity {
    private ActivityListarSistemasBinding binding;
    private ListarSistemasViewModel listarViewModel;
    private SistemaItemAdapter sistemaAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        // Configuración binding layout
        binding = ActivityListarSistemasBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        int userRol = new UserInfo().getUserRol();

        // Configuración View Model
        listarViewModel = new ViewModelProvider(this).get(ListarSistemasViewModel.class);

        // Botón flotante
        binding.btnCrearSistema.setOnClickListener(v -> {
            FormularioSistemaFragment formularioSistemaFragment = FormularioSistemaFragment.newInstance(null);
            formularioSistemaFragment.show(getSupportFragmentManager(), formularioSistemaFragment.getTag());
        });

        // Toolbar
        Toolbar toolbar = binding.tbMainSistema.tbMain;
        TextView tbTitle = binding.tbMainSistema.tvTbTitle;
        TextView tbDescripcion = binding.tbMainSistema.tvTbDescripcion;

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        if (userRol == 3 || userRol == 4) {
            binding.btnCrearSistema.setVisibility(View.GONE);
        }

        binding.tbMainSistema.cvUsuarioMenuPrincipal.setVisibility(View.GONE);
        tbTitle.setText("Sistemas");
        tbDescripcion.setText("Gestionar sistemas o aplicaciones");
        toolbar.setContentInsetStartWithNavigation(0);
        toolbar.setNavigationOnClickListener(v -> {
            finish();
        });

        // Elements
        binding.pbHttpLoadingSistema.setVisibility(View.VISIBLE);
        binding.rvSistema.setLayoutManager(new LinearLayoutManager(this));

        // Observador de consulta HTTP
        listarViewModel.getSistemaList().observe(this, sistema -> {
            if (sistemaAdapter == null) {
                sistemaAdapter = new SistemaItemAdapter(this, sistema, getSupportFragmentManager());

                binding.rvSistema.setAdapter(sistemaAdapter);

                binding.pbHttpLoadingSistema.setVisibility(View.INVISIBLE);
            } else {
                binding.rvSistema.post(new Runnable() {
                    public void run() {
                        sistemaAdapter.notifyItemRangeChanged(0,sistema.size());
                    }
                });
            }
        });

        // Listener de scroll para cargar siguientes páginas
        binding.rvSistema.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                if (!listarViewModel.cargandoDatos) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == listarViewModel.arSistema.size() - 1) {
                        listarViewModel.cargandoDatos = true;
                        listarViewModel.loadHTTPSistemaList();
                    }
                }
            }
        });

        binding.btnBuscarSistema.setOnClickListener(v -> {
            binding.pbHttpLoadingSistema.setVisibility(View.VISIBLE);
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etSistemaBusqueda.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arSistema.clear();
            listarViewModel.loadHTTPSistemaList();
            sistemaAdapter = null;
        });
    }
}