package com.example.servercraft.ViewModels.ServidoresRacksSalas.Servidores.DetalleServidor;

import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

public class DetalleServidorViewModelFactory implements ViewModelProvider.Factory {
    private Integer mServerId;

    public DetalleServidorViewModelFactory(@Nullable Integer serverId) {
        if (serverId != null) {
            this.mServerId = serverId;
        }
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        return (T) new DetalleServidorViewModel(mServerId);
    }
};