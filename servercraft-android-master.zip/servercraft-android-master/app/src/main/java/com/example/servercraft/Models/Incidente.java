package com.example.servercraft.Models;

import androidx.annotation.Nullable;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.servercraft.Utils.ServercraftApplication;
import org.json.JSONObject;
import java.util.Map;
import java.util.Objects;

public class Incidente extends BaseHTTP {
    // Constants
    private final String ENDPOINT_BASE = super.HOST + "/incidente";

    // Attributes
    public int id;
    public String fechaHoraProblema;
    public String fechaHoraSolucion;
    public String detalleProblema;
    @Nullable
    public String detalleSolucion;
    public int idTipoProblema;
    public Integer idTipoSolucion;
    public Integer idEquipoSolucion;
    public int idSistema;
    public Integer idEstadoIncidente;

    // Relations
    public Instancia instanciaSistema;
    public TipoProblema tipoProblema;
    public TipoSolucion tipoSolucion;
    public EstadoIncidente estadoIncidente;
    public EquipoTrabajo equipoTrabajo;

    public boolean isFullyVisible = false;

    // Constructor
    public Incidente() {
        super();
    }

    // To String
    @Override
    public String toString() {
        return String.valueOf(id);
    }

    // Equals
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Incidente that = (Incidente) o;

        return id == that.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(ENDPOINT_BASE, id, fechaHoraProblema, estadoIncidente);
    }

    // HTTP Methods
    public void listar (int por_pagina, int pagina, @Nullable String q, @Nullable JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_INDEX = ENDPOINT_BASE + "?limit="+ por_pagina +"&page=" + pagina +  (q != null && !q.equals("") ? "&q="+ q : "") ;

        JsonObjectRequest listarIncidentes = new JsonObjectRequest(Request.Method.GET, ENDPOINT_INDEX, request, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() {
                return Incidente.super.headers;
            }
        };

        queue.add(listarIncidentes);
    }

    public void obtener(int idIncidente, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/" + idIncidente;

        JsonObjectRequest obtenerIncidente = new JsonObjectRequest(Request.Method.GET, ENDPOINT_DETAIL, null, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() {
                return Incidente.super.headers;
            }
        };

        queue.add(obtenerIncidente);
    }

    public void crear(JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());

        JsonObjectRequest crearIncidente = new JsonObjectRequest(Request.Method.POST, ENDPOINT_BASE, request, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() {
                return Incidente.super.headers;
            }
        };

        queue.add(crearIncidente);
    }

    public void actualizar(int idIncidente, JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/" + idIncidente;

        JsonObjectRequest actualizarIncidente = new JsonObjectRequest(Request.Method.PUT, ENDPOINT_DETAIL, request, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() {
                return Incidente.super.headers;
            }
        };

        queue.add(actualizarIncidente);
    }

    public void eliminar(int idIncidente, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/" + idIncidente;

        JsonObjectRequest eliminarIncidente = new JsonObjectRequest(Request.Method.DELETE, ENDPOINT_DETAIL, null, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() {
                return Incidente.super.headers;
            }
        };

        queue.add(eliminarIncidente);
    }
}
