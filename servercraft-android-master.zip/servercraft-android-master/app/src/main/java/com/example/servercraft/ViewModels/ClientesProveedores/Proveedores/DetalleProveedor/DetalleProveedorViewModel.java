package com.example.servercraft.ViewModels.ClientesProveedores.Proveedores.DetalleProveedor;

import android.util.Log;
import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.ProveedorSistema;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.json.JSONException;
import org.json.JSONObject;

public class DetalleProveedorViewModel extends ViewModel {
    private MutableLiveData<Integer> proveedorId;
    private MutableLiveData<ProveedorSistema> mProveedor;

    // Constructor
    public DetalleProveedorViewModel(@Nullable Integer idProveedor) {
        proveedorId = new MutableLiveData<>();
        mProveedor = new MutableLiveData<>();

        if (idProveedor != null) {
            proveedorId.setValue(idProveedor);

            loadHTTPProveedor();
        }
    }

    // Getters
    public MutableLiveData<ProveedorSistema> getProveedor() {
        return mProveedor;
    }

    public Integer getProveedorId() {
        return proveedorId.getValue();
    }

    public boolean hasProveedor() {
        return proveedorId.getValue() != null;
    }

    // Setters
    private void loadHTTPProveedor() {
        ProveedorSistema proveedorSistema = new ProveedorSistema();

        proveedorSistema.obtener(proveedorId.getValue(), response -> {
            try {
                JSONObject httpProveedor = response.getJSONObject("proveedor");
                ProveedorSistema objectProveedor = mapProveedorIntoObject(httpProveedor);

                mProveedor.setValue(objectProveedor);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ProveedorSistema mapProveedorIntoObject(JSONObject httpProveedor) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        ProveedorSistema proveedorSistema = gson.fromJson(httpProveedor.toString(), ProveedorSistema.class);

        return proveedorSistema;
    }
}
