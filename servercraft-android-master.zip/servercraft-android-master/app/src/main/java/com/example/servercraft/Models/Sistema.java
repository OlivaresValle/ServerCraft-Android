package com.example.servercraft.Models;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.servercraft.Utils.ServercraftApplication;
import org.jetbrains.annotations.Nullable;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;

public class Sistema extends BaseHTTP {
    // Constants
    private final String ENDPOINT_BASE = super.HOST + "/sistema";

    // Attributes
    public int id;
    public String nombre;
    @Nullable
    public Integer idServidorBd;
    public int idEquipoProveedor;
    public int idNivelSeguridad;
    @Nullable
    public Integer idNivelSensibilidad;
    public int idUsuario;

    // Relations
    public Usuario usuario;
    public Servidor servidorDb;
    public NivelSeguridad nivelSeguridad;
    public NivelSensibilidad nivelSensibilidad;
    public EquipoProveedor equipoProveedor;
    @Nullable
    public ArrayList<Lenguaje> lenguajes;
    @Nullable
    public ArrayList<Instancia> instancias;
    @Nullable
    public ArrayList<DocumentoSistema> documentos;
    @Nullable
    public ArrayList<ServicioWeb> servicioWeb;

    // HTTP Policy
    DefaultRetryPolicy policy = new DefaultRetryPolicy(
            DefaultRetryPolicy.DEFAULT_TIMEOUT_MS * 1000,
            DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
            DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

    public boolean isFullyVisible = false;

    // Constructor
    public Sistema() {
        super();
    }

    // To String
    @Override
    public String toString() {
        return nombre;
    }

    // Equals
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Sistema that = (Sistema) o;

        return id == that.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(ENDPOINT_BASE, id, nombre);
    }

    public String obtenerEstado(ArrayList<Instancia> instancias) {
        int var = 3;
        String estado = "";
        if (instancias.size() == 0) {
            return "No posee Instancias";
        }
        for (int a = 0; a < instancias.size(); a++) {
            if (instancias.get(a).estadoInstancia.id <= var) {
                estado = instancias.get(a).estadoInstancia.nombre;
                var = instancias.get(a).estadoInstancia.id;
            }
        }
        return estado;
    }

    // HTTP Methods
    public void listar (int por_pagina, int pagina, @Nullable String q, @Nullable JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_INDEX = ENDPOINT_BASE + "?limit="+ por_pagina +"&page=" + pagina +  (q != null ? "&q="+q : "");

        JsonObjectRequest listarSistemas = new JsonObjectRequest(Request.Method.GET, ENDPOINT_INDEX, request, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() {
                return Sistema.super.headers;
            }
        };

        listarSistemas.setRetryPolicy(policy);
        queue.add(listarSistemas);
    }

    public void obtener(int id, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/" + id;

        JsonObjectRequest obtenerSistema = new JsonObjectRequest(Request.Method.GET, ENDPOINT_DETAIL, null, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() {
                return Sistema.super.headers;
            }
        };

        obtenerSistema.setRetryPolicy(policy);
        queue.add(obtenerSistema);
    }

    public void crear(JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());

        JsonObjectRequest crearSistema = new JsonObjectRequest(Request.Method.POST, ENDPOINT_BASE, request, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() {
                return Sistema.super.headers;
            }
        };

        crearSistema.setRetryPolicy(policy);
        queue.add(crearSistema);
    }


    public void actualizar(int idSistema, JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/" + idSistema;

        JsonObjectRequest actualizarSistema = new JsonObjectRequest(Request.Method.PUT, ENDPOINT_DETAIL, request, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() {
                return Sistema.super.headers;
            }
        };

        actualizarSistema.setRetryPolicy(policy);
        queue.add(actualizarSistema);
    }

    public void eliminar(int id, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/" + id;

        JsonObjectRequest eliminarSistema = new JsonObjectRequest(Request.Method.DELETE, ENDPOINT_DETAIL, null, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() {
                return Sistema.super.headers;
            }
        };

        eliminarSistema.setRetryPolicy(policy);
        queue.add(eliminarSistema);
    }
}
