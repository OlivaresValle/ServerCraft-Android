package com.example.servercraft.ViewModels.Incidentes.Incidentes.DetalleIncidente;

import android.util.Log;
import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.Incidente;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.json.JSONException;
import org.json.JSONObject;

public class DetalleIncidenteViewModel extends ViewModel {
    private MutableLiveData<Integer> incidenteId;
    private MutableLiveData<Incidente> mIncidente;

    // Constructor
    public DetalleIncidenteViewModel(@Nullable Integer idIncidente) {
        incidenteId = new MutableLiveData<>();
        mIncidente = new MutableLiveData<>();

        if (idIncidente != null) {
            incidenteId.setValue(idIncidente);
            loadHTTPIncidente();
        }
    }

    // Getters
    public MutableLiveData<Incidente> getIncidente() {
        return mIncidente;
    }

    public Integer getIncidenteId() {
        return incidenteId.getValue();
    }

    public boolean hasIncidente() {
        return incidenteId.getValue() != null;
    }

    // Setters
    private void loadHTTPIncidente() {
        Incidente incidente = new Incidente();

        incidente.obtener(incidenteId.getValue(), response -> {
            try {
                JSONObject httpIncidente = response.getJSONObject("incidente");
                Incidente objectIncidente = mapIncidenteIntoObject(httpIncidente);

                mIncidente.setValue(objectIncidente);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private Incidente mapIncidenteIntoObject(JSONObject httpIncidente) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Incidente incidente = gson.fromJson(httpIncidente.toString(), Incidente.class);

        return incidente;
    }
}
