package com.example.servercraft.ViewModels.UsuariosEquipos.Usuarios.DetalleUsuario;

import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

public class DetalleUsuarioViewModelFactory implements ViewModelProvider.Factory {
    private Integer mUsuarioId;

    public DetalleUsuarioViewModelFactory(@Nullable Integer usuarioId) {
        if (usuarioId != null) {
            this.mUsuarioId = usuarioId;
        }
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        return (T) new DetalleUsuarioViewModel(mUsuarioId);
    }
}


