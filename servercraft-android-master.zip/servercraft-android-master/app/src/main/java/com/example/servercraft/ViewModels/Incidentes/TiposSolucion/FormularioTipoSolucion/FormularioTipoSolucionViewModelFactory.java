package com.example.servercraft.ViewModels.Incidentes.TiposSolucion.FormularioTipoSolucion;

import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import com.example.servercraft.Models.TipoSolucion;

public class FormularioTipoSolucionViewModelFactory implements ViewModelProvider.Factory {
    private TipoSolucion mTipoSolucion;

    public FormularioTipoSolucionViewModelFactory(@Nullable TipoSolucion tipoSolucion) {
        if (tipoSolucion != null) {
            this.mTipoSolucion = tipoSolucion;
        }
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        return (T) new FormularioTipoSolucionViewModel(mTipoSolucion);
    }
}
