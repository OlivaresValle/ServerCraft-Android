package com.example.servercraft.UI.BaseDeDatos;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;
import com.example.servercraft.Models.BaseDatos;
import com.example.servercraft.ViewModels.BaseDatos.DetalleBaseDatos.DetalleBaseDatosViewModel;
import com.example.servercraft.ViewModels.BaseDatos.DetalleBaseDatos.DetalleBaseDatosViewModelFactory;
import com.example.servercraft.databinding.FragmentFormularioBaseDatosBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class FormularioBaseDatosFragment extends BottomSheetDialogFragment implements Validator.ValidationListener {
    // Configuración de View Model
    private static final String ARG_BD = "base_de_datos";
    private DetalleBaseDatosViewModel detalleViewModel;
    private FragmentFormularioBaseDatosBinding binding;
    private Validator validator;
    private View root;

    // Validaciones
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etBaseDatosNombreCrear;

    public static FormularioBaseDatosFragment newInstance(@Nullable BaseDatos baseDatos) {
        FormularioBaseDatosFragment fragment = new FormularioBaseDatosFragment();

        if (baseDatos != null) {
            Bundle bundle = new Bundle();
            Gson gson = new Gson();

            bundle.putString(ARG_BD, gson.toJson(baseDatos));
            fragment.setArguments(bundle);
        }

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            Gson gson = new Gson();
            String jsonBaseDatos = getArguments().getString(ARG_BD);
            BaseDatos baseDatos = gson.fromJson(jsonBaseDatos, BaseDatos.class);

            detalleViewModel = new ViewModelProvider(this, new DetalleBaseDatosViewModelFactory(baseDatos)).get(DetalleBaseDatosViewModel.class);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentFormularioBaseDatosBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.setValidationListener(this);

        // Intanciamiento de los campos a validar
        etBaseDatosNombreCrear = binding.etBaseDatosNombreCrear;

        // Loading Status
        binding.clLoadingBaseDatosCrearForm.setVisibility(View.VISIBLE);
        binding.lSubmitBaseDatosForm.setVisibility(View.GONE);

        // Configuración de botón de creación
        binding.btnCrearLP.setOnClickListener(v -> {
            validator.validate();
        });

        // Modificar título en caso de que se esté intentando editar una Base de Datos
        if (detalleViewModel != null && detalleViewModel.hasBaseDatos()) {
            binding.tvBaseDatosCrearFormTitle.setText("Editar base de datos");
            binding.btnCrearLP.setText("Actualizar base de datos");
        }

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Solo cargar datos cuando el formulario sea de edición.
        if (detalleViewModel != null && detalleViewModel.hasBaseDatos()) {
            detalleViewModel.getBaseDatos().observe(getViewLifecycleOwner(), baseDatos -> {
                binding.etBaseDatosNombreCrear.setText(baseDatos.nombre);
                binding.clLoadingBaseDatosCrearForm.setVisibility(View.GONE);
                binding.lSubmitBaseDatosForm.setVisibility(View.VISIBLE);
            });
        } else {
            binding.clLoadingBaseDatosCrearForm.setVisibility(View.GONE);
            binding.lSubmitBaseDatosForm.setVisibility(View.VISIBLE);
        }
    }

    private void updateBaseDatosList() {
        getActivity().finish();
        getActivity().overridePendingTransition(0, 0);
        getActivity().startActivity(getActivity().getIntent());
        getActivity().overridePendingTransition(0, 0);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onValidationSucceeded() {
        // Se muestra animación de cargando
        binding.clLoadingBaseDatosCrearForm.setVisibility(View.VISIBLE);
        binding.lSubmitBaseDatosForm.setVisibility(View.GONE);
        binding.tvLoadingBaseDatosCrear.setText("Guardando datos");

        // Manejo de datos
        Gson gson = new Gson();

        BaseDatos baseDatos = new BaseDatos();
        baseDatos.nombre = binding.etBaseDatosNombreCrear.getText().toString();

        JSONObject request = new JSONObject();

        try {
            request.put("baseDatos", new JSONObject(gson.toJson(baseDatos)));
        } catch (JSONException ignored) {
        }

        if (detalleViewModel != null && detalleViewModel.hasBaseDatos()) {
            baseDatos.actualizar(detalleViewModel.getBaseDatos().getValue().id, request, response -> {
                binding.clLoadingBaseDatosCrearForm.setVisibility(View.GONE);
                binding.lSubmitBaseDatosForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateBaseDatosList();
            }, error -> {
                binding.clLoadingBaseDatosCrearForm.setVisibility(View.GONE);
                binding.lSubmitBaseDatosForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al actualizar base de datos", Toast.LENGTH_SHORT).show();
            });
        } else {
            baseDatos.crear(request, response -> {
                binding.clLoadingBaseDatosCrearForm.setVisibility(View.GONE);
                binding.lSubmitBaseDatosForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateBaseDatosList();
            }, error -> {
                binding.clLoadingBaseDatosCrearForm.setVisibility(View.GONE);
                binding.lSubmitBaseDatosForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al crear base de datos", Toast.LENGTH_SHORT).show();
            });
        }
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(getContext());

            // Display error messages ;)
            if (view instanceof EditText) {
                ((EditText) view).setError(message);
            } else {
                Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show();
            }
        }
    }
}