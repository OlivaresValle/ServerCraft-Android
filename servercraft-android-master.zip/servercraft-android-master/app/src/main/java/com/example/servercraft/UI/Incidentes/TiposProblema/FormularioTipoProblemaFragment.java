package com.example.servercraft.UI.Incidentes.TiposProblema;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;
import com.example.servercraft.Models.TipoProblema;
import com.example.servercraft.Utils.AdapterMaterialSpinner;
import com.example.servercraft.ViewModels.Incidentes.TiposProblema.FormularioTipoProblema.FormularioTipoProblemaViewModel;
import com.example.servercraft.ViewModels.Incidentes.TiposProblema.FormularioTipoProblema.FormularioTipoProblemaViewModelFactory;
import com.example.servercraft.databinding.FragmentFormularioTipoProblemaBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class FormularioTipoProblemaFragment extends BottomSheetDialogFragment implements Validator.ValidationListener {
    // Configuración de View Model
    private static final String ARG_TIPO_PROBLEMA = "tipo_problema";
    private FormularioTipoProblemaViewModel formularioViewModel;
    private FragmentFormularioTipoProblemaBinding binding;
    private Validator validator;
    private View root;

    // Validaciones
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etTipoProblema;

    public static FormularioTipoProblemaFragment newInstance(@Nullable TipoProblema tipoProblema) {
        FormularioTipoProblemaFragment fragment = new FormularioTipoProblemaFragment();

        if (tipoProblema != null) {
            Bundle bundle = new Bundle();
            Gson gson = new Gson();

            bundle.putString(ARG_TIPO_PROBLEMA, gson.toJson(tipoProblema));
            fragment.setArguments(bundle);
        }

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TipoProblema tipoProblema = null;

        if (getArguments() != null) {
            Gson gson = new Gson();

            tipoProblema = gson.fromJson(getArguments().getString(ARG_TIPO_PROBLEMA), TipoProblema.class);
        }

        formularioViewModel = new ViewModelProvider(this, new FormularioTipoProblemaViewModelFactory(tipoProblema)).get(FormularioTipoProblemaViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentFormularioTipoProblemaBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.setValidationListener(this);

        // Intanciamiento de los campos a validar
        etTipoProblema = binding.etTipoProblema;

        // Loading Status
        binding.clLoadingTipoProblemaForm.setVisibility(View.VISIBLE);
        binding.lSubmitTipoProblemaForm.setVisibility(View.GONE);

        // Configuración de botón de creación
        binding.btnCrearTipoProblemaForm.setOnClickListener(v -> {
            validator.validate();
        });

        // Modificar título en caso de que se esté intentando editar un servidor
        if (formularioViewModel != null && formularioViewModel.hasTipoProblema()) {
            binding.tvTipoProblemaFormTitle.setText("Editar tipo de problema");
            binding.btnCrearTipoProblemaForm.setText("Actualizar tipo de problema");
        }

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Solo cargar datos cuando el formulario sea de edición.
        if (formularioViewModel != null && formularioViewModel.hasTipoProblema()) {
            formularioViewModel.getTipoProblema().observe(getViewLifecycleOwner(), tipoProblema -> {
                binding.etTipoProblema.setText(tipoProblema.nombre);
            });
        }

        binding.clLoadingTipoProblemaForm.setVisibility(View.GONE);
        binding.lSubmitTipoProblemaForm.setVisibility(View.VISIBLE);
    }

    private void updateTipoProblemaList() {
        getActivity().finish();
        getActivity().overridePendingTransition(0, 0);
        getActivity().startActivity(getActivity().getIntent());
        getActivity().overridePendingTransition(0, 0);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }


    @Override
    public void onValidationSucceeded() {
        // Se muestra animación de cargando
        binding.clLoadingTipoProblemaForm.setVisibility(View.VISIBLE);
        binding.lSubmitTipoProblemaForm.setVisibility(View.GONE);
        binding.tvLoadingTipoProblemaForm.setText("Guardando datos");

        // Manejo de datos
        Gson gson = new Gson();
        TipoProblema tipoProblema = new TipoProblema();

        tipoProblema.nombre = binding.etTipoProblema.getText().toString();

        JSONObject request = new JSONObject();

        try {
            request.put("tipoProblema", new JSONObject(gson.toJson(tipoProblema)));
        } catch (JSONException ignored) {
        }

        if (formularioViewModel != null && formularioViewModel.hasTipoProblema()) {
            tipoProblema.actualizar(formularioViewModel.getTipoProblema().getValue().id, request, response -> {
                binding.clLoadingTipoProblemaForm.setVisibility(View.GONE);
                binding.lSubmitTipoProblemaForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateTipoProblemaList();
            }, error -> {
                binding.clLoadingTipoProblemaForm.setVisibility(View.GONE);
                binding.lSubmitTipoProblemaForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al actualizar tipo de problema", Toast.LENGTH_SHORT).show();
            });
        } else {
            tipoProblema.crear(request, response -> {
                binding.clLoadingTipoProblemaForm.setVisibility(View.GONE);
                binding.lSubmitTipoProblemaForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateTipoProblemaList();
            }, error -> {
                binding.clLoadingTipoProblemaForm.setVisibility(View.GONE);
                binding.lSubmitTipoProblemaForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al crear tipo de problema", Toast.LENGTH_SHORT).show();
            });
        }
    }


    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        AdapterMaterialSpinner.onErrorChanges(errors);
    }
}