package com.example.servercraft.ViewModels.ClientesProveedores.Proveedores.DetalleProveedor;

import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

public class DetalleProveedorViewModelFactory implements ViewModelProvider.Factory {
    private Integer mProveedorId;

    public DetalleProveedorViewModelFactory(@Nullable Integer proveedorId) {
        if (proveedorId != null) {
            this.mProveedorId = proveedorId;
        }
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        return (T) new DetalleProveedorViewModel(mProveedorId);
    }
}
