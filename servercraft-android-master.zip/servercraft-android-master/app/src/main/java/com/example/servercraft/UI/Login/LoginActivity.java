package com.example.servercraft.UI.Login;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.servercraft.Models.Auth;
import com.example.servercraft.Models.Token;
import com.example.servercraft.Models.Usuario;
import com.example.servercraft.UI.MenuPrincipalUsuario.MenuPrincipal;
import com.example.servercraft.UI.SplashScreen.SplashActivity;
import com.example.servercraft.Utils.AdapterMaterialSpinner;
import com.example.servercraft.Utils.Preferences;
import com.example.servercraft.Utils.UserInfo;
import com.example.servercraft.databinding.ActivityLoginBinding;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.Email;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Password;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class LoginActivity extends AppCompatActivity implements Validator.ValidationListener {
    ActivityLoginBinding binding;
    private Validator validator;

    //Validaciones
    @NotEmpty(message = "Campo obligatorio")
    @Email(message = "Ingrese un email válido")
    private EditText etEmail;

    @NotEmpty(message = "Campo obligatorio")
    @Password(min = 6, message = "La contraseña debe ser mayor a 6 caracteres")
    private EditText etPassword;


    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Configuración Binding
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Se oculta el webView inicialmente
        binding.rlLoginWebView.setVisibility(View.GONE);

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.setValidationListener(this);

        // Intanciamiento de los campos a validar
        etEmail = binding.etEmail;
        etPassword = binding.etPassword;

        // Configuración Login
        binding.btnLogin.setOnClickListener(v -> {
            validator.validate();
        });

        // Configuración Recuperar contraseña
        binding.btnForgotPassword.setOnClickListener((v) -> {
            binding.wvRecuperarContrasena.loadUrl("https://servercraft.ga/recuperar?ua=mobile");
            binding.wvRecuperarContrasena.getSettings().setJavaScriptEnabled(true);
            binding.rlLoginWebView.setVisibility(View.VISIBLE);
        });

        binding.btnCerrarWebView.setOnClickListener(v -> {
            binding.rlLoginWebView.setVisibility(View.INVISIBLE);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }

    @Override
    public void onValidationSucceeded() {
        try {
            Gson gson = new Gson();
            Auth auth = new Auth();
            Usuario usuario = new Usuario();

            usuario.email = etEmail.getText().toString();
            usuario.password = etPassword.getText().toString();
            auth.setUsuario(usuario);

            JSONObject request = new JSONObject(gson.toJson(auth));

            auth.login(request, response -> {
                Token token = gson.fromJson(response.toString(), Auth.class).getToken();

                new Preferences("auth").addValue("token", token.getToken());

                usuario.obtener(0, responseUsuario -> {
                    try {
                        JSONObject httpUsuario = responseUsuario.getJSONObject("usuario");
                        Usuario objectUsuario = mapUsuarioIntoObject(httpUsuario);

                        new UserInfo().setUserRol(objectUsuario.rol.id);

                        new UserInfo().setUserImage(objectUsuario.imagen.url);
                    } catch (Exception e) {
                        new UserInfo().setUserImage("");
                    }

                    Intent menuInicio = new Intent(LoginActivity.this, MenuPrincipal.class);
                    startActivity(menuInicio);
                    finish();
                }, error -> {
                }, token.getToken());
            }, error -> {
                Toast.makeText(this, "Email o contraseña inválidos", Toast.LENGTH_SHORT).show();
            });
        } catch (Exception e) {
        }
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        AdapterMaterialSpinner.onErrorChanges(errors);
    }

    private Usuario mapUsuarioIntoObject(JSONObject httpUsuario) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Usuario usuario = gson.fromJson(httpUsuario.toString(), Usuario.class);

        return usuario;
    }
}