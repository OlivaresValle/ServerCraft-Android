package com.example.servercraft.UI.ServidoresRacksSalas.Racks;

import android.app.Activity;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import com.example.servercraft.R;
import com.example.servercraft.ViewModels.ServidoresRacksSalas.Racks.ListarRacksViewModel;
import com.example.servercraft.databinding.FragmentListarRacksBinding;

public class ListarRacksFragment extends Fragment {
    public ListarRacksViewModel listarViewModel;
    private FragmentListarRacksBinding binding;
    private RackItemAdapter rackItemAdapter;
    private boolean iniciado = false;

    public static ListarRacksFragment newInstance() {
        ListarRacksFragment fragment = new ListarRacksFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        listarViewModel = new ViewModelProvider(this).get(ListarRacksViewModel.class);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        Activity parent = getActivity();
        binding = FragmentListarRacksBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Elements
        ProgressBar spinner = parent.findViewById(R.id.pbHttpLoading);

        // Configuración inicial de elementos
        spinner.setVisibility(View.INVISIBLE);
        binding.rvRacks.setLayoutManager(new LinearLayoutManager(root.getContext()));
        binding.pbHttpLoadingRack.setVisibility(View.INVISIBLE);

        if (iniciado) {
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etBuscarRack.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arRack.clear();
            listarViewModel.loadHTTPRackList();
            rackItemAdapter = null;
            binding.pbHttpLoadingRack.setVisibility(View.VISIBLE);
        }

        // Observador de consulta HTTP
        listarViewModel.getRackList().observe(getViewLifecycleOwner(), racks -> {

            if (rackItemAdapter == null) {
                iniciado = true;
                rackItemAdapter = new RackItemAdapter(root.getContext(), racks, getChildFragmentManager());

                binding.rvRacks.setAdapter(rackItemAdapter);
                spinner.setVisibility(View.INVISIBLE);
                binding.pbHttpLoadingRack.setVisibility(View.INVISIBLE);
            } else {
                binding.rvRacks.post(new Runnable() {
                    public void run() {
                        rackItemAdapter.notifyItemRangeChanged(0, racks.size() - 1);
                    }
                });
            }
        });

        binding.btnBuscarRack.setOnClickListener(v -> {
            binding.pbHttpLoadingRack.setVisibility(View.VISIBLE);
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etBuscarRack.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arRack.clear();
            listarViewModel.loadHTTPRackList();
            rackItemAdapter = null;
        });

        // Listener de scroll para cargar siguientes páginas
        binding.rvRacks.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                if (!listarViewModel.cargandoDatos) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == listarViewModel.arRack.size() - 1) {
                        listarViewModel.cargandoDatos = true;
                        listarViewModel.loadHTTPRackList();
                    }
                }
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}