package com.example.servercraft.UI.Ubicacion.Regiones;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.servercraft.Models.Region;
import com.example.servercraft.R;
import com.example.servercraft.ViewModels.Ubicacion.Region.DetalleRegion.DetalleRegionViewModel;
import com.example.servercraft.ViewModels.Ubicacion.Region.DetalleRegion.DetalleRegionViewModelFactory;
import com.example.servercraft.databinding.FragmentDetalleRegionesBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;

public class DetalleRegionesFragment extends BottomSheetDialogFragment {
    private static final String ARG_REG = "ubicacion/region";
    private DetalleRegionViewModel detalleViewModel;
    private FragmentDetalleRegionesBinding binding;


    public static DetalleRegionesFragment newInstance(Region region){
        DetalleRegionesFragment fragment = new DetalleRegionesFragment();
        Bundle bundle = new Bundle();
        Gson gson = new Gson();

        bundle.putString(ARG_REG, gson.toJson(region));
        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Region region = null;

        if (getArguments() != null) {
            Gson gson = new Gson();
            String jsonRegion = getArguments().getString(ARG_REG);

            region = gson.fromJson(jsonRegion, Region.class);
        }

        detalleViewModel = new ViewModelProvider(this, new DetalleRegionViewModelFactory(region)).get(DetalleRegionViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentDetalleRegionesBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Observador de consulta HTTP
        detalleViewModel.getRegion().observe(getViewLifecycleOwner(), region -> {
            // Cargar datos cuando estén disponibles
            binding.tvRegionTitle.setText(region.nombre);
            binding.tvPais.setText(region.pais.nombre);


            // Ocultar vista de "cargando..."
            binding.clLoadingRegion.setVisibility(View.GONE);
            binding.llRegionData.setVisibility(View.VISIBLE);
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}