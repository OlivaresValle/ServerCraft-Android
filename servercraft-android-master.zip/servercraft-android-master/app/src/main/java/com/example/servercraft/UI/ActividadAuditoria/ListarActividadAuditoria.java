package com.example.servercraft.UI.ActividadAuditoria;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.example.servercraft.ViewModels.ActividadAuditoria.ListarActividadAuditoriaViewModel;
import com.example.servercraft.databinding.ActivityListarActividadAuditoriaBinding;

public class ListarActividadAuditoria extends AppCompatActivity {
    private ActivityListarActividadAuditoriaBinding binding;
    private ListarActividadAuditoriaViewModel listarViewModel;
    private ActividadAuditoriaAdapter actividadAuditoriaAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Configuración binding del Layout
        binding = ActivityListarActividadAuditoriaBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //Configuración View Model
        listarViewModel = new ViewModelProvider(this).get(ListarActividadAuditoriaViewModel.class);

        //Toolbar
        Toolbar toolbar = binding.tbMainActividadAuditoria.tbMain;
        TextView tvTbTitle = binding.tbMainActividadAuditoria.tvTbTitle;
        TextView tvTbDescripcion = binding.tbMainActividadAuditoria.tvTbDescripcion;

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        binding.tbMainActividadAuditoria.cvUsuarioMenuPrincipal.setVisibility(View.GONE);
        tvTbTitle.setText("Registro de actividad");
        tvTbDescripcion.setText("Listado de eventos que ocurren en los sistemas");
        toolbar.setContentInsetStartWithNavigation(0);
        toolbar.setNavigationOnClickListener(v -> {
            finish();
        });

        //Elements
        binding.pbHttpLoadingActividadAuditoria.setVisibility(View.VISIBLE);
        binding.recyclerActividadAuditoria.setLayoutManager(new LinearLayoutManager(this));

        // Observador de consulta HTTP
        listarViewModel.getActividadAuditoria().observe(this, actividadAuditorias -> {
            Log.d("Listado", actividadAuditorias.toString());
            if (actividadAuditoriaAdapter == null) {
                actividadAuditoriaAdapter = new ActividadAuditoriaAdapter(this, actividadAuditorias, getSupportFragmentManager());

                binding.recyclerActividadAuditoria.setAdapter(actividadAuditoriaAdapter);

                binding.pbHttpLoadingActividadAuditoria.setVisibility(View.INVISIBLE);
            } else {
                binding.recyclerActividadAuditoria.post(new Runnable() {
                    @Override
                    public void run() {
                        actividadAuditoriaAdapter.notifyItemRangeChanged(0, actividadAuditorias.size() - 1);
                    }
                });
            }
        });

        // Observador de scroll para cargar siguiente pagina
        binding.recyclerActividadAuditoria.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                if (!listarViewModel.cargandoDatos) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == listarViewModel.arActividadAuditoria.size() - 1) {
                        listarViewModel.cargandoDatos = true;
                        listarViewModel.loadHTTPActividadAuditoriaList();
                    }
                }
            }
        });
    }
}