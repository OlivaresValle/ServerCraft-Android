package com.example.servercraft.UI.MenuPrincipalUsuario.PerfilUsuario;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.chivorn.smartmaterialspinner.SmartMaterialSpinner;
import com.example.servercraft.Models.Usuario;
import com.example.servercraft.Utils.AdapterMaterialSpinner;
import com.example.servercraft.databinding.FragmentFormularioContrasenaBinding;
import com.google.gson.Gson;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.ConfirmPassword;
import com.mobsandgeeks.saripaar.annotation.Length;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Password;

import org.json.JSONObject;

import java.util.List;

public class FormularioContrasenaFragment extends Fragment implements Validator.ValidationListener {
    private FragmentFormularioContrasenaBinding binding;
    private View root;
    private Validator validator;

    // Validaciones

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etPasswordOld;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    @Password(min = 6, message = "Contraseña inválida")
    EditText etPassword;

    @ConfirmPassword(message = "Las contraseñas no coinciden")
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etConfirmPassword;

    public static FormularioContrasenaFragment newInstance() {
        FormularioContrasenaFragment fragment = new FormularioContrasenaFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentFormularioContrasenaBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.registerAdapter(SmartMaterialSpinner.class, new AdapterMaterialSpinner());
        validator.setValidationListener(this);

        // Intanciamiento de los campos a validar
        etPasswordOld = binding.etContrasenaActual;
        etPassword = binding.etContrasenaNueva;
        etConfirmPassword = binding.etContrasenaConfirmar;


        // Button Listener
        binding.btnCambiarContrasena.setOnClickListener(v -> {
            validator.validate();

        });

        return root;
    }

    @Override
    public void onValidationSucceeded() {
        // Manejo de datos
        Gson gson = new Gson();
        JSONObject request = new JSONObject();
        JSONObject usuario = new JSONObject();

        try {
            usuario.put("contrasenaActual", binding.etContrasenaActual.getText().toString());
        } catch (Exception ignored) {
        }

        try {
            usuario.put("contrasenaNueva", binding.etContrasenaNueva.getText().toString());
        } catch (Exception ignored) {
        }

        try {
            usuario.put("confirmarContrasena", binding.etContrasenaConfirmar.getText().toString());
        } catch (Exception ignored) {
        }

        try {
            request.put("usuario", usuario);
        } catch (Exception ignored) {
        }

        new Usuario().actualizarContrasena(request, response -> {
            binding.etContrasenaActual.setText("");
            binding.etContrasenaNueva.setText("");
            binding.etContrasenaConfirmar.setText("");

            Toast.makeText(getContext(), "Contraseña actualizada correctamente", Toast.LENGTH_SHORT).show();
        }, error -> {
            Toast.makeText(getContext(), "Las contraseñas ingresadas no coinciden", Toast.LENGTH_SHORT).show();
        });

    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(getContext());

            // Display error messages ;)
            if (view instanceof EditText) {
                ((EditText) view).setError(message);
            } else {
                Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show();
            }
        }
    }
}