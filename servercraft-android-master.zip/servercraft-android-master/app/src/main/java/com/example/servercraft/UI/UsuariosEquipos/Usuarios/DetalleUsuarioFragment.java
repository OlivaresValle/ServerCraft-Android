package com.example.servercraft.UI.UsuariosEquipos.Usuarios;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.example.servercraft.ViewModels.UsuariosEquipos.Usuarios.DetalleUsuario.DetalleUsuarioViewModel;
import com.example.servercraft.databinding.FragmentDetalleUsuarioBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.example.servercraft.ViewModels.UsuariosEquipos.Usuarios.DetalleUsuario.DetalleUsuarioViewModelFactory;
import com.squareup.picasso.Picasso;

public class DetalleUsuarioFragment extends BottomSheetDialogFragment {
    private static final String ARG_ID_USUARIO = "id_usuario";
    private DetalleUsuarioViewModel detalleViewModel;
    private FragmentDetalleUsuarioBinding binding;

    public static DetalleUsuarioFragment newInstance(int idUsuario) {
        DetalleUsuarioFragment fragment = new DetalleUsuarioFragment();
        Bundle bundle = new Bundle();

        bundle.putInt(ARG_ID_USUARIO, idUsuario);
        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int usuarioId = 1;

        if (getArguments() != null) {
            usuarioId = getArguments().getInt(ARG_ID_USUARIO);
        }
        detalleViewModel = new ViewModelProvider(this, new DetalleUsuarioViewModelFactory(usuarioId)).get(DetalleUsuarioViewModel.class);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentDetalleUsuarioBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Observador de consulta HTTP
        detalleViewModel.getUser().observe(getViewLifecycleOwner(), usuario -> {
            // Cargar datos cuando estén disponibles
            // 1 - Imagen
            if (usuario.imagen != null) {
                Picasso.get().load(usuario.imagen.url).into(binding.ivUsuario);
            }

            // 2 - Nombre completo
            binding.tvUsuarioNombre.setText(usuario.nombre + " " + usuario.apellidos);

            // 3 - RUT
            binding.tvRUTData.setText(usuario.rut);

            // 4 - Rol
            binding.tvRolData.setText(usuario.rol.nombre);

            // 5 - Equipo Trabajo
            binding.tvEquipoData.setText(usuario.equipoTrabajo != null ? usuario.equipoTrabajo.nombre : "Sin equipo");

            // 6 - Email
            binding.tvEmailUsuario.setText(usuario.email);

            // 7 - Telefono
            binding.tvTelefonoUsuarioData.setText(usuario.telefonoContacto);

            // Ocultar vista de "cargando..."
            binding.clLoadingUsuario.setVisibility(View.GONE);
            binding.lUsuarioTab.setVisibility(View.VISIBLE);
        });
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}



