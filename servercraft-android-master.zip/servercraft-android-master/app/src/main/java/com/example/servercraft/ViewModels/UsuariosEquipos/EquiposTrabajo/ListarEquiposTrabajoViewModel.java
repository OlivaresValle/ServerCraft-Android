package com.example.servercraft.ViewModels.UsuariosEquipos.EquiposTrabajo;

import android.util.Log;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.EquipoTrabajo;
import com.example.servercraft.Models.Lenguaje;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Objects;

public class ListarEquiposTrabajoViewModel extends ViewModel {
    private MutableLiveData<ArrayList<EquipoTrabajo>> mEquipoTrabajoList;
    public ArrayList<EquipoTrabajo> arEquipo = new ArrayList<>();

    public boolean cargandoDatos = false;
    public boolean blPuedeCargarMas = true;
    public int pagina = 0;
    public String busqueda = "";

    // Constructor
    public ListarEquiposTrabajoViewModel() {
        mEquipoTrabajoList = new MutableLiveData<>();

        loadHTTPEquiposList();
    }

    // Getters
    public MutableLiveData<ArrayList<EquipoTrabajo>> getEquiposTrabajoList() {
        return mEquipoTrabajoList;
    }

    // Setters
    public void loadHTTPEquiposList() {

        if (blPuedeCargarMas) {
            EquipoTrabajo equipoTrabajo = new EquipoTrabajo();

            pagina = pagina + 1;

            if (arEquipo.size() != 0) {
                arEquipo.add(null);
                mEquipoTrabajoList.setValue(arEquipo);
            }

        equipoTrabajo.listar(10,pagina,busqueda,null, response -> {
            try {
                JSONArray httpEquipos = response.getJSONArray("equipos_trabajo");
                JSONObject httpMeta = response.getJSONObject("meta");

                Log.d("Resultados",httpEquipos.toString());

                arEquipo.removeIf(Objects::isNull);


                if (httpMeta.getInt("last_page") == pagina) {
                    blPuedeCargarMas = false;
                }

                arEquipo.addAll(mapEquiposTrabajoIntoObject(httpEquipos));

                mEquipoTrabajoList.setValue(arEquipo);

                cargandoDatos = false;
            } catch (JSONException e) {
                Log.e("Listar leng", e.toString());
            }
        }, error -> Log.d("Error de ", error.toString()));
        }
    }


    private ArrayList<EquipoTrabajo> mapEquiposTrabajoIntoObject(JSONArray httpEquipos) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type EquipoTrabajoArray = new TypeToken<ArrayList<EquipoTrabajo>>() {
        }.getType();
        ArrayList<EquipoTrabajo> equipoTrabajoList = gson.fromJson(httpEquipos.toString(), EquipoTrabajoArray);

        return equipoTrabajoList;
    }
}
