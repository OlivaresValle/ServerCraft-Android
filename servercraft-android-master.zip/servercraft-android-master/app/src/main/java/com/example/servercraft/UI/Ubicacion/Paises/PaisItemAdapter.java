package com.example.servercraft.UI.Ubicacion.Paises;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.servercraft.Models.Lenguaje;
import com.example.servercraft.Models.Pais;
import com.example.servercraft.R;
import com.example.servercraft.UI.LenguajesProgramacion.FormularioLenguajeProgramacionFragment;
import com.example.servercraft.UI.LenguajesProgramacion.LenguajeItemAdapter;

import java.util.ArrayList;

public class PaisItemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;

    LayoutInflater inflater;
    ArrayList<Pais> model;
    FragmentManager fragmentManager;
    Context context;

    public PaisItemAdapter(Context context, ArrayList<Pais> model, FragmentManager fm) {


        this.inflater = LayoutInflater.from(context);
        this.model = model;
        this.fragmentManager = fm;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = inflater.inflate(R.layout.item_list_simple, parent, false);

            return new PaisItemAdapter.ItemViewHolder(view);
        }else{
            View view = inflater.inflate(R.layout.item_list_loading, parent, false);

            return new PaisItemAdapter.LoadingViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof PaisItemAdapter.ItemViewHolder) {
            populateItemRows((PaisItemAdapter.ItemViewHolder) holder, position);
        } else if (holder instanceof PaisItemAdapter.LoadingViewHolder) {
            showLoadingView((PaisItemAdapter.LoadingViewHolder) holder, position);
        }
    }


    @Override
    public int getItemViewType(int position) {
        return model.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }

    @Override
    public int getItemCount() {
        return model == null ? 0 : model.size();
    }

    private class ItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ConstraintLayout clItemData, clItemActions;
        TextView nombre;
        Button btnEdit, btnDelete;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);

            nombre = itemView.findViewById(R.id.tvItemTitle);
            clItemData = itemView.findViewById(R.id.clItemData);
            clItemActions = itemView.findViewById(R.id.clItemActions);
            btnEdit = itemView.findViewById(R.id.btnUpdate);
            btnDelete = itemView.findViewById(R.id.btnDelete);

            clItemData.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int adapterPosition = getAbsoluteAdapterPosition();
            Pais pais = model.get(adapterPosition);
            pais.isFullyVisible = !pais.isFullyVisible;

            notifyItemChanged(adapterPosition);
        }
    }



    private class LoadingViewHolder extends RecyclerView.ViewHolder {

        public LoadingViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    private void showLoadingView(PaisItemAdapter.LoadingViewHolder viewHolder, int position) {
        //ProgressBar would be displayed

    }

    private void populateItemRows(PaisItemAdapter.ItemViewHolder holder, int position) {

// Obtención de objeto
        //Obtencion del Objeto
        Pais pais = model.get(position);

        //Seteo de Valores
        holder.nombre.setText(pais.nombre);
        holder.clItemActions.setVisibility(pais.isFullyVisible ? View.VISIBLE : View.GONE);

        // Click listeners
        holder.btnEdit.setOnClickListener(v -> {
            FormularioPaisFragment formPais = FormularioPaisFragment.newInstance(pais);
            formPais.show(fragmentManager, formPais.getTag());
        });

        holder.btnDelete.setOnClickListener(v -> {
            AlertDialog.Builder confirmation = new AlertDialog.Builder(context);
            confirmation.setTitle("Advertencia")
                    .setMessage("¿Estás seguro de qué deseas eliminar el país: \""+pais.nombre+"\"?")
                    .setCancelable(false)
                    .setPositiveButton("Eliminar", (dialog, which) -> {
                        pais.eliminar(pais.id, response -> {
                            ((Activity) context).finish();
                            ((Activity) context).overridePendingTransition(0, 0);
                            ((Activity) context).startActivity(((Activity) context).getIntent());
                            ((Activity) context).overridePendingTransition(0, 0);
                        }, error -> {
                            Toast.makeText(context, "Error al eliminar país.", Toast.LENGTH_SHORT).show();
                        });
                    }).setNegativeButton("Cancelar", (dialog, which) -> {
                dialog.dismiss();
            });
            confirmation.create().show();
        });
    }
}
