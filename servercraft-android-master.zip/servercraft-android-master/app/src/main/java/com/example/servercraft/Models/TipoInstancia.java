package com.example.servercraft.Models;

public class TipoInstancia {
    // Attributes
    public int id;
    public String nombre;
}