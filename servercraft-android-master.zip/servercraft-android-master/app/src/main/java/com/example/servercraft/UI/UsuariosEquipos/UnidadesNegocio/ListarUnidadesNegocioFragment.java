package com.example.servercraft.UI.UsuariosEquipos.UnidadesNegocio;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.example.servercraft.R;
import com.example.servercraft.ViewModels.UsuariosEquipos.UnidadesNegocio.ListarUnidadesNegocioViewModel;
import com.example.servercraft.databinding.FragmentListarUnidadesNegocioBinding;

public class ListarUnidadesNegocioFragment extends Fragment {
    public ListarUnidadesNegocioViewModel listarViewModel;
    private FragmentListarUnidadesNegocioBinding binding;
    public UnidadNegocioItemAdapter unidadNegocioAdapter;
    private boolean iniciado = false;

    public static ListarUnidadesNegocioFragment newInstance() {
        return new ListarUnidadesNegocioFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        listarViewModel = new ViewModelProvider(this).get(ListarUnidadesNegocioViewModel.class);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        Activity parent = getActivity();
        binding = FragmentListarUnidadesNegocioBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Elements
        ProgressBar spinner = parent.findViewById(R.id.pbHttpUsuariosLoading);
        RecyclerView rvUnidadesNegocio = binding.rvUnidadesNegocio;

        // Configuración inicial de elementos
        spinner.setVisibility(View.INVISIBLE);
        rvUnidadesNegocio.setLayoutManager(new LinearLayoutManager(root.getContext()));
        binding.pbHttpLoadingUnidad.setVisibility(View.INVISIBLE);

        if (iniciado) {
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etBuscarUnidad.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arUnidad.clear();
            listarViewModel.loadHTTPUnidadesList();
            unidadNegocioAdapter = null;
            binding.pbHttpLoadingUnidad.setVisibility(View.VISIBLE);
        }

        // Observador de consulta HTTP
        listarViewModel.getUnidadesNegocioList().observe(getViewLifecycleOwner(), unidadesNegocio -> {
            iniciado = true;
            if (unidadNegocioAdapter == null) {
                unidadNegocioAdapter = new UnidadNegocioItemAdapter(root.getContext(), unidadesNegocio, getChildFragmentManager());

                binding.rvUnidadesNegocio.setAdapter(unidadNegocioAdapter);

                spinner.setVisibility(View.INVISIBLE);
                binding.pbHttpLoadingUnidad.setVisibility(View.INVISIBLE);
            } else {
                binding.rvUnidadesNegocio.post(new Runnable() {
                    public void run() {
                        unidadNegocioAdapter.notifyItemRangeChanged(0, unidadesNegocio.size() - 1);
                    }
                });
            }
        });


        binding.btnBuscarUnidad.setOnClickListener(v -> {
            Log.d("Boton", "apretado");
            binding.pbHttpLoadingUnidad.setVisibility(View.VISIBLE);
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etBuscarUnidad.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arUnidad.clear();
            listarViewModel.loadHTTPUnidadesList();
            unidadNegocioAdapter = null;
        });


        binding.rvUnidadesNegocio.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                if (!listarViewModel.cargandoDatos) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == listarViewModel.arUnidad.size() - 1) {
                        listarViewModel.cargandoDatos = true;
                        listarViewModel.loadHTTPUnidadesList();
                    }
                }
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}