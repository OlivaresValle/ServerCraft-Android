package com.example.servercraft.ViewModels.Ubicacion.Region.DetalleRegion;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.example.servercraft.Models.Region;

import org.jetbrains.annotations.Nullable;

public class DetalleRegionViewModelFactory implements ViewModelProvider.Factory {
    private Region mRegion;

    public DetalleRegionViewModelFactory(@Nullable Region region){
        if (region != null){
            this.mRegion = region;
        }
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass){
        return (T) new DetalleRegionViewModel(mRegion);
    }

}
