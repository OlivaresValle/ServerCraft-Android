package com.example.servercraft.UI.Estadisticas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.ViewModelProvider;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;


import com.example.servercraft.Models.EstadisticaCliente;
import com.example.servercraft.Models.EstadisticaIncidente;
import com.example.servercraft.R;
import com.example.servercraft.ViewModels.Estadistica.VisualizarEstadisticasViewModel;
import com.example.servercraft.databinding.ActivityVisualizarEstadisticasBinding;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.util.ArrayList;
import java.util.List;

public class VisualizarEstadisticas extends AppCompatActivity {
    private ActivityVisualizarEstadisticasBinding binding;
    private VisualizarEstadisticasViewModel visualizarViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Configuración binding de layout
        binding = ActivityVisualizarEstadisticasBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Toolbar
        Toolbar toolbar = binding.tbMainUbicacion.tbMain;
        TextView tvTbTitle = binding.tbMainUbicacion.tvTbTitle;
        TextView tvTbDescripcion = binding.tbMainUbicacion.tvTbDescripcion;

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        binding.tbMainUbicacion.cvUsuarioMenuPrincipal.setVisibility(View.GONE);
        tvTbTitle.setText("Estadísticas");
        tvTbDescripcion.setText("Estadísticas del año actual.");
        toolbar.setContentInsetStartWithNavigation(0);
        toolbar.setNavigationOnClickListener(v -> {
            finish();
        });

        // Configuración View Model
        visualizarViewModel = new ViewModelProvider(this).get(VisualizarEstadisticasViewModel.class);

        // Observador de consulta HTTP
        visualizarViewModel.getEstadisticaClienteList().observe(this, estadisticaClientes -> {
            LineChart chart = binding.chClientes;

            List<Entry> entries = new ArrayList<>();

            for (EstadisticaCliente data : estadisticaClientes) {
                // turn your data into Entry objects
                entries.add(new Entry(data.mes, data.clientes));
            }

            final String[] meses = new String[]{"Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"};

            IndexAxisValueFormatter formatter = new IndexAxisValueFormatter();
            formatter.setValues(meses);

            XAxis xAxis = chart.getXAxis();
            xAxis.setGranularity(1f);
            xAxis.setValueFormatter(formatter);

            LineDataSet dataSet = new LineDataSet(entries, "Clientes nuevos");
            dataSet.setColor(R.color.primary_500);

            LineData lineData = new LineData(dataSet);
            lineData.setValueTextSize(12);
            chart.setData(lineData);

            Description desc = new Description();
            desc.setText("Clientes nuevos por mes en el año actual");
            chart.setDescription(desc);
            desc.setTextSize(12);

            chart.invalidate();
        });

        visualizarViewModel.getEstadisticaIncidenteList().observe(this, estadisticaIncidentes -> {
            BarChart chart = binding.chIncidentes;

            List<BarEntry> entries = new ArrayList<>();

            for (EstadisticaIncidente data : estadisticaIncidentes) {
                // turn your data into Entry objects
                entries.add(new BarEntry(data.mes, data.contador));
            }

            final String[] meses = new String[]{"Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"};

            IndexAxisValueFormatter formatter = new IndexAxisValueFormatter();
            formatter.setValues(meses);

            XAxis xAxis = chart.getXAxis();
            xAxis.setGranularity(1f);
            xAxis.setValueFormatter(formatter);

            BarDataSet dataSet = new BarDataSet(entries, "Incidentes activos");
            dataSet.setColor(R.color.primary_600);

            BarData barData = new BarData(dataSet);

            chart.setData(barData);

            Description desc = new Description();
            desc.setText("Incidentes activos por mes en el año actual");
            desc.setTextSize(12);
            chart.setDescription(desc);

            chart.invalidate();
        });
    }
}