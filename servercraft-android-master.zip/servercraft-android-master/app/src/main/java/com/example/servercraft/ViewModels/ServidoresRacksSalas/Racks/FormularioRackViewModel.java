package com.example.servercraft.ViewModels.ServidoresRacksSalas.Racks;

import android.util.Log;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.Sala;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.JSONArray;
import org.json.JSONException;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class FormularioRackViewModel extends ViewModel {
    private MutableLiveData<ArrayList<Sala>> mSalas;

    // Constructor
    public FormularioRackViewModel() {
        mSalas = new MutableLiveData<>();

        loadHTTPSalaList();
    }

    // Getters
    public MutableLiveData<ArrayList<Sala>> getSalaList() {
        return mSalas;
    }

    // Setters
    private void loadHTTPSalaList() {
        Sala sala = new Sala();

        sala.listar(1000, 1,null, null, response -> {
            try {
                JSONArray httpSalas = response.getJSONArray("salas");

                ArrayList<Sala> objectSalas = mapSalaIntoObject(httpSalas);

                mSalas.setValue(objectSalas);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<Sala> mapSalaIntoObject(JSONArray httpSalas) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type SalaArray = new TypeToken<ArrayList<Sala>>() {
        }.getType();
        ArrayList<Sala> salasList = gson.fromJson(httpSalas.toString(), SalaArray);

        return salasList;
    }
}
