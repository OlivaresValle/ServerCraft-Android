package com.example.servercraft.UI.ClientesProveedores.EquipoProveedor;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import com.example.servercraft.R;
import com.example.servercraft.ViewModels.ClientesProveedores.EquiposProveedores.ListarEquiposProveedoresViewModel;
import com.example.servercraft.databinding.FragmentListarEquiposProveedoresBinding;

public class ListarEquiposProveedoresFragment extends Fragment {
    private ListarEquiposProveedoresViewModel listarViewModel;
    private FragmentListarEquiposProveedoresBinding binding;
    private EquipoProveedorItemAdapter equipoProveedorAdapter;

    public static ListarEquiposProveedoresFragment newInstance() {
        return new ListarEquiposProveedoresFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        listarViewModel = new ViewModelProvider(this).get(ListarEquiposProveedoresViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        Activity parent = getActivity();
        binding = FragmentListarEquiposProveedoresBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Elements
        ProgressBar spinner = parent.findViewById(R.id.pbHttpProveedorLoading);

        // Configuración inicial de elementos
        spinner.setVisibility(View.VISIBLE);
        binding.rvEquiposProveedores.setLayoutManager(new LinearLayoutManager(root.getContext()));
        binding.pbHttpLoadingEquipo.setVisibility(View.INVISIBLE);

        // Observador de consulta HTTP
        listarViewModel.getEquipoProveedorList().observe(getViewLifecycleOwner(), equipos -> {
            if (equipoProveedorAdapter == null) {
                equipoProveedorAdapter = new EquipoProveedorItemAdapter(root.getContext(), equipos, getChildFragmentManager());

                binding.rvEquiposProveedores.setAdapter(equipoProveedorAdapter);
                spinner.setVisibility(View.INVISIBLE);
                binding.pbHttpLoadingEquipo.setVisibility(View.INVISIBLE);
            } else {
                binding.rvEquiposProveedores.post(new Runnable() {
                    public void run() {
                        equipoProveedorAdapter.notifyItemRangeChanged(0, equipos.size() - 1);
                    }
                });
            }
        });

        binding.btnBuscarEquipo.setOnClickListener(v -> {
            binding.pbHttpLoadingEquipo.setVisibility(View.VISIBLE);
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etBuscarEquipo.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arEquipoProveedor.clear();
            listarViewModel.loadHTTPEquipoProveedorList();
            equipoProveedorAdapter = null;
        });

        // Listener de scroll para cargar siguientes páginas


        binding.rvEquiposProveedores.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                if (!listarViewModel.cargandoDatos) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == listarViewModel.arEquipoProveedor.size() - 1) {
                        listarViewModel.cargandoDatos = true;
                        listarViewModel.loadHTTPEquipoProveedorList();
                    }
                }
            }
        });
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}