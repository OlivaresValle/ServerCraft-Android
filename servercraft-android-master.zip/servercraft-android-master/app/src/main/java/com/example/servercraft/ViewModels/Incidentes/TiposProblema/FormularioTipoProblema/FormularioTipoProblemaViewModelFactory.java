package com.example.servercraft.ViewModels.Incidentes.TiposProblema.FormularioTipoProblema;

import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import com.example.servercraft.Models.TipoProblema;

public class FormularioTipoProblemaViewModelFactory implements ViewModelProvider.Factory {
    private TipoProblema mTipoProblema;

    public FormularioTipoProblemaViewModelFactory(@Nullable TipoProblema tipoProblema) {
        if (tipoProblema != null) {
            this.mTipoProblema = tipoProblema;
        }
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        return (T) new FormularioTipoProblemaViewModel(mTipoProblema);
    }
}
