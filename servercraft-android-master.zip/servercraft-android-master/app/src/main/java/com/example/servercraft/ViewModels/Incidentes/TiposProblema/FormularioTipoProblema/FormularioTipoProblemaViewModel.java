package com.example.servercraft.ViewModels.Incidentes.TiposProblema.FormularioTipoProblema;

import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.TipoProblema;

public class FormularioTipoProblemaViewModel extends ViewModel {
    private MutableLiveData<TipoProblema> mTipoProblema;

    // Constructor
    public FormularioTipoProblemaViewModel(@Nullable TipoProblema tipoProblema) {
        if (tipoProblema != null) {
            mTipoProblema = new MutableLiveData<>();

            mTipoProblema.setValue(tipoProblema);
        }
    }

    // Getters
    public MutableLiveData<TipoProblema> getTipoProblema() {
        return mTipoProblema;
    }

    public boolean hasTipoProblema() {
        return mTipoProblema != null;
    }
}
