package com.example.servercraft.ViewModels.BaseDatos.DetalleBaseDatos;

import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.BaseDatos;

public class DetalleBaseDatosViewModel extends ViewModel {
    private MutableLiveData<BaseDatos> mBaseDatos;

    public DetalleBaseDatosViewModel(@Nullable BaseDatos baseDatos) {
        mBaseDatos = new MutableLiveData<>();

        mBaseDatos.setValue(baseDatos);
    }

    public MutableLiveData<BaseDatos> getBaseDatos() {
        return mBaseDatos;
    }

    public boolean hasBaseDatos() {
        return mBaseDatos != null;
    }
}
