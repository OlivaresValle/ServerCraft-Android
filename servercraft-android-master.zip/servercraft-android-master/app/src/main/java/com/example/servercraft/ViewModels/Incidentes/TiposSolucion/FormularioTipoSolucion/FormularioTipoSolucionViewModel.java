package com.example.servercraft.ViewModels.Incidentes.TiposSolucion.FormularioTipoSolucion;

import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.TipoSolucion;

public class FormularioTipoSolucionViewModel extends ViewModel {
    private MutableLiveData<TipoSolucion> mTipoSolucion;

    // Constructor
    public FormularioTipoSolucionViewModel(@Nullable TipoSolucion tipoSolucion) {
        if (tipoSolucion != null) {
            mTipoSolucion = new MutableLiveData<>();

            mTipoSolucion.setValue(tipoSolucion);
        }
    }

    // Getters
    public MutableLiveData<TipoSolucion> getTipoSolucion() {
        return mTipoSolucion;
    }

    public boolean hasTipoSolucion() {
        return mTipoSolucion != null;
    }
}
