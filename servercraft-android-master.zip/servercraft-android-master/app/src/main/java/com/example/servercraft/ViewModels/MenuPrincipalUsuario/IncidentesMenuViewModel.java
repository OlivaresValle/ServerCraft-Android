package com.example.servercraft.ViewModels.MenuPrincipalUsuario;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.Menu;
import com.example.servercraft.R;
import com.example.servercraft.Utils.UserInfo;

import java.util.ArrayList;

public class IncidentesMenuViewModel extends ViewModel {
    private MutableLiveData<ArrayList<Menu>> mMenuList;

    public IncidentesMenuViewModel() {
        mMenuList = new MutableLiveData<>();
        mMenuList.setValue(obtenerMenu());
    }

    public LiveData<ArrayList<Menu>> getMenuList() {
        return mMenuList;
    }

    private ArrayList<Menu> obtenerMenu() {
        ArrayList<Menu> list = new ArrayList<>();

        int userRol = new UserInfo().getUserRol();

        list.add(new Menu(R.drawable.issues_icon, "Incidentes", "Gestionar incidentes relacionados a sistemas"));
        if(userRol == 1) list.add(new Menu(R.drawable.statistics_icon, "Estadísticas", "Visualizar estadísticas de la plataforma, uso y eventos"));
        if(userRol == 1) list.add(new Menu(R.drawable.activity_icon, "Registro de actividad", "Listado de eventos que ocurren en los sistemas"));

        return list;
    }
}