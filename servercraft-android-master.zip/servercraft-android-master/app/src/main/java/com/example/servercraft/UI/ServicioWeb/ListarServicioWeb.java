package com.example.servercraft.UI.ServicioWeb;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.servercraft.Models.ServicioWeb;
import com.example.servercraft.R;
import com.example.servercraft.Utils.UserInfo;
import com.example.servercraft.ViewModels.ServicioWeb.ListarServicioWebViewModel;
import com.example.servercraft.databinding.ActivityListarServicioWebBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

import androidx.annotation.NonNull;

import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import java.util.Objects;

public class ListarServicioWeb extends AppCompatActivity {
    ServicioWebAdapter servicioWebAdapter;
    ListarServicioWebViewModel listarServicioWebViewModel;
    FormularioServicioWebFragment formularioServicioWebFragment;
    private ActivityListarServicioWebBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Configuración binding de layout
        binding = ActivityListarServicioWebBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        int userRol = new UserInfo().getUserRol();

        // Configuración View Model
        listarServicioWebViewModel = new ViewModelProvider(this).get(ListarServicioWebViewModel.class);

        // Botón flotante
        binding.btnCrearServicioWeb.setOnClickListener(v -> {
            formularioServicioWebFragment = FormularioServicioWebFragment.newInstance(null);
            formularioServicioWebFragment.show(getSupportFragmentManager(), formularioServicioWebFragment.getTag());
        });

        // Toolbar
        Toolbar toolbar = binding.tbMainServicioWeb.tbMain;
        ImageView ivToolbarImage = binding.tbMainServicioWeb.ivTbUsuario;
        TextView tvTbTitle = binding.tbMainServicioWeb.tvTbTitle;
        TextView tvTbDescripcion = binding.tbMainServicioWeb.tvTbDescripcion;

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        if (userRol == 3) {
            binding.btnCrearServicioWeb.setVisibility(View.GONE);
        }

        ivToolbarImage.setVisibility(View.GONE);
        tvTbTitle.setText("Servicio web");
        tvTbDescripcion.setText("Administrar servicios disponibles para aplicaciones");


        toolbar.setContentInsetStartWithNavigation(0);
        toolbar.setNavigationOnClickListener(v -> {
            finish();
        });

        // Elements
        binding.pbHttpLoadingServicioWeb.setVisibility(View.VISIBLE);
        binding.rvServiciosWeb.setLayoutManager(new LinearLayoutManager(this));
        binding.tbMainServicioWeb.cvUsuarioMenuPrincipal.setVisibility(View.GONE);

        // Observador de consulta HTTP
        listarServicioWebViewModel.getServicioWebList().observe(this, serviciosWeb -> {
            if (servicioWebAdapter == null) {
                servicioWebAdapter = new ServicioWebAdapter(this, serviciosWeb, getSupportFragmentManager());

                binding.rvServiciosWeb.setAdapter(servicioWebAdapter);

                binding.pbHttpLoadingServicioWeb.setVisibility(View.INVISIBLE);
            } else {
                binding.rvServiciosWeb.post(new Runnable() {
                    public void run() {
                        servicioWebAdapter.notifyItemRangeChanged(0, serviciosWeb.size() - 1);
                    }
                });
            }
        });

        binding.btnBuscarServicioWeb.setOnClickListener(v -> {
            Log.d("Boton", "apretado");
            binding.pbHttpLoadingServicioWeb.setVisibility(View.VISIBLE);
            listarServicioWebViewModel.blPuedeCargarMas = true;
            listarServicioWebViewModel.busqueda = binding.etServicioWebBusqueda.getText().toString();
            listarServicioWebViewModel.pagina = 0;
            listarServicioWebViewModel.arServiciosWeb.clear();
            listarServicioWebViewModel.loadHTTPServicioWebList();
            servicioWebAdapter = null;
        });

        // Listener de scroll para cargar siguientes páginas
        binding.rvServiciosWeb.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                if (!listarServicioWebViewModel.cargandoDatos) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == listarServicioWebViewModel.arServiciosWeb.size() - 1) {
                        listarServicioWebViewModel.cargandoDatos = true;
                        listarServicioWebViewModel.loadHTTPServicioWebList();
                    }
                }
            }
        });
    }
}
