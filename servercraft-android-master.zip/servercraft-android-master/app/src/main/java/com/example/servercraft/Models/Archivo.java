package com.example.servercraft.Models;

public class Archivo {
    // Attributes
    public String url, name, extname, mimeType;
    public int size;

}
