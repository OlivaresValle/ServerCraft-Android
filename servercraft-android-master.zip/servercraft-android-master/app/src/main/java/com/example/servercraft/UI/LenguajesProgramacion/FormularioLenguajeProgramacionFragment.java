package com.example.servercraft.UI.LenguajesProgramacion;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;
import com.example.servercraft.Models.Lenguaje;
import com.example.servercraft.Utils.AdapterMaterialSpinner;
import com.example.servercraft.ViewModels.LenguajesProgramacion.FormularioLenguaje.FormularioLenguajeViewModel;
import com.example.servercraft.ViewModels.LenguajesProgramacion.FormularioLenguaje.FormularioLenguajeViewModelFactory;
import com.example.servercraft.databinding.FragmentFormularioLenguajeProgramacionBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class FormularioLenguajeProgramacionFragment extends BottomSheetDialogFragment implements Validator.ValidationListener{
    private static final String ARG_LENGUAJE = "lenguaje";
    private FormularioLenguajeViewModel formularioViewModel;
    private FragmentFormularioLenguajeProgramacionBinding binding;

    private Validator validator;
    private View root;

    // Validaciones
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etLenguajeNombre;

    public static FormularioLenguajeProgramacionFragment newInstance(@Nullable Lenguaje lenguaje) {
        FormularioLenguajeProgramacionFragment fragment = new FormularioLenguajeProgramacionFragment();

        if (lenguaje != null) {
            Bundle bundle = new Bundle();
            Gson gson = new Gson();

            bundle.putString(ARG_LENGUAJE, gson.toJson(lenguaje));
            fragment.setArguments(bundle);
        }

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Lenguaje lenguaje = null;

        if (getArguments() != null) {
            Gson gson = new Gson();
            lenguaje = gson.fromJson(getArguments().getString(ARG_LENGUAJE), Lenguaje.class);
        }

        formularioViewModel = new ViewModelProvider(this, new FormularioLenguajeViewModelFactory(lenguaje)).get(FormularioLenguajeViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentFormularioLenguajeProgramacionBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.setValidationListener(this);

        // Intanciamiento de los campos a validar
        etLenguajeNombre = binding.etLenguajeNombre;

        // Loading Status
        binding.clLoadingLenguajeForm.setVisibility(View.VISIBLE);
        binding.lSubmitLenguajeForm.setVisibility(View.GONE);

        // Configuración de botón de creación
        binding.btnCrearLenguajeForm.setOnClickListener(v -> {
            validator.validate();
        });

        // Modificar título en caso de que se esté intentando editar un servidor
        if (formularioViewModel != null && formularioViewModel.hasLenguaje()) {
            binding.tvLenguajeFormTitle.setText("Editar lenguaje");
            binding.btnCrearLenguajeForm.setText("Actualizar lenguaje");
        }

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Solo cargar datos cuando el formulario sea de edición.
        if (formularioViewModel != null && formularioViewModel.hasLenguaje()) {
            formularioViewModel.getLenguaje().observe(getViewLifecycleOwner(), lenguaje -> {
                binding.etLenguajeNombre.setText(lenguaje.nombre);
            });
        }

        binding.clLoadingLenguajeForm.setVisibility(View.GONE);
        binding.lSubmitLenguajeForm.setVisibility(View.VISIBLE);
    }

    private void updateLenguajeList() {
        getActivity().finish();
        getActivity().overridePendingTransition(0, 0);
        getActivity().startActivity(getActivity().getIntent());
        getActivity().overridePendingTransition(0, 0);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }


    @Override
    public void onValidationSucceeded() {
        // Se muestra animación de cargando
        binding.clLoadingLenguajeForm.setVisibility(View.VISIBLE);
        binding.lSubmitLenguajeForm.setVisibility(View.GONE);
        binding.tvLoadingLenguajeForm.setText("Guardando datos");

        // Manejo de datos
        Gson gson = new Gson();
        Lenguaje lenguaje = new Lenguaje();

        lenguaje.nombre = binding.etLenguajeNombre.getText().toString();

        JSONObject request = new JSONObject();

        try {
            request.put("lenguajeProgramacion", new JSONObject(gson.toJson(lenguaje)));
        } catch (JSONException ignored) {
        }

        if (formularioViewModel != null && formularioViewModel.hasLenguaje()) {
            lenguaje.actualizar(formularioViewModel.getLenguaje().getValue().id, request, response -> {
                binding.clLoadingLenguajeForm.setVisibility(View.GONE);
                binding.lSubmitLenguajeForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateLenguajeList();
            }, error -> {
                binding.clLoadingLenguajeForm.setVisibility(View.GONE);
                binding.lSubmitLenguajeForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al actualizar lenguaje de programacion", Toast.LENGTH_SHORT).show();
            });
        } else {
            lenguaje.crear(request, response -> {
                binding.clLoadingLenguajeForm.setVisibility(View.GONE);
                binding.lSubmitLenguajeForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateLenguajeList();
            }, error -> {
                binding.clLoadingLenguajeForm.setVisibility(View.GONE);
                binding.lSubmitLenguajeForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al crear lenguaje de programación", Toast.LENGTH_SHORT).show();
            });
        }
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        AdapterMaterialSpinner.onErrorChanges(errors);
    }
}