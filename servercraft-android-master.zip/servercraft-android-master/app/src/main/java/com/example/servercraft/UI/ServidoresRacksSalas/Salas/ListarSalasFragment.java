package com.example.servercraft.UI.ServidoresRacksSalas.Salas;

import android.app.Activity;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import com.example.servercraft.R;
import com.example.servercraft.ViewModels.ServidoresRacksSalas.Salas.ListarSalasViewModel;
import com.example.servercraft.databinding.FragmentListarSalasBinding;

public class ListarSalasFragment extends Fragment {
    public ListarSalasViewModel listarViewModel;
    private FragmentListarSalasBinding binding;
    private SalaItemAdapter salaItemAdapter;
    private boolean iniciado = false;

    public static ListarSalasFragment newInstance() {
        return new ListarSalasFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        listarViewModel = new ViewModelProvider(this).get(ListarSalasViewModel.class);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        Activity parent = getActivity();
        binding = FragmentListarSalasBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Elements
        ProgressBar spinner = parent.findViewById(R.id.pbHttpLoading);

        // Configuración inicial de elementos
        spinner.setVisibility(View.INVISIBLE);
        binding.pbHttpLoadingSala.setVisibility(View.INVISIBLE);
        binding.rvSalas.setLayoutManager(new LinearLayoutManager(root.getContext()));

        if (iniciado) {
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etBuscarSala.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arSalas.clear();
            listarViewModel.loadHTTPSalasList();
            salaItemAdapter = null;
            binding.pbHttpLoadingSala.setVisibility(View.VISIBLE);
        }

        // Observador de consulta HTTP
        listarViewModel.getSalasList().observe(getViewLifecycleOwner(), salas -> {
            iniciado = true;
            if (salaItemAdapter == null) {
                salaItemAdapter = new SalaItemAdapter(root.getContext(), salas, getChildFragmentManager());
                binding.rvSalas.setAdapter(salaItemAdapter);
                spinner.setVisibility(View.INVISIBLE);

                binding.pbHttpLoadingSala.setVisibility(View.INVISIBLE);
            } else {
                binding.rvSalas.post(new Runnable() {
                    public void run() {
                        salaItemAdapter.notifyItemRangeChanged(0,salas.size() - 1);
                    }
                });
            }
        });

        binding.btnBuscarSala.setOnClickListener(v -> {
            Log.d("Boton", "apretado");
            binding.pbHttpLoadingSala.setVisibility(View.VISIBLE);
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etBuscarSala.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arSalas.clear();
            listarViewModel.loadHTTPSalasList();
            salaItemAdapter = null;
        });

        // Listener de scroll para cargar siguientes páginas
        binding.rvSalas.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                if (!listarViewModel.cargandoDatos) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == listarViewModel.arSalas.size() - 1) {
                        listarViewModel.cargandoDatos = true;
                        listarViewModel.loadHTTPSalasList();
                    }
                }
            }
        });


        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}