package com.example.servercraft.Models;

import androidx.annotation.Nullable;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.servercraft.Utils.ServercraftApplication;

import org.json.JSONObject;

import java.util.Map;

public class Usuario extends BaseHTTP {
    // Constants
    private final String ENDPOINT_BASE = super.HOST + "/usuario";

    // Attributes
    public int id;
    public String rut;
    public String nombre;
    public String apellidos;
    public String email;
    public String password;
    public String telefonoContacto;
    public Archivo imagen;
    public int idRol;
    public Integer idEquipoTrabajo;

    public boolean isFullyVisible = false;

    // Relations
    public Rol rol;
    public EquipoTrabajo equipoTrabajo;

    // Constructor
    public Usuario() {
        super();
    }

    // To String
    @Override
    public String toString() {
        return nombre;
    }

    // Equals
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Usuario that = (Usuario) o;

        return id == that.id;
    }

    // HTTP methods
    public void listar(int por_pagina, int pagina, @Nullable String q, @Nullable JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_INDEX = ENDPOINT_BASE + "?limit="+ por_pagina +"&page=" + pagina +  (q != null ? "&q="+q : "");

        JsonObjectRequest listarusuarios = new JsonObjectRequest(Request.Method.GET, ENDPOINT_INDEX, request, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() {
                return Usuario.super.headers;
            }
        };

        queue.add(listarusuarios);
    }

    public void obtener(int idUsuario, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError, @Nullable String token) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/" + idUsuario;

        JsonObjectRequest obtenerUsuario = new JsonObjectRequest(Request.Method.GET, ENDPOINT_DETAIL, null, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() {
                if (token != null) {
                    Usuario.super.headers.put("Authorization", "Bearer " + token);
                }
                return Usuario.super.headers;
            }
        };
        queue.add(obtenerUsuario);
    }

    public void crear(JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());

        JsonObjectRequest crearUsuario = new JsonObjectRequest(Request.Method.POST, ENDPOINT_BASE, request, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() {
                return Usuario.super.headers;
            }
        };

        queue.add(crearUsuario);
    }

    public void actualizar(int idUsuario, JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/" + idUsuario;

        JsonObjectRequest actualizarUsuario = new JsonObjectRequest(Request.Method.PUT, ENDPOINT_DETAIL, request, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() {
                return Usuario.super.headers;
            }
        };

        queue.add(actualizarUsuario);
    }

    public void actualizarContrasena(JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/contrasena";

        JsonObjectRequest actualizarContrasena = new JsonObjectRequest(Request.Method.PUT, ENDPOINT_DETAIL, request, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() {
                return Usuario.super.headers;
            }
        };

        queue.add(actualizarContrasena);
    }

    public void eliminar(int idUsuario, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/" + idUsuario;

        JsonObjectRequest eliminarUsuario = new JsonObjectRequest(Request.Method.DELETE, ENDPOINT_DETAIL, null, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() {
                return Usuario.super.headers;
            }
        };

        queue.add(eliminarUsuario);
    }

}
