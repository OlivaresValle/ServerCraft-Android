package com.example.servercraft.ViewModels.ServidoresRacksSalas.Servidores;

import android.util.Log;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.servercraft.Models.Lenguaje;
import com.example.servercraft.Models.Servidor;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Objects;

public class ListarServidoresViewModel extends ViewModel {
    private MutableLiveData<ArrayList<Servidor>> mServerList;
    public ArrayList<Servidor> arServidor = new ArrayList<>();

    public boolean cargandoDatos = false;
    public boolean blPuedeCargarMas = true;
    public int pagina = 0;
    public String busqueda = "";

    // Constructor
    public ListarServidoresViewModel() {
        mServerList = new MutableLiveData<>();
        loadHTTPServerList();
    }

    // Getters
    public MutableLiveData<ArrayList<Servidor>> getServerList() {
        return mServerList;
    }

    // Setters
    public void loadHTTPServerList() {
        if (blPuedeCargarMas) {
            Servidor servidor = new Servidor();

            pagina = pagina + 1;

            if (arServidor.size() != 0) {
                arServidor.add(null);
                mServerList.setValue(arServidor);
            }



        servidor.listar(10,pagina,busqueda,null, response -> {
            try {
                JSONArray httpServers = response.getJSONArray("servidores");
                JSONObject httpMeta = response.getJSONObject("meta");

                Log.d("Resultados",httpServers.toString());

                arServidor.removeIf(Objects::isNull);


                if (httpMeta.getInt("last_page") == pagina) {
                    blPuedeCargarMas = false;
                }

                arServidor.addAll(mapServerIntoObject(httpServers));

                mServerList.setValue(arServidor);

                cargandoDatos = false;
            } catch (JSONException e) {
                Log.e("Listar leng", e.toString());
            }
        }, error -> Log.d("Error de ", error.toString()));
        }
    }

    private ArrayList<Servidor> mapServerIntoObject(JSONArray httpServers) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type ServerArray = new TypeToken<ArrayList<Servidor>>() {
        }.getType();
        ArrayList<Servidor> serverList = gson.fromJson(httpServers.toString(), ServerArray);

        return serverList;
    }
}
