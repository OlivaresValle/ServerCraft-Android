package com.example.servercraft.Models;

public class EstadisticaIncidente {
    // Attributes
    public int mes;
    public int contador;

    // Constructor
    public EstadisticaIncidente() {
        super();
    }

    // To String
    @Override
    public String toString() {
        return "mes " + mes + " incidentes " + contador;
    }
}
