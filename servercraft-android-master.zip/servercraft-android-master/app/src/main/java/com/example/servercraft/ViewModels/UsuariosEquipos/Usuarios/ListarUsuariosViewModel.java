package com.example.servercraft.ViewModels.UsuariosEquipos.Usuarios;

import android.util.Log;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.servercraft.Models.Lenguaje;
import com.example.servercraft.Models.Usuario;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Objects;

public class ListarUsuariosViewModel extends ViewModel {
    private MutableLiveData<ArrayList<Usuario>> mUserList;
    public ArrayList<Usuario> arUsuario = new ArrayList<>();

    public boolean cargandoDatos = false;
    public boolean blPuedeCargarMas = true;
    public int pagina = 0;
    public String busqueda = "";

    // Constructor
    public ListarUsuariosViewModel() {
        mUserList = new MutableLiveData<>();

        loadHTTPUserList();
    }

    // Getters
    public MutableLiveData<ArrayList<Usuario>> getUserList() {
        return mUserList;
    }

    // Setters
    public void loadHTTPUserList() {

        if (blPuedeCargarMas) {
            Usuario usuario = new Usuario();
            pagina = pagina + 1;

            if (arUsuario.size() != 0) {
                arUsuario.add(null);
                mUserList.setValue(arUsuario);
            }

            usuario.listar(10, pagina, busqueda, null, response -> {
                try {
                    JSONArray httpUsers = response.getJSONArray("usuarios");
                    JSONObject httpMeta = response.getJSONObject("meta");

                    Log.d("Resultados",httpUsers.toString());

                    arUsuario.removeIf(Objects::isNull);


                    if (httpMeta.getInt("last_page") == pagina) {
                        blPuedeCargarMas = false;
                    }

                    arUsuario.addAll(mapUsersIntoObject(httpUsers));

                    mUserList.setValue(arUsuario);

                    cargandoDatos = false;
                } catch (JSONException e) {
                    Log.e("Listar leng", e.toString());
                }
            }, error -> Log.d("Error de ", error.toString()));
        }
    }

    private ArrayList<Usuario> mapUsersIntoObject(JSONArray httpUsers) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type UserArray = new TypeToken<ArrayList<Usuario>>() {}.getType();
        ArrayList<Usuario> userList = gson.fromJson(httpUsers.toString(), UserArray);

        return userList;
    }
}



