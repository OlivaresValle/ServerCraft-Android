package com.example.servercraft.UI.ClientesProveedores;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.servercraft.UI.ClientesProveedores.EquipoProveedor.FormularioEquipoProveedorFragment;
import com.example.servercraft.UI.ClientesProveedores.Proveedores.FormularioProveedorFragment;
import com.example.servercraft.Utils.UserInfo;
import com.example.servercraft.databinding.ActivityClientesProveedoresBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;

import java.util.Objects;

public class ClientesProveedores extends AppCompatActivity {
    private ActivityClientesProveedoresBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Configuración binding de layout
        binding = ActivityClientesProveedoresBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        int userRol = new UserInfo().getUserRol();


        // Botón flotante
        binding.btnCrearProveedor.setOnClickListener(v -> {
            FormularioProveedorFragment formulario = FormularioProveedorFragment.newInstance(null);
            formulario.show(getSupportFragmentManager(), formulario.getTag());
        });

        // Toolbar


        Toolbar toolbar = binding.tbMainProveedor.tbMain;
        TextView tvTbTitle = binding.tbMainProveedor.tvTbTitle;

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        binding.tbMainProveedor.cvUsuarioMenuPrincipal.setVisibility(View.GONE);
        tvTbTitle.setText("Proveedores");
        toolbar.setContentInsetStartWithNavigation(0);
        toolbar.setNavigationOnClickListener(v -> {
            finish();
        });

        // Configuración Tabs
        ClientesProveedoresPagerAdapter sectionsPagerAdapter = new ClientesProveedoresPagerAdapter(this, getSupportFragmentManager());
        ViewPager viewPager = binding.vpProveedorTabs;
        viewPager.setAdapter(sectionsPagerAdapter);

        TabLayout tabs = binding.tabProveedor;
        tabs.setupWithViewPager(viewPager);

        if (userRol == 1) {
            binding.btnCrearProveedor.setVisibility(View.VISIBLE);
        } else {
            binding.btnCrearProveedor.setVisibility(View.INVISIBLE);
        }

        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                switch (position) {
                    case 0:
                        tvTbTitle.setText("Proveedores");

                        if (userRol == 1) {
                            binding.btnCrearProveedor.setVisibility(View.VISIBLE);
                        } else {
                            binding.btnCrearProveedor.setVisibility(View.INVISIBLE);
                        }

                        binding.btnCrearProveedor.setOnClickListener(v -> {


                            FormularioProveedorFragment formulario = FormularioProveedorFragment.newInstance(null);
                            formulario.show(getSupportFragmentManager(), formulario.getTag());
                        });

                        break;
                    case 1:
                        tvTbTitle.setText("Equipos de proveedores");

                        if (userRol == 1 || userRol == 2) {
                            binding.btnCrearProveedor.setVisibility(View.VISIBLE);
                        } else {
                            binding.btnCrearProveedor.setVisibility(View.INVISIBLE);
                        }

                        binding.btnCrearProveedor.setOnClickListener(v -> {
                            FormularioEquipoProveedorFragment formulario = FormularioEquipoProveedorFragment.newInstance(null);
                            formulario.show(getSupportFragmentManager(), formulario.getTag());
                        });

                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}