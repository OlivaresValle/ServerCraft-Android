package com.example.servercraft.Models;

public class Token {
    // Attributes
    private String type;
    private String token;

    // Getters & Setters
    public String getToken() {
        return token;
    }
}
