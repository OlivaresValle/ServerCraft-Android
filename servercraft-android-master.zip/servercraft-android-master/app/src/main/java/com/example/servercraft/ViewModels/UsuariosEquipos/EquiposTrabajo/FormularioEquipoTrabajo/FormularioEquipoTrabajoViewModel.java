package com.example.servercraft.ViewModels.UsuariosEquipos.EquiposTrabajo.FormularioEquipoTrabajo;

import android.util.Log;
import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.EquipoTrabajo;
import com.example.servercraft.Models.UnidadNegocio;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.JSONArray;
import org.json.JSONException;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class FormularioEquipoTrabajoViewModel extends ViewModel {
    private MutableLiveData<EquipoTrabajo> mEquipoTrabajo;
    private MutableLiveData<ArrayList<UnidadNegocio>> mUnidadesNegocio;



    // Constructor
    public FormularioEquipoTrabajoViewModel(@Nullable EquipoTrabajo equipoTrabajo) {
        mEquipoTrabajo = new MutableLiveData<>();
        mUnidadesNegocio = new MutableLiveData<>();

        if (equipoTrabajo != null) {
            mEquipoTrabajo.setValue(equipoTrabajo);
        }

        loadHTTPUnidadesList();
    }

    // Getters
    public MutableLiveData<EquipoTrabajo> getEquipoTrabajo() {
        return mEquipoTrabajo;
    }

    public MutableLiveData<ArrayList<UnidadNegocio>> getUnidadesNegocioList() {
        return mUnidadesNegocio;
    }

    public boolean hasEquipoTrabajo() {
        return mEquipoTrabajo.getValue() != null;
    }

    // Setters
    private void loadHTTPUnidadesList() {
        UnidadNegocio unidadNegocio = new UnidadNegocio();

        unidadNegocio.listar(1000,1,null,null, response -> {
            try {
                JSONArray httpUnidades = response.getJSONArray("unidades_negocio");
                ArrayList<UnidadNegocio> objectUnidades = mapUnidadesIntoObject(httpUnidades);

                mUnidadesNegocio.setValue(objectUnidades);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<UnidadNegocio> mapUnidadesIntoObject(JSONArray httpUnidades) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type UnidadNegocioArray = new TypeToken<ArrayList<UnidadNegocio>>() {}.getType();
        ArrayList<UnidadNegocio> unidadNegocioList = gson.fromJson(httpUnidades.toString(), UnidadNegocioArray);

        return unidadNegocioList;
    }
}
