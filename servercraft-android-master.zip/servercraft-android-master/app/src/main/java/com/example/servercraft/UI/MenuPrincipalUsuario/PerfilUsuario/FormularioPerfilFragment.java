package com.example.servercraft.UI.MenuPrincipalUsuario.PerfilUsuario;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.servercraft.Models.Usuario;
import com.example.servercraft.R;
import com.example.servercraft.Utils.AdapterMaterialSpinner;
import com.example.servercraft.Utils.Images;
import com.example.servercraft.ViewModels.MenuPrincipalUsuario.PerfilViewModel;
import com.example.servercraft.databinding.FragmentFormularioPerfilBinding;
import com.google.gson.Gson;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.Email;
import com.mobsandgeeks.saripaar.annotation.Length;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class FormularioPerfilFragment extends Fragment implements Validator.ValidationListener {
    private PerfilViewModel perfilViewModel;
    private FragmentFormularioPerfilBinding binding;
    private Uri selectedImage;
    private View root;
    private Validator validator;
    private Usuario user;

    // Validaciones
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etNombre;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etApellidos;

    @NotEmpty(message = "Campo obligatorio")
    @Email(message = "Ingrese un email válido")
    EditText etEmail;

    @Length(min = 9, max = 9, message = "El número debe ser de 9 dígitos")
    @NotEmpty(message = "Campo obligatorio")
    EditText etTelefonoContacto;

    public static FormularioPerfilFragment newInstance() {
        FormularioPerfilFragment fragment = new FormularioPerfilFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        perfilViewModel = new ViewModelProvider(this).get(PerfilViewModel.class);
    }

    ActivityResultLauncher<Intent> mStartForResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    selectedImage = result.getData().getData();
                    Picasso.get().load(selectedImage).into(binding.ivUsuario);
                }
            });

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentFormularioPerfilBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.setValidationListener(this);

        // Inicialización de variables
        etNombre = binding.etNombreUsuario;
        etApellidos = binding.etApellidosUsuario;
        etEmail = binding.etEmailUsuario;
        etTelefonoContacto = binding.etTelefonoUsuario;

        // Observador de consulta HTTP
        perfilViewModel.getUser().observe(getViewLifecycleOwner(), usuario -> {
            user = usuario;

            if (usuario.imagen != null) {
                Picasso.get().load(usuario.imagen.url).into(binding.ivUsuario);
            }

            binding.etNombreUsuario.setText(usuario.nombre);
            binding.etApellidosUsuario.setText(usuario.apellidos);
            binding.etEmailUsuario.setText(usuario.email);
            binding.etTelefonoUsuario.setText(usuario.telefonoContacto);

            binding.btnActualizaImgPerfil.setOnClickListener(v -> {
                Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                mStartForResult.launch(i);
            });

            binding.btnActualizarPerfil.setOnClickListener(v -> {
                validator.validate();
            });
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onValidationSucceeded() {
        // Manejo de datos
        Gson gson = new Gson();
        Usuario usuarioActualizado = new Usuario();

        usuarioActualizado.nombre = binding.etNombreUsuario.getText().toString();
        usuarioActualizado.apellidos = binding.etApellidosUsuario.getText().toString();
        usuarioActualizado.email = binding.etEmailUsuario.getText().toString();
        usuarioActualizado.telefonoContacto = binding.etTelefonoUsuario.getText().toString();
        usuarioActualizado.idRol = user.rol.id;
        usuarioActualizado.idEquipoTrabajo = user.equipoTrabajo != null ? user.equipoTrabajo.id : null;

        JSONObject request = new JSONObject();

        if (selectedImage != null) {
            try {
                InputStream imageStream;
                imageStream = getActivity().getContentResolver().openInputStream(selectedImage);

                new Images().uploadImage(new Images().getBytes(imageStream));

                Picasso.get().load(selectedImage).into((ImageView) getActivity().findViewById(R.id.ivTbUsuario));
            } catch (IOException e) {
                e.printStackTrace();
                Picasso.get().load(user.imagen.url).into((ImageView) getActivity().findViewById(R.id.ivTbUsuario));
            }

            selectedImage = null;
        }

        try {
            request.put("usuario", new JSONObject(gson.toJson(usuarioActualizado)));
        } catch (JSONException ignored) {
        }

        usuarioActualizado.actualizar(user.id, request, response -> {
            Toast.makeText(root.getContext(), "Perfil actualizado correctamente", Toast.LENGTH_SHORT).show();
        }, error -> {
            Toast.makeText(root.getContext(), "Error al actualizar usuario", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        AdapterMaterialSpinner.onErrorChanges(errors);
    }
}