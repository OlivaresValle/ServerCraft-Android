package com.example.servercraft.ViewModels.ServidoresRacksSalas.Salas.DetalleSala;

import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import com.example.servercraft.Models.Sala;

public class DetalleSalaViewModelFactory implements ViewModelProvider.Factory {
    private Sala mSala;

    public DetalleSalaViewModelFactory(@Nullable Sala sala) {
        if (sala != null) {
            this.mSala = sala;
        }
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        return (T) new DetalleSalaViewModel(mSala);
    }
}
