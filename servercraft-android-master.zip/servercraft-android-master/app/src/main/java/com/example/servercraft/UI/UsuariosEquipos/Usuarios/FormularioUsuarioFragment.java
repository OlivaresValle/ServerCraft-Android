package com.example.servercraft.UI.UsuariosEquipos.Usuarios;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.chivorn.smartmaterialspinner.SmartMaterialSpinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.example.servercraft.Models.EquipoTrabajo;
import com.example.servercraft.Models.Usuario;
import com.example.servercraft.Models.Rol;
import com.example.servercraft.Utils.AdapterMaterialSpinner;
import com.example.servercraft.ViewModels.UsuariosEquipos.Usuarios.DetalleUsuario.DetalleUsuarioViewModel;
import com.example.servercraft.ViewModels.UsuariosEquipos.Usuarios.DetalleUsuario.DetalleUsuarioViewModelFactory;
import com.example.servercraft.ViewModels.UsuariosEquipos.Usuarios.FormularioUsuarioViewModel;
import com.example.servercraft.databinding.FragmentFormularioUsuarioBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.Digits;
import com.mobsandgeeks.saripaar.annotation.Email;
import com.mobsandgeeks.saripaar.annotation.Length;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Password;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;


public class FormularioUsuarioFragment extends BottomSheetDialogFragment implements Validator.ValidationListener {
    // Configuración de View Model
    private static final String ARG_ID_USER = "id_usuario";
    private DetalleUsuarioViewModel detalleViewModel;
    private FormularioUsuarioViewModel formularioViewModel;
    private FragmentFormularioUsuarioBinding binding;
    private View root;
    private Validator validator;

    // Validaciones
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etNombre;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etApellidos;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etRut;

    @NotEmpty(message = "Campo obligatorio")
    @Email(message = "Ingrese un email válido")
    EditText etEmail;

    @NotEmpty(message = "Campo obligatorio")
    @Password(min = 6, message = "La contraseña debe ser mayor a 6 caracteres")
    EditText etPassword;

    @Length(min = 9, max = 9, message = "El número debe ser de 9 dígitos")
    @NotEmpty(message = "Campo obligatorio")
    EditText etTelefonoContacto;


    // Spinners
    @NotEmpty(message = "Campo obligatorio")
    SmartMaterialSpinner<Rol> spRol;

    SmartMaterialSpinner<EquipoTrabajo> spEquipos;

    public static FormularioUsuarioFragment newInstance(@Nullable Integer idUsuario) {
        FormularioUsuarioFragment fragment = new FormularioUsuarioFragment();

        if (idUsuario != null) {
            Bundle bundle = new Bundle();

            bundle.putInt(ARG_ID_USER, idUsuario);
            fragment.setArguments(bundle);
        }

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            Integer usuarioId = getArguments().getInt(ARG_ID_USER);

            detalleViewModel = new ViewModelProvider(this, new DetalleUsuarioViewModelFactory(usuarioId)).get(DetalleUsuarioViewModel.class);
        }

        formularioViewModel = new ViewModelProvider(this).get(FormularioUsuarioViewModel.class);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentFormularioUsuarioBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        // Loading Status
        binding.clLoadingCrearUsuarioForm.setVisibility(View.VISIBLE);
        binding.llUsuarioFormCrearUsuario.setVisibility(View.GONE);

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.registerAdapter(SmartMaterialSpinner.class, new AdapterMaterialSpinner());
        validator.setValidationListener(this);

        // Intanciamiento de los campos a validar
        etNombre = binding.etNombreCrearUsuario;
        etApellidos = binding.etApellidoCrearUsuario;
        etRut = binding.etRutCrearUsuario;
        etEmail = binding.etEmailCrearUsuario;
        etPassword = binding.etPasswordCrearUsuario;
        etTelefonoContacto = binding.etContactoCrearUsuario;

        // Referenciación de Spinners
        spRol = binding.spRoles;
        spEquipos = binding.spEquipos;


        // Inicialización de spinners con API.
        formularioViewModel.getRolList().observe(getViewLifecycleOwner(), roles -> {
            spRol.setItem(roles);
        });

        formularioViewModel.getEquipoTrabajoList().observe(getViewLifecycleOwner(), equipos -> {
            spEquipos.setItem(equipos);
        });

        // Limpieza de errores al seleccionar
        spRol.setOnItemSelectedListener(AdapterMaterialSpinner.clearSpinner(spRol));

        // Configuración de botón de creación
        binding.btnUsuarioCrear.setOnClickListener(v -> {
            validator.validate();
        });

        // Modificar título en caso de que se esté intentando editar un usuario
        if (detalleViewModel != null && detalleViewModel.hasUser()) {
            binding.tvUsuarioFormTitleCrearUsuario.setText("Editar usuario");
            binding.btnUsuarioCrear.setText("Actualizar usuario");
        }
        return root;
    }

    private void updateUsuarioList() {
        getActivity().finish();
        getActivity().overridePendingTransition(0, 0);
        getActivity().startActivity(getActivity().getIntent());
        getActivity().overridePendingTransition(0, 0);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Solo cargar datos cuando el formulario sea de edición.
        if (detalleViewModel != null && detalleViewModel.hasUser()) {
            detalleViewModel.getUser().observe(getViewLifecycleOwner(), usuario -> {
                binding.lControlPasswordCrearUsuario.setVisibility(View.GONE);

                binding.etNombreCrearUsuario.setText(usuario.nombre);
                binding.etApellidoCrearUsuario.setText(usuario.apellidos);
                binding.etRutCrearUsuario.setText(usuario.rut);
                binding.etEmailCrearUsuario.setText(String.valueOf(usuario.email));
                binding.etContactoCrearUsuario.setText(usuario.telefonoContacto);

                formularioViewModel.getRolList().observe(getViewLifecycleOwner(), roles -> {
                    spRol.setSelection(roles.indexOf(usuario.rol));
                });

                if (usuario.equipoTrabajo != null) {
                    formularioViewModel.getEquipoTrabajoList().observe(getViewLifecycleOwner(), equipos -> {
                        spEquipos.setSelection(equipos.indexOf(usuario.equipoTrabajo));
                    });
                }

                binding.clLoadingCrearUsuarioForm.setVisibility(View.GONE);
                binding.llUsuarioFormCrearUsuario.setVisibility(View.VISIBLE);
            });
        } else {
            binding.clLoadingCrearUsuarioForm.setVisibility(View.GONE);
            binding.llUsuarioFormCrearUsuario.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onValidationSucceeded() {
        // Se muestra animación de cargando
        binding.clLoadingCrearUsuarioForm.setVisibility(View.VISIBLE);
        binding.llUsuarioFormCrearUsuario.setVisibility(View.GONE);
        binding.tvLoadingCrearUsuario.setText("Guardando datos");

        // Manejo de datos
        Gson gson = new Gson();
        Usuario usuario = new Usuario();

        usuario.nombre = etNombre.getText().toString();
        usuario.apellidos = etApellidos.getText().toString();
        usuario.rut = etRut.getText().toString();
        usuario.email = etEmail.getText().toString();
        usuario.password = etPassword.getText().toString();
        usuario.telefonoContacto = etTelefonoContacto.getText().toString();
        usuario.idRol = spRol.getSelectedItem().id;

        try {
            usuario.idEquipoTrabajo = spEquipos.getSelectedItem().id;
        } catch (Exception e) {
            usuario.idEquipoTrabajo = null;
        }

        JSONObject request = new JSONObject();

        try {
            request.put("usuario", new JSONObject(gson.toJson(usuario)));
        } catch (JSONException ignored) {
        }

        if (detalleViewModel != null && detalleViewModel.hasUser()) {
            usuario.actualizar(detalleViewModel.getUserId(), request, response -> {
                binding.clLoadingCrearUsuarioForm.setVisibility(View.GONE);
                binding.llUsuarioFormCrearUsuario.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateUsuarioList();
            }, error -> {
                binding.clLoadingCrearUsuarioForm.setVisibility(View.GONE);
                binding.llUsuarioFormCrearUsuario.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al actualizar usuario", Toast.LENGTH_SHORT).show();
            });
        } else {
            usuario.crear(request, response -> {
                binding.clLoadingCrearUsuarioForm.setVisibility(View.GONE);
                binding.llUsuarioFormCrearUsuario.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateUsuarioList();
            }, error -> {
                binding.clLoadingCrearUsuarioForm.setVisibility(View.GONE);
                binding.llUsuarioFormCrearUsuario.setVisibility(View.VISIBLE);

                Toast.makeText(root.getContext(), "Error al crear usuario", Toast.LENGTH_SHORT).show();
            });
        }
    }


    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        AdapterMaterialSpinner.onErrorChanges(errors);
    }
}
