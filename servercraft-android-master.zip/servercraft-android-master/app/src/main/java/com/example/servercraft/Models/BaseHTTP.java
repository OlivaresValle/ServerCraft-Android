package com.example.servercraft.Models;

import com.example.servercraft.Utils.Preferences;
import java.util.HashMap;
import java.util.Map;

public abstract class BaseHTTP {
    // Attributes
    protected Map<String, String> headers = new HashMap<String, String>();
    protected final String HOST = "https://servercraft-api.herokuapp.com";

    // Constructor
    public BaseHTTP () {
        super();
        this.headers.put("Authorization", "Bearer " + getToken());
    }

    // Methods
    private String getToken () {
        String token = new Preferences("auth").getString("token");

        return token;
    }
}
