package com.example.servercraft.ViewModels.BaseDatos.DetalleBaseDatos;

import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import com.example.servercraft.Models.BaseDatos;

public class DetalleBaseDatosViewModelFactory implements ViewModelProvider.Factory {
    private BaseDatos mBaseDatos;

    public DetalleBaseDatosViewModelFactory(@Nullable BaseDatos baseDatos) {
        if (baseDatos != null) {
            this.mBaseDatos = baseDatos;
        }
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        return (T) new DetalleBaseDatosViewModel(mBaseDatos);
    }
}
