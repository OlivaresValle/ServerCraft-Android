package com.example.servercraft.UI.UsuariosEquipos.UnidadesNegocio;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;
import com.example.servercraft.Models.UnidadNegocio;
import com.example.servercraft.Utils.AdapterMaterialSpinner;
import com.example.servercraft.ViewModels.UsuariosEquipos.UnidadesNegocio.FormularioUnidadNegocio.FormularioUnidadNegocioViewModel;
import com.example.servercraft.ViewModels.UsuariosEquipos.UnidadesNegocio.FormularioUnidadNegocio.FormularioUnidadNegocioViewModelFactory;
import com.example.servercraft.databinding.FragmentFormularioUnidadNegocioBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class FormularioUnidadNegocioFragment extends BottomSheetDialogFragment implements Validator.ValidationListener {
    private static final String ARG_UNIDAD = "unidadNegocio";
    private FormularioUnidadNegocioViewModel formularioViewModel;
    private FragmentFormularioUnidadNegocioBinding binding;
    private View root;
    private Validator validator;

    // Validaciones
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etUnidadNombre;

    public static FormularioUnidadNegocioFragment newInstance(@Nullable UnidadNegocio unidadNegocio) {
        FormularioUnidadNegocioFragment fragment = new FormularioUnidadNegocioFragment();

        if (unidadNegocio != null) {
            Bundle bundle = new Bundle();
            Gson gson = new Gson();

            bundle.putString(ARG_UNIDAD, gson.toJson(unidadNegocio));
            fragment.setArguments(bundle);
        }

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UnidadNegocio unidadNegocio = null;

        if (getArguments() != null) {
            Gson gson = new Gson();
            unidadNegocio = gson.fromJson(getArguments().getString(ARG_UNIDAD), UnidadNegocio.class);
        }

        formularioViewModel = new ViewModelProvider(this, new FormularioUnidadNegocioViewModelFactory(unidadNegocio)).get(FormularioUnidadNegocioViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentFormularioUnidadNegocioBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.setValidationListener(this);

        // Intanciamiento de los campos a validar
        etUnidadNombre = binding.etUnidadNombre;

        // Loading Status
        binding.clLoadingUnidadForm.setVisibility(View.VISIBLE);
        binding.lSubmitUnidadNegocioForm.setVisibility(View.GONE);

        // Configuración de botón de creación
        binding.btnCrearUnidadNegocio.setOnClickListener(v -> {
            validator.validate();
        });

        // Modificar título en caso de que se esté intentando editar un servidor
        if (formularioViewModel != null && formularioViewModel.hasUnidadNegocio()) {
            binding.tvUnidadNegocioFormTitle.setText("Editar unidad de negocio");
            binding.btnCrearUnidadNegocio.setText("Actualizar unidad");
        }

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Solo cargar datos cuando el formulario sea de edición.
        if (formularioViewModel != null && formularioViewModel.hasUnidadNegocio()) {
            formularioViewModel.getUnidadNegocio().observe(getViewLifecycleOwner(), unidadNegocio -> {
                binding.etUnidadNombre.setText(unidadNegocio.nombre);
            });
        }

        binding.clLoadingUnidadForm.setVisibility(View.GONE);
        binding.lSubmitUnidadNegocioForm.setVisibility(View.VISIBLE);
    }

    private void updateUnidadList() {
        getActivity().finish();
        getActivity().overridePendingTransition(0, 0);
        getActivity().startActivity(getActivity().getIntent());
        getActivity().overridePendingTransition(0, 0);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }


    @Override
    public void onValidationSucceeded() {
        // Se muestra animación de cargando
        binding.clLoadingUnidadForm.setVisibility(View.VISIBLE);
        binding.lSubmitUnidadNegocioForm.setVisibility(View.GONE);
        binding.tvLoadingUnidadNegocio.setText("Guardando datos");

        // Manejo de datos
        Gson gson = new Gson();
        UnidadNegocio unidadNegocio = new UnidadNegocio();

        unidadNegocio.nombre = binding.etUnidadNombre.getText().toString();

        JSONObject request = new JSONObject();

        try {
            request.put("unidadNegocio", new JSONObject(gson.toJson(unidadNegocio)));
        } catch (JSONException ignored) {
        }

        if (formularioViewModel != null && formularioViewModel.hasUnidadNegocio()) {
            unidadNegocio.actualizar(formularioViewModel.getUnidadNegocio().getValue().id, request, response -> {
                binding.clLoadingUnidadForm.setVisibility(View.GONE);
                binding.lSubmitUnidadNegocioForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateUnidadList();
            }, error -> {
                binding.clLoadingUnidadForm.setVisibility(View.GONE);
                binding.lSubmitUnidadNegocioForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al actualizar unidad de negocio", Toast.LENGTH_SHORT).show();
            });
        } else {
            unidadNegocio.crear(request, response -> {
                binding.clLoadingUnidadForm.setVisibility(View.GONE);
                binding.lSubmitUnidadNegocioForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateUnidadList();
            }, error -> {
                binding.clLoadingUnidadForm.setVisibility(View.GONE);
                binding.lSubmitUnidadNegocioForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al crear unidad de negocio", Toast.LENGTH_SHORT).show();
            });
        }
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        AdapterMaterialSpinner.onErrorChanges(errors);

    }
}