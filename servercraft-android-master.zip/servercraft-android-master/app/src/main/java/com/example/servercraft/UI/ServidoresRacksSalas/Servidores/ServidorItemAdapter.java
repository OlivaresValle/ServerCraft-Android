package com.example.servercraft.UI.ServidoresRacksSalas.Servidores;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.servercraft.Models.Lenguaje;
import com.example.servercraft.Models.Servidor;
import com.example.servercraft.R;
import com.example.servercraft.UI.LenguajesProgramacion.FormularioLenguajeProgramacionFragment;
import com.example.servercraft.UI.LenguajesProgramacion.LenguajeItemAdapter;
import com.example.servercraft.Utils.UserInfo;

import java.util.ArrayList;

public class ServidorItemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;

    LayoutInflater inflater;
    ArrayList<Servidor> model;
    FragmentManager fragmentManager;
    Context context;

    public ServidorItemAdapter(Context context, ArrayList<Servidor> model, FragmentManager fm) {
        this.inflater = LayoutInflater.from(context);
        this.model = model;
        this.fragmentManager = fm;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = inflater.inflate(R.layout.item_list_general, parent, false);

            return new ServidorItemAdapter.ItemViewHolder(view);
        } else {
            View view = inflater.inflate(R.layout.item_list_loading, parent, false);

            return new ServidorItemAdapter.LoadingViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof ServidorItemAdapter.ItemViewHolder) {
            populateItemRows((ServidorItemAdapter.ItemViewHolder) holder, position);
        } else if (holder instanceof ServidorItemAdapter.LoadingViewHolder) {
            showLoadingView((ServidorItemAdapter.LoadingViewHolder) holder, position);
        }
    }

    @Override
    public int getItemCount() {
        return model == null ? 0 : model.size();
    }

    @Override
    public int getItemViewType(int position) {
        return model.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ConstraintLayout clItemData, clItemActions;
        TextView nombre, tipo;
        Button btnView, btnEdit, btnDelete;



        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            int userRol = new UserInfo().getUserRol();

            nombre = itemView.findViewById(R.id.tvItemTitle);
            tipo = itemView.findViewById(R.id.tvItemDescription);
            clItemData = itemView.findViewById(R.id.clItemData);
            clItemActions = itemView.findViewById(R.id.clItemActions);
            btnView = itemView.findViewById(R.id.btnView);
            btnEdit = itemView.findViewById(R.id.btnUpdate);
            btnDelete = itemView.findViewById(R.id.btnDelete);

            if (userRol == 2 || userRol == 3) {
                btnEdit.setVisibility(View.GONE);
                btnDelete.setVisibility(View.GONE);

            }

            clItemData.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int adapterPosition = getAdapterPosition();
            Servidor servidor = model.get(adapterPosition);
            servidor.isFullyVisible = !servidor.isFullyVisible;

            notifyItemChanged(adapterPosition);
        }
    }


    private class LoadingViewHolder extends RecyclerView.ViewHolder {

        public LoadingViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    private void showLoadingView(ServidorItemAdapter.LoadingViewHolder viewHolder, int position) {
        //ProgressBar would be displayed

    }

    private void populateItemRows(ServidorItemAdapter.ItemViewHolder holder, int position) {


        // Obtención de objeto
        Servidor servidor = model.get(position);

        // Seteo de valores en view holder
        holder.nombre.setText(servidor.nombre);
        holder.tipo.setText(servidor.tipoServidor.nombre);
        holder.clItemActions.setVisibility(servidor.isFullyVisible ? View.VISIBLE : View.GONE);

        // Click listeners
        holder.btnView.setOnClickListener(v -> {
            DetalleServidorFragment detalleServidor = DetalleServidorFragment.newInstance(servidor.id);
            detalleServidor.show(fragmentManager, detalleServidor.getTag());
        });

        holder.btnEdit.setOnClickListener(v -> {
            FormularioServidorFragment formServidor = FormularioServidorFragment.newInstance(servidor.id);
            formServidor.show(fragmentManager, formServidor.getTag());
        });

        holder.btnDelete.setOnClickListener(v -> {
            AlertDialog.Builder confirmation = new AlertDialog.Builder(context);
            confirmation.setTitle("Advertencia")
                    .setMessage("¿Estás seguro de qué deseas eliminar el servidor: \""+servidor.nombre+"\"?")
                    .setCancelable(false)
                    .setPositiveButton("Eliminar", (dialog, which) -> {
                        servidor.eliminar(servidor.id, response -> {
                            ((Activity) context).finish();
                            ((Activity) context).overridePendingTransition(0, 0);
                            ((Activity) context).startActivity(((Activity) context).getIntent());
                            ((Activity) context).overridePendingTransition(0, 0);
                        }, error -> {
                            Toast.makeText(context, "Error al eliminar servidor.", Toast.LENGTH_SHORT).show();
                        });
                    }).setNegativeButton("Cancelar", (dialog, which) -> {
                dialog.dismiss();
            });

            confirmation.create().show();
        });
    }
}
