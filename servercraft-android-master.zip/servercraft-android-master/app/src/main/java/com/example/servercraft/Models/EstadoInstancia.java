package com.example.servercraft.Models;

import androidx.annotation.Nullable;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.servercraft.Utils.ServercraftApplication;
import org.json.JSONObject;
import java.util.Map;

public class EstadoInstancia extends BaseHTTP {
    // Constants
    private final String ENDPOINT_BASE = super.HOST + "/estado_instancia";

    // Attributes
    public int id;
    public String nombre;

    // HTTP Methods
    public void listar(@Nullable JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());

        JsonObjectRequest listarEstadosInstancia = new JsonObjectRequest(Request.Method.GET, ENDPOINT_BASE, request, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() {
                return EstadoInstancia.super.headers;
            }
        };

        queue.add(listarEstadosInstancia);
    }
}
