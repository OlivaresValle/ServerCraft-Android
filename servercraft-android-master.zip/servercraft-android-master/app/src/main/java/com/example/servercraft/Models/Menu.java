package com.example.servercraft.Models;

public class Menu {
    // Attributes
    private int icono;
    private String titulo;
    private String descripcion;

    // Constructor
    public Menu (int icono, String titulo, String descripcion) {
        this.icono = icono;
        this.titulo = titulo;
        this.descripcion = descripcion;
    }

    // Getters & Setters
    public int getIcono() {
        return icono;
    }

    public void setIcono(int icono) {
        this.icono = icono;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
