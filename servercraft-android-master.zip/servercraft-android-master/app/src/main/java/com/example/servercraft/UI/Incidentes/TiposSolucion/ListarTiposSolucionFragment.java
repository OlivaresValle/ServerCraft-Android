package com.example.servercraft.UI.Incidentes.TiposSolucion;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.example.servercraft.R;
import com.example.servercraft.ViewModels.Incidentes.TiposSolucion.ListarTiposSolucionViewModel;
import com.example.servercraft.databinding.FragmentListarTiposSolucionBinding;

public class ListarTiposSolucionFragment extends Fragment {
    public ListarTiposSolucionViewModel listarViewModel;
    private FragmentListarTiposSolucionBinding binding;
    public TipoSolucionItemAdapter tipoSolucionItemAdapter;
    private boolean iniciado = false;

    public static ListarTiposSolucionFragment newInstance() {
        return new ListarTiposSolucionFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        listarViewModel = new ViewModelProvider(this).get(ListarTiposSolucionViewModel.class);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        Activity parent = getActivity();
        binding = FragmentListarTiposSolucionBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Elements
        ProgressBar spinner = parent.findViewById(R.id.pbHttpLoading);
        RecyclerView rvTiposSolucion = binding.rvTiposSolucion;

        // Configuración inicial de elementos
        spinner.setVisibility(View.INVISIBLE);
        rvTiposSolucion.setLayoutManager(new LinearLayoutManager(root.getContext()));
        binding.pbHttpLoadingTipoSolucion.setVisibility(View.VISIBLE);

        if (iniciado) {
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etBuscarTipoSolucion.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arTipoSolucion.clear();
            listarViewModel.loadHTTPTiposList();
            tipoSolucionItemAdapter = null;
            binding.pbHttpLoadingTipoSolucion.setVisibility(View.VISIBLE);
        }

        // Observador de consulta HTTP
        listarViewModel.getTipoSolucionList().observe(getViewLifecycleOwner(), tiposSolucion -> {
            iniciado = true;
            if (tipoSolucionItemAdapter == null) {
                tipoSolucionItemAdapter = new TipoSolucionItemAdapter(root.getContext(), tiposSolucion, getChildFragmentManager());

                binding.rvTiposSolucion.setAdapter(tipoSolucionItemAdapter);
                spinner.setVisibility(View.INVISIBLE);
                binding.pbHttpLoadingTipoSolucion.setVisibility(View.INVISIBLE);
            } else {
                binding.rvTiposSolucion.post(new Runnable() {
                    public void run() {
                        tipoSolucionItemAdapter.notifyItemRangeChanged(0, tiposSolucion.size() - 1);
                    }
                });
            }
        });

        binding.btnBuscarTipoSolucion.setOnClickListener(v -> {
            binding.pbHttpLoadingTipoSolucion.setVisibility(View.VISIBLE);
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etBuscarTipoSolucion.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arTipoSolucion.clear();
            listarViewModel.loadHTTPTiposList();
            tipoSolucionItemAdapter = null;
        });

        binding.rvTiposSolucion.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                if (!listarViewModel.cargandoDatos) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == listarViewModel.arTipoSolucion.size() - 1) {
                        listarViewModel.cargandoDatos = true;
                        listarViewModel.loadHTTPTiposList();
                    }
                }
            }
        });

        return root;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}