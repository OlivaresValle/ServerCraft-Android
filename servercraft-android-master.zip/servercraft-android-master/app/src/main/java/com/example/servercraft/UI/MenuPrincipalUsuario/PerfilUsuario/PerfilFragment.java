package com.example.servercraft.UI.MenuPrincipalUsuario.PerfilUsuario;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;
import com.example.servercraft.R;
import com.example.servercraft.databinding.FragmentPerfilBinding;
import com.google.android.material.tabs.TabLayout;

public class PerfilFragment extends Fragment {
    private FragmentPerfilBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentPerfilBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Configuración Tabs
        PerfilPagerAdapter perfilPagerAdapter = new PerfilPagerAdapter(getContext(), getChildFragmentManager());

        ViewPager viewPager = binding.vpPerfil;
        viewPager.setAdapter(perfilPagerAdapter);

        TabLayout tabs = binding.tabPerfil;
        tabs.setupWithViewPager(viewPager);

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}