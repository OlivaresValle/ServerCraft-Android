package com.example.servercraft.Models;

import androidx.annotation.Nullable;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.servercraft.Utils.ServercraftApplication;
import org.json.JSONObject;
import java.util.Map;
import java.util.Objects;

public class EquipoProveedor extends BaseHTTP {
    // Constants
    private final String ENDPOINT_BASE = super.HOST + "/equipo_encargado";

    // Attributes
    public int id;
    public String nombre;
    public String telefonoContacto;
    public String emailContacto;
    public String nombreRepresentante;
    public int idProveedorSistema;

    // Relations
    public ProveedorSistema proveedorSistema;

    public boolean isFullyVisible = false;

    // Constructor
    public EquipoProveedor() {
        super();
    }

    // To String
    @Override
    public String toString() {
        return nombre;
    }

    // Equals
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        EquipoProveedor that = (EquipoProveedor) o;

        return id == that.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(ENDPOINT_BASE, id, nombre);
    }

    // HTTP Methods
    public void listar (int por_pagina, int pagina, @Nullable String q,@Nullable JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_INDEX = ENDPOINT_BASE + "?limit="+ por_pagina +"&page=" + pagina +  (q != null ? "&q="+q : "");
        JsonObjectRequest listarEquiposProveedor = new JsonObjectRequest(Request.Method.GET, ENDPOINT_INDEX, request, onSuccess, onError){
            @Override
            public Map<String, String> getHeaders() {
                return EquipoProveedor.super.headers;
            }
        };

        queue.add(listarEquiposProveedor);
    }

    public void obtener (int idEquipoProveedor, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/" + idEquipoProveedor;

        JsonObjectRequest obtenerEquipoProveedor = new JsonObjectRequest (Request.Method.GET, ENDPOINT_DETAIL, null, onSuccess, onError){
            @Override
            public Map<String, String> getHeaders() {
                return EquipoProveedor.super.headers;
            }
        };

        queue.add(obtenerEquipoProveedor);
    }

    public void crear (JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());

        JsonObjectRequest crearEquipoProveedor = new JsonObjectRequest (Request.Method.POST, ENDPOINT_BASE, request, onSuccess, onError){
            @Override
            public Map<String, String> getHeaders() {
                return EquipoProveedor.super.headers;
            }
        };

        queue.add(crearEquipoProveedor);
    }

    public void actualizar (int idEquipoProveedor, JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/" + idEquipoProveedor;

        JsonObjectRequest actualizarEquipoProveedor = new JsonObjectRequest (Request.Method.PUT, ENDPOINT_DETAIL, request, onSuccess, onError){
            @Override
            public Map<String, String> getHeaders() {
                return EquipoProveedor.super.headers;
            }
        };

        queue.add(actualizarEquipoProveedor);
    }

    public void eliminar (int idEquipoProveedor, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/" + idEquipoProveedor;

        JsonObjectRequest eliminarEquipoProveedor = new JsonObjectRequest (Request.Method.DELETE, ENDPOINT_DETAIL, null, onSuccess, onError){
            @Override
            public Map<String, String> getHeaders() {
                return EquipoProveedor.super.headers;
            }
        };

        queue.add(eliminarEquipoProveedor);
    }
}
