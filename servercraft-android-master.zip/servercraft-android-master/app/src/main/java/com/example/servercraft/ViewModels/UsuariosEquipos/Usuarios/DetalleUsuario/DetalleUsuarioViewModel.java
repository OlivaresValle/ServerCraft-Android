package com.example.servercraft.ViewModels.UsuariosEquipos.Usuarios.DetalleUsuario;

import android.util.Log;

import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.servercraft.Models.Usuario;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONException;
import org.json.JSONObject;

public class DetalleUsuarioViewModel extends ViewModel {
    private MutableLiveData<Integer> usuarioId;
    private MutableLiveData<Usuario> mUsuario;

    // Constructor
    public DetalleUsuarioViewModel(@Nullable Integer idUsuario) {
        usuarioId = new MutableLiveData<>();
        mUsuario = new MutableLiveData<>();

        if (idUsuario != null) {
            usuarioId.setValue(idUsuario);
            loadHTTPUsuario();
        }
    }

    // Getters
    public MutableLiveData<Usuario> getUser() {
        return mUsuario;
    }

    public Integer getUserId() {
        return usuarioId.getValue();
    }

    public boolean hasUser() {
        return usuarioId.getValue() != null;
    }

    // Setters
    private void loadHTTPUsuario() {
        Usuario usuario = new Usuario();

        usuario.obtener(usuarioId.getValue(), response -> {
            try {
                JSONObject httpUsuario = response.getJSONObject("usuario");
                Usuario objectUsuario = mapUsuarioIntoObject(httpUsuario);

                mUsuario.setValue(objectUsuario);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()), null);
    }

    private Usuario mapUsuarioIntoObject(JSONObject httpUsuario) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Usuario usuario = gson.fromJson(httpUsuario.toString(), Usuario.class);

        return usuario;
    }
}
