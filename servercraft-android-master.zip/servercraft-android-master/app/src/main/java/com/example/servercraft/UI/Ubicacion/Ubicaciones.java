package com.example.servercraft.UI.Ubicacion;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.servercraft.R;
import com.example.servercraft.UI.Ubicacion.Paises.FormularioPaisFragment;
import com.example.servercraft.UI.Ubicacion.Regiones.FormularioRegionFragment;
import com.example.servercraft.databinding.ActivityUbicacionesBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;

public class Ubicaciones extends AppCompatActivity {
    private ActivityUbicacionesBinding binding;
    FloatingActionButton btnCrear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ubicaciones);

        //Configuración binding de Layout
        binding = ActivityUbicacionesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //Boton Flotante

        binding.btnCrearUbicacion.setOnClickListener(view -> {
            FormularioPaisFragment formularioPais = FormularioPaisFragment.newInstance(null);
            formularioPais.show(getSupportFragmentManager(), formularioPais.getTag());
        });

        // Toolbar
        Toolbar toolbar = binding.tbMainUbicacion.tbMain;
        TextView tvTbTitle = binding.tbMainUbicacion.tvTbTitle;

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        binding.tbMainUbicacion.cvUsuarioMenuPrincipal.setVisibility(View.GONE);
        tvTbTitle.setText("Ubicaciones");
        toolbar.setContentInsetStartWithNavigation(0);
        toolbar.setNavigationOnClickListener(v -> {
            finish();
        });

        //Configuración Tabs
        UbicacionPagerAdapter sectionsPagerAdapter = new UbicacionPagerAdapter(this, getSupportFragmentManager());
        ViewPager viewPager = binding.vpUbicacionTabs;
        viewPager.setAdapter(sectionsPagerAdapter);

        TabLayout tabs = binding.tabUbicacion;
        tabs.setupWithViewPager(viewPager);

        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {}

            @Override
            public void onPageSelected(int position) {
                switch (position){
                    case 0:
                        tvTbTitle.setText("Paises");

                        binding.btnCrearUbicacion.setOnClickListener(view -> {
                            FormularioPaisFragment formularioPais = FormularioPaisFragment.newInstance(null);
                            formularioPais.show(getSupportFragmentManager(), formularioPais.getTag());
                        });


                        break;
                    case 1:
                        tvTbTitle.setText("Regiones");

                        binding.btnCrearUbicacion.setOnClickListener(view -> {
                            FormularioRegionFragment formularioRegion = FormularioRegionFragment.newInstance(null);
                            formularioRegion.show(getSupportFragmentManager(), formularioRegion.getTag());
                        });

                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {}
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}