package com.example.servercraft.Utils;

public class UserInfo {
    // Constructor
    public UserInfo() {

    }

    // Setters
    public void setUserImage(String userImage) {
        new Preferences("user").addValue("image",userImage);
    }

    public void setUserRol(int userRol) {
        new Preferences("user").addValue("rol",userRol);
    }

    // Getters
    public int getUserRol() {
        int userRol = new Preferences("user").getInt("rol");

        return userRol;
    }

    public String getUserImage() {
        String userImage = new Preferences("user").getString("image");

        return userImage;
    }
}
