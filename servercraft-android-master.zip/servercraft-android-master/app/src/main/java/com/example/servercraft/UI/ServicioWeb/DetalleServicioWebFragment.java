package com.example.servercraft.UI.ServicioWeb;

import android.os.Bundle;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.ViewModelProvider;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.example.servercraft.Models.ServicioWeb;
import com.example.servercraft.R;
import com.example.servercraft.ViewModels.ServicioWeb.DetalleServicioWeb.DetalleServicioWebViewModel;
import com.example.servercraft.ViewModels.ServicioWeb.DetalleServicioWeb.DetalleServicioWebViewModelFactory;
import com.example.servercraft.databinding.FragmentDetalleServicioWebBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;

public class DetalleServicioWebFragment extends BottomSheetDialogFragment {
    private static final String ARG_SW = "servicio_web";
    private DetalleServicioWebViewModel detalleViewModel;
    private FragmentDetalleServicioWebBinding binding;

    public static DetalleServicioWebFragment newInstance(ServicioWeb servicioWeb) {
        DetalleServicioWebFragment fragment = new DetalleServicioWebFragment();
        Bundle bundle = new Bundle();
        Gson gson = new Gson();

        bundle.putString(ARG_SW, gson.toJson(servicioWeb));
        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ServicioWeb servicioWeb = null;

        if (getArguments() != null) {
            Gson gson = new Gson();
            String jsonServicioWeb = getArguments().getString(ARG_SW);

            servicioWeb = gson.fromJson(jsonServicioWeb, ServicioWeb.class);
        }

        detalleViewModel = new ViewModelProvider(this, new DetalleServicioWebViewModelFactory(servicioWeb)).get(DetalleServicioWebViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentDetalleServicioWebBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Elementos
        LinearLayout llDataSala = root.findViewById(R.id.llServicioWebData);
        ConstraintLayout clLoading = root.findViewById(R.id.clLoadingServicioWebDetalle);

        // Observador de consulta HTTP
        detalleViewModel.getServicioWeb().observe(getViewLifecycleOwner(), servicioWeb -> {
            //Cargar Datos
            TextView tvTitle = root.findViewById(R.id.tvServicioWebTitle);
            TextView tvDescripcion = root.findViewById(R.id.tvServicioWebDescripcion);

            tvTitle.setText(servicioWeb.nombre);
            tvDescripcion.setText(servicioWeb.descripcion);

            // Ocultar vista de "cargando..."
            clLoading.setVisibility(View.GONE);
            llDataSala.setVisibility(View.VISIBLE);
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}