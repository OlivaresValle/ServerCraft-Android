package com.example.servercraft.UI.ServidoresRacksSalas.Salas;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.servercraft.Models.Lenguaje;
import com.example.servercraft.Models.Sala;
import com.example.servercraft.R;
import com.example.servercraft.UI.LenguajesProgramacion.FormularioLenguajeProgramacionFragment;
import com.example.servercraft.UI.LenguajesProgramacion.LenguajeItemAdapter;
import com.example.servercraft.Utils.UserInfo;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class SalaItemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;

    LayoutInflater inflater;
    ArrayList<Sala> model;
    FragmentManager fragmentManager;
    Context context;

    public SalaItemAdapter(Context context, ArrayList<Sala> model, FragmentManager fm) {
        this.inflater = LayoutInflater.from(context);
        this.model = model;
        this.fragmentManager = fm;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = inflater.inflate(R.layout.item_list_general, parent, false);

            return new SalaItemAdapter.ItemViewHolder(view);
        } else {
            View view = inflater.inflate(R.layout.item_list_loading, parent, false);

            return new SalaItemAdapter.LoadingViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof SalaItemAdapter.ItemViewHolder) {
            populateItemRows((SalaItemAdapter.ItemViewHolder) holder, position);
        } else if (holder instanceof SalaItemAdapter.LoadingViewHolder) {
            showLoadingView((SalaItemAdapter.LoadingViewHolder) holder, position);
        }
    }

    @Override
    public int getItemCount() {
        return model == null ? 0 : model.size();
    }

    @Override
    public int getItemViewType(int position) {
        return model.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }


    public class ItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ConstraintLayout clItemData, clItemActions;
        TextView nombre, tipo;
        Button btnView, btnEdit, btnDelete;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            int userRol = new UserInfo().getUserRol();

            nombre = itemView.findViewById(R.id.tvItemTitle);
            tipo = itemView.findViewById(R.id.tvItemDescription);
            clItemData = itemView.findViewById(R.id.clItemData);
            clItemActions = itemView.findViewById(R.id.clItemActions);
            btnView = itemView.findViewById(R.id.btnView);
            btnEdit = itemView.findViewById(R.id.btnUpdate);
            btnDelete = itemView.findViewById(R.id.btnDelete);


            if (userRol == 2 || userRol == 3) {
                btnEdit.setVisibility(View.GONE);
                btnDelete.setVisibility(View.GONE);
            }

            clItemData.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int adapterPosition = getAbsoluteAdapterPosition();
            Sala sala = model.get(adapterPosition);
            sala.isFullyVisible = !sala.isFullyVisible;

            notifyItemChanged(adapterPosition);
        }
    }

    private class LoadingViewHolder extends RecyclerView.ViewHolder {

        public LoadingViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    private void showLoadingView(SalaItemAdapter.LoadingViewHolder viewHolder, int position) {
        //ProgressBar would be displayed

    }

    private void populateItemRows(SalaItemAdapter.ItemViewHolder holder, int position) {

// Obtención de objeto
        // Obtención de objeto
        Sala sala = model.get(position);

        // Seteo de valores en view holder
        holder.nombre.setText(sala.nombre);
        holder.tipo.setText(sala.region.nombre);
        holder.clItemActions.setVisibility(sala.isFullyVisible ? View.VISIBLE : View.GONE);

        // Click listeners
        holder.btnView.setOnClickListener(v -> {
            DetalleSalaFragment detalleSala = DetalleSalaFragment.newInstance(sala);
            detalleSala.show(fragmentManager, detalleSala.getTag());
        });

        holder.btnEdit.setOnClickListener(v -> {
            FormularioSalaFragment formSala = FormularioSalaFragment.newInstance(sala);
            formSala.show(fragmentManager, formSala.getTag());
        });

        holder.btnDelete.setOnClickListener(v -> {
            AlertDialog.Builder confirmation = new AlertDialog.Builder(context);
            confirmation.setTitle("Advertencia")
                    .setMessage("¿Estás seguro de qué deseas eliminar la sala: \""+sala.nombre+"\"?")
                    .setCancelable(false)
                    .setPositiveButton("Eliminar", (dialog, which) -> {
                        sala.eliminar(sala.id, response -> {
                            ((Activity) context).finish();
                            ((Activity) context).overridePendingTransition(0, 0);
                            ((Activity) context).startActivity(((Activity) context).getIntent());
                            ((Activity) context).overridePendingTransition(0, 0);
                        }, error -> {
                            Toast.makeText(context, "Error al eliminar sala.", Toast.LENGTH_SHORT).show();
                        });
                    }).setNegativeButton("Cancelar", (dialog, which) -> {
                dialog.dismiss();
            });

            confirmation.create().show();
        });
    }
}
