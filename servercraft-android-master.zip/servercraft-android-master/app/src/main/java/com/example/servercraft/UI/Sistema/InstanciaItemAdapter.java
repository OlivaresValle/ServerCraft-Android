package com.example.servercraft.UI.Sistema;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.servercraft.Models.Instancia;
import com.example.servercraft.R;
import java.util.ArrayList;

public class InstanciaItemAdapter extends RecyclerView.Adapter<InstanciaItemAdapter.ViewHolder> {
    LayoutInflater inflater;
    ArrayList<Instancia> model;
    FragmentManager fragmentManager;
    Context context;

    public InstanciaItemAdapter(Context context, ArrayList<Instancia> model, FragmentManager fm) {
        this.inflater = LayoutInflater.from(context);
        this.model = model;
        this.fragmentManager = fm;
        this.context = context;
    }

    @NonNull
    @Override
    public InstanciaItemAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list_general, parent, false);
        return new InstanciaItemAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InstanciaItemAdapter.ViewHolder holder, int position) {
        Instancia instancia = model.get(position);
        holder.nombre.setText("Instancia " + position + ": " + instancia.tipoInstancia.nombre);
        holder.estadoInstancia.setText(instancia.estadoInstancia.nombre);
        holder.clItemActions.setVisibility(View.GONE);
        holder.ivChevronDown.setVisibility(View.GONE);

        switch (instancia.estadoInstancia.nombre) {
            case "Operativo":
                holder.estadoInstancia.setTextColor(ContextCompat.getColor(context, R.color.success_500));
                break;

            case "En mantención":
                holder.estadoInstancia.setTextColor(ContextCompat.getColor(context, R.color.warning_500));
                break;

            case "Con errores":
                holder.estadoInstancia.setTextColor(ContextCompat.getColor(context, R.color.danger_500));
                break;

            default:
                holder.estadoInstancia.setTextColor(ContextCompat.getColor(context, R.color.gray_500));
                break;
        }
    }

    @Override
    public int getItemCount() {
        return model.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ConstraintLayout clItemData, clItemActions;
        TextView nombre, estadoInstancia;
        ImageView ivChevronDown;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nombre = itemView.findViewById(R.id.tvItemTitle);
            estadoInstancia = itemView.findViewById(R.id.tvItemDescription);
            clItemData = itemView.findViewById(R.id.clItemData);
            clItemActions = itemView.findViewById(R.id.clItemActions);
            ivChevronDown = itemView.findViewById(R.id.ivChevronDown);
        }
    }
}
