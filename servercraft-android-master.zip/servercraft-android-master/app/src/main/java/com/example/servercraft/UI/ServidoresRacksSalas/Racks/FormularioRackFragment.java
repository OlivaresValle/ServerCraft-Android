package com.example.servercraft.UI.ServidoresRacksSalas.Racks;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Toast;

import com.chivorn.smartmaterialspinner.SmartMaterialSpinner;
import com.example.servercraft.Models.Rack;
import com.example.servercraft.Models.Sala;
import com.example.servercraft.Utils.AdapterMaterialSpinner;
import com.example.servercraft.ViewModels.ServidoresRacksSalas.Racks.DetalleRack.DetalleRackViewModel;
import com.example.servercraft.ViewModels.ServidoresRacksSalas.Racks.DetalleRack.DetalleRackViewModelFactory;
import com.example.servercraft.ViewModels.ServidoresRacksSalas.Racks.FormularioRackViewModel;
import com.example.servercraft.databinding.FragmentFormularioRackBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class FormularioRackFragment extends BottomSheetDialogFragment implements Validator.ValidationListener {
    // Configuración de View Model
    private static final String ARG_RACK = "rack";
    private DetalleRackViewModel detalleViewModel;
    private FormularioRackViewModel formularioViewModel;
    private FragmentFormularioRackBinding binding;
    private View root;
    private Validator validator;


    // Validaciones
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etRegionNombre;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etRegionDescripcion;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    SmartMaterialSpinner<Sala> spSala;
    // Spinners


    public static FormularioRackFragment newInstance(@Nullable Rack rack) {
        FormularioRackFragment fragment = new FormularioRackFragment();

        if (rack != null) {
            Bundle bundle = new Bundle();
            Gson gson = new Gson();

            bundle.putString(ARG_RACK, gson.toJson(rack));
            fragment.setArguments(bundle);
        }

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            Gson gson = new Gson();
            String jsonRack = getArguments().getString(ARG_RACK);
            Rack rack = gson.fromJson(jsonRack, Rack.class);

            detalleViewModel = new ViewModelProvider(this, new DetalleRackViewModelFactory(rack)).get(DetalleRackViewModel.class);
        }

        formularioViewModel = new ViewModelProvider(this).get(FormularioRackViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentFormularioRackBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.registerAdapter(SmartMaterialSpinner.class, new AdapterMaterialSpinner());
        validator.setValidationListener(this);

        // Intanciamiento de los campos a validar
        etRegionNombre = binding.etRackNombre;
        etRegionDescripcion = binding.etRackDescripcion;

        // Loading Status
        binding.clLoadingRackForm.setVisibility(View.VISIBLE);
        binding.lSubmitRackForm.setVisibility(View.GONE);

        // Referenciación de elementos
        spSala = binding.spRackSala;

        // Inicialización de spinners con API.
        formularioViewModel.getSalaList().observe(getViewLifecycleOwner(), salas -> {
            spSala.setItem(salas);

            spSala.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    // Sala seleccionada
                    Sala selectedSala = salas.get(position);

                    // Seteo de valores
                    binding.tvRackRegion.setText(selectedSala.region.nombre);
                    binding.tvRackPais.setText(selectedSala.region.pais.nombre);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });
        });

        // Limpieza de errores al seleccionar
        spSala.setOnItemSelectedListener(AdapterMaterialSpinner.clearSpinner(spSala));

        // Configuración de botón de creación
        binding.btnCrearRack.setOnClickListener(v -> {
            validator.validate();
        });

        // Modificar título en caso de que se esté intentando editar un rack
        if (detalleViewModel != null && detalleViewModel.hasRack()) {
            binding.tvRackFormTitle.setText("Editar rack");
            binding.btnCrearRack.setText("Actualizar rack");
        }

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Solo cargar datos cuando el formulario sea de edición.
        if (detalleViewModel != null && detalleViewModel.hasRack()) {
            detalleViewModel.getRack().observe(getViewLifecycleOwner(), rack -> {
                // 1 - Información General
                binding.etRackNombre.setText(rack.nombre);
                binding.etRackDescripcion.setText(rack.descripcion);

                formularioViewModel.getSalaList().observe(getViewLifecycleOwner(), salas -> {
                    spSala.setSelection(salas.indexOf(rack.sala));

                    binding.clLoadingRackForm.setVisibility(View.GONE);
                    binding.lSubmitRackForm.setVisibility(View.VISIBLE);
                });
            });
        } else {
            binding.clLoadingRackForm.setVisibility(View.GONE);
            binding.lSubmitRackForm.setVisibility(View.VISIBLE);
        }
    }

    private void updateRackList() {
        getActivity().finish();
        getActivity().overridePendingTransition(0, 0);
        getActivity().startActivity(getActivity().getIntent());
        getActivity().overridePendingTransition(0, 0);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }


    @Override
    public void onValidationSucceeded() {
        // Se muestra animación de cargando
        binding.clLoadingRackForm.setVisibility(View.VISIBLE);
        binding.lSubmitRackForm.setVisibility(View.GONE);
        binding.tvLoadingServer.setText("Guardando datos");

        // Manejo de datos
        Gson gson = new Gson();
        Rack rack = new Rack();

        rack.nombre = binding.etRackNombre.getText().toString();
        rack.descripcion = binding.etRackDescripcion.getText().toString();
        rack.idSala = spSala.getSelectedItem().id;

        JSONObject request = new JSONObject();

        try {
            request.put("rack", new JSONObject(gson.toJson(rack)));
        } catch (JSONException ignored) {
        }

        if (detalleViewModel != null && detalleViewModel.hasRack()) {
            rack.actualizar(detalleViewModel.getRack().getValue().id, request, response -> {
                binding.clLoadingRackForm.setVisibility(View.GONE);
                binding.lSubmitRackForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateRackList();
            }, error -> {
                binding.clLoadingRackForm.setVisibility(View.GONE);
                binding.lSubmitRackForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al actualizar rack", Toast.LENGTH_SHORT).show();
            });
        } else {
            rack.crear(request, response -> {
                binding.clLoadingRackForm.setVisibility(View.GONE);
                binding.lSubmitRackForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateRackList();
            }, error -> {
                binding.clLoadingRackForm.setVisibility(View.GONE);
                binding.lSubmitRackForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al crear rack", Toast.LENGTH_SHORT).show();
            });
        }
    }


    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        AdapterMaterialSpinner.onErrorChanges(errors);
    }
}