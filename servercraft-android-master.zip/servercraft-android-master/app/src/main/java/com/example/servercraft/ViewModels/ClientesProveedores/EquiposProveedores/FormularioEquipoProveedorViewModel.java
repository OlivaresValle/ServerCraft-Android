package com.example.servercraft.ViewModels.ClientesProveedores.EquiposProveedores;

import android.util.Log;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.ProveedorSistema;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.JSONArray;
import org.json.JSONException;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class FormularioEquipoProveedorViewModel extends ViewModel {
    private MutableLiveData<ArrayList<ProveedorSistema>> mProveedores;

    // Constructor
    public FormularioEquipoProveedorViewModel() {
        mProveedores = new MutableLiveData<>();

        loadHTTPProveedorList();
    }

    // Getters
    public MutableLiveData<ArrayList<ProveedorSistema>> getProveedorList() {
        return mProveedores;
    }

    // Setters
    private void loadHTTPProveedorList() {
        ProveedorSistema proveedorSistema = new ProveedorSistema();

        proveedorSistema.listar(1000,1,null,null, response -> {
            try {
                JSONArray httpProveedores = response.getJSONArray("proveedores");

                ArrayList<ProveedorSistema> objectProveedores = mapProveedoresIntoObject(httpProveedores);

                mProveedores.setValue(objectProveedores);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<ProveedorSistema> mapProveedoresIntoObject(JSONArray httpProveedores) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type ProveedorArray = new TypeToken<ArrayList<ProveedorSistema>>() {
        }.getType();
        ArrayList<ProveedorSistema> proveedoresList = gson.fromJson(httpProveedores.toString(), ProveedorArray);

        return proveedoresList;
    }
}
