package com.example.servercraft.Models;

import androidx.annotation.Nullable;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.servercraft.Utils.ServercraftApplication;
import org.json.JSONObject;
import java.util.Map;
import java.util.Objects;

public class TipoServidor extends BaseHTTP {
    // Constants
    private final String ENDPOINT_BASE = super.HOST + "/tipo_servidor";

    // Attributes
    public int id;
    public String nombre;

    // Constructor
    public TipoServidor() {
        super();
    }

    // To String
    @Override
    public String toString() {
        return nombre;
    }

    // Equals
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TipoServidor that = (TipoServidor) o;

        return id == that.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(ENDPOINT_BASE, id, nombre);
    }

    // HTTP Methods
    public void listar (@Nullable JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());

        JsonObjectRequest listarTipos = new JsonObjectRequest(Request.Method.GET, ENDPOINT_BASE, request, onSuccess, onError){
            @Override
            public Map<String, String> getHeaders() {
                return TipoServidor.super.headers;
            }
        };

        queue.add(listarTipos);
    }

    public void actualizar (int idTipo, JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/" + idTipo;

        JsonObjectRequest actualizarTipo = new JsonObjectRequest (Request.Method.PUT, ENDPOINT_DETAIL, request, onSuccess, onError){
            @Override
            public Map<String, String> getHeaders() {
                return TipoServidor.super.headers;
            }
        };

        queue.add(actualizarTipo);
    }
}
