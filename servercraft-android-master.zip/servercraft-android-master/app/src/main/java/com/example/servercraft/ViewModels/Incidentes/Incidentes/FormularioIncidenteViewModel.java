package com.example.servercraft.ViewModels.Incidentes.Incidentes;

import android.util.Log;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.EquipoTrabajo;
import com.example.servercraft.Models.EstadoIncidente;
import com.example.servercraft.Models.Instancia;
import com.example.servercraft.Models.TipoProblema;
import com.example.servercraft.Models.TipoSolucion;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.JSONArray;
import org.json.JSONException;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class FormularioIncidenteViewModel extends ViewModel {
    private MutableLiveData<ArrayList<TipoProblema>> mTiposProblema;
    private MutableLiveData<ArrayList<TipoSolucion>> mTiposSolucion;
    private MutableLiveData<ArrayList<EstadoIncidente>> mEstadosIncidentes;
    private MutableLiveData<ArrayList<Instancia>> mInstancias;
    private MutableLiveData<ArrayList<EquipoTrabajo>> mEquipos;




    // Constructor
    public FormularioIncidenteViewModel() {
        mTiposProblema = new MutableLiveData<>();
        mTiposSolucion = new MutableLiveData<>();
        mEstadosIncidentes = new MutableLiveData<>();
        mInstancias = new MutableLiveData<>();
        mEquipos = new MutableLiveData<>();

        loadHTTPTipoProblemaList();
        loadHTTPTipoSolucionList();
        loadHTTPEstadoIncidenteList();
        loadHTTPInstanciaList();
        loadHTTPEquipoTrabajoList();
    }

    // Getters
    public MutableLiveData<ArrayList<TipoProblema>> getTipoProblemaList() {
        return mTiposProblema;
    }

    public MutableLiveData<ArrayList<TipoSolucion>> getTipoSolucionList() {
        return mTiposSolucion;
    }

    public MutableLiveData<ArrayList<EstadoIncidente>> getEstadoIncidenteList() {
        return mEstadosIncidentes;
    }

    public MutableLiveData<ArrayList<Instancia>> getInstanciaList() {
        return mInstancias;
    }

    public MutableLiveData<ArrayList<EquipoTrabajo>> getEquipoTrabajoList() {
        return mEquipos;
    }

    // Setters

    // 1 - Tipos de Problemas
    private void loadHTTPTipoProblemaList() {
        TipoProblema tipo = new TipoProblema();

        tipo.listar(1000,1,null,null, response -> {
            try {
                JSONArray httpTipos = response.getJSONArray("tipos_problema");

                ArrayList<TipoProblema> objectTipos = mapTipoProblemaIntoObject(httpTipos);

                mTiposProblema.setValue(objectTipos);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<TipoProblema> mapTipoProblemaIntoObject(JSONArray httpTipos) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type TipoProblemaArray = new TypeToken<ArrayList<TipoProblema>>() {
        }.getType();
        ArrayList<TipoProblema> tiposList = gson.fromJson(httpTipos.toString(), TipoProblemaArray);

        return tiposList;
    }

    // 2 - Tipos de Solucion
    private void loadHTTPTipoSolucionList() {
        TipoSolucion tipo = new TipoSolucion();

        tipo.listar(1000,1,null,null, response -> {
            try {
                JSONArray httpTipos = response.getJSONArray("tipos_solucion");

                ArrayList<TipoSolucion> objectTipos = mapTipoSolucionIntoObject(httpTipos);

                mTiposSolucion.setValue(objectTipos);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<TipoSolucion> mapTipoSolucionIntoObject(JSONArray httpTipos) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type TipoSolucionArray = new TypeToken<ArrayList<TipoSolucion>>() {
        }.getType();
        ArrayList<TipoSolucion> tiposList = gson.fromJson(httpTipos.toString(), TipoSolucionArray);

        return tiposList;
    }

    // 3 - Estado Incidente
    private void loadHTTPEstadoIncidenteList() {
        EstadoIncidente estadoIncidente = new EstadoIncidente();

        estadoIncidente.listar(null, response -> {
            try {
                JSONArray httpEstados = response.getJSONArray("estados_incidente");

                ArrayList<EstadoIncidente> objectEstados = mapEstadosIncidenteIntoObject(httpEstados);

                mEstadosIncidentes.setValue(objectEstados);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<EstadoIncidente> mapEstadosIncidenteIntoObject(JSONArray httpEstados) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type EstadoIncidenteArray = new TypeToken<ArrayList<EstadoIncidente>>() {
        }.getType();
        ArrayList<EstadoIncidente> estadoIncidentesList = gson.fromJson(httpEstados.toString(), EstadoIncidenteArray);

        return estadoIncidentesList;
    }

    // 4 - Instancias
    private void loadHTTPInstanciaList() {
        Instancia instancia = new Instancia();

        instancia.listar(null, response -> {
            try {
                JSONArray httpInstancias = response.getJSONArray("instancias");

                ArrayList<Instancia> objectInstancias = mapInstanciasIntoObject(httpInstancias);

                mInstancias.setValue(objectInstancias);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()),10000,1);
    }

    private ArrayList<Instancia> mapInstanciasIntoObject(JSONArray httpInstancias) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type InstanciaArray = new TypeToken<ArrayList<Instancia>>() {
        }.getType();
        ArrayList<Instancia> instanciaList = gson.fromJson(httpInstancias.toString(), InstanciaArray);

        return instanciaList;
    }

    // 4 - Instancias
    private void loadHTTPEquipoTrabajoList() {
        EquipoTrabajo equipoTrabajo = new EquipoTrabajo();

        equipoTrabajo.listar(1000,1,null,null, response -> {
            try {
                JSONArray httpEquipos = response.getJSONArray("equipos_trabajo");

                ArrayList<EquipoTrabajo> objectEquipos = mapEquiposTrabajoIntoObject(httpEquipos);

                mEquipos.setValue(objectEquipos);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<EquipoTrabajo> mapEquiposTrabajoIntoObject(JSONArray httpEquipos) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type EquipoTrabajoArray = new TypeToken<ArrayList<EquipoTrabajo>>() {
        }.getType();
        ArrayList<EquipoTrabajo> equipoTrabajoList = gson.fromJson(httpEquipos.toString(), EquipoTrabajoArray);

        return equipoTrabajoList;
    }
}
