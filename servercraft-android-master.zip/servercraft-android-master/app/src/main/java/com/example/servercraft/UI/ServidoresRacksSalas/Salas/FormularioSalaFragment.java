package com.example.servercraft.UI.ServidoresRacksSalas.Salas;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Toast;

import com.chivorn.smartmaterialspinner.SmartMaterialSpinner;
import com.example.servercraft.Models.Pais;
import com.example.servercraft.Models.Region;
import com.example.servercraft.Models.Sala;
import com.example.servercraft.Utils.AdapterMaterialSpinner;
import com.example.servercraft.ViewModels.ServidoresRacksSalas.Salas.DetalleSala.DetalleSalaViewModel;
import com.example.servercraft.ViewModels.ServidoresRacksSalas.Salas.DetalleSala.DetalleSalaViewModelFactory;
import com.example.servercraft.ViewModels.ServidoresRacksSalas.Salas.FormularioSalaViewModel;
import com.example.servercraft.databinding.FragmentFormularioSalaBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.ValidationError;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;


public class FormularioSalaFragment extends BottomSheetDialogFragment implements Validator.ValidationListener {
    // Configuración de View Model
    private static final String ARG_SALA = "sala";
    private DetalleSalaViewModel detalleViewModel;
    private FormularioSalaViewModel formularioViewModel;
    private FragmentFormularioSalaBinding binding;
    private Validator validator;
    private View root;

    // Spinners


    // Validaciones
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etSalaNombreCrear;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etSalaDescripcionCrear;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    SmartMaterialSpinner<Region> spRegion;

    public static FormularioSalaFragment newInstance(@Nullable Sala sala) {
        FormularioSalaFragment fragment = new FormularioSalaFragment();

        if (sala != null) {
            Bundle bundle = new Bundle();
            Gson gson = new Gson();

            bundle.putString(ARG_SALA, gson.toJson(sala));
            fragment.setArguments(bundle);
        }

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            Gson gson = new Gson();
            String jsonSala = getArguments().getString(ARG_SALA);
            Sala sala = gson.fromJson(jsonSala, Sala.class);

            detalleViewModel = new ViewModelProvider(this, new DetalleSalaViewModelFactory(sala)).get(DetalleSalaViewModel.class);
        }

        formularioViewModel = new ViewModelProvider(this).get(FormularioSalaViewModel.class);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentFormularioSalaBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.registerAdapter(SmartMaterialSpinner.class, new AdapterMaterialSpinner());
        validator.setValidationListener(this);

        // Intanciamiento de los campos a validar
        etSalaNombreCrear = binding.etSalaNombre;
        etSalaDescripcionCrear = binding.etSalaDescripcion;

        // Loading Status
        binding.clLoadingSalaForm.setVisibility(View.VISIBLE);
        binding.lSubmitSalaForm.setVisibility(View.GONE);

        // Referenciación de elementos
        spRegion = binding.spSalaRegion;

        // Inicialización de spinners con API.
        formularioViewModel.getRegionesList().observe(getViewLifecycleOwner(), regiones -> {
            spRegion.setItem(regiones);

            spRegion.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    // Región seleccionada
                    Region selectedRegion = regiones.get(position);

                    // Seteo de valores
                    binding.tvSalaPais.setText(selectedRegion.pais.nombre);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });
        });

        // Limpieza de errores al seleccionar
        spRegion.setOnItemSelectedListener(AdapterMaterialSpinner.clearSpinner(spRegion));

        // Configuración de botón de creación
        binding.btnCrearSala.setOnClickListener(v -> {
            validator.validate();

        });

        // Modificar título en caso de que se esté intentando editar una sala
        if (detalleViewModel != null && detalleViewModel.hasSala()) {
            binding.tvSalaFormTitle.setText("Editar sala");
            binding.btnCrearSala.setText("Actualizar sala");
        }

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Solo cargar datos cuando el formulario sea de edición.
        if (detalleViewModel != null && detalleViewModel.hasSala()) {
            detalleViewModel.getSala().observe(getViewLifecycleOwner(), sala -> {
                // 1 - Información General
                binding.etSalaNombre.setText(sala.nombre);
                binding.etSalaDescripcion.setText(sala.descripcion);

                formularioViewModel.getRegionesList().observe(getViewLifecycleOwner(), regiones -> {
                    spRegion.setSelection(regiones.indexOf(sala.region));

                    binding.clLoadingSalaForm.setVisibility(View.GONE);
                    binding.lSubmitSalaForm.setVisibility(View.VISIBLE);
                });
            });
        } else {
            binding.clLoadingSalaForm.setVisibility(View.GONE);
            binding.lSubmitSalaForm.setVisibility(View.VISIBLE);
        }
    }

    private void updateSalaList() {
        getActivity().finish();
        getActivity().overridePendingTransition(0, 0);
        getActivity().startActivity(getActivity().getIntent());
        getActivity().overridePendingTransition(0, 0);
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onValidationSucceeded() {
        // Se muestra animación de cargando
        binding.clLoadingSalaForm.setVisibility(View.VISIBLE);
        binding.lSubmitSalaForm.setVisibility(View.GONE);
        binding.tvLoadingSala.setText("Guardando datos");

        // Manejo de datos
        Gson gson = new Gson();
        Sala sala = new Sala();

        sala.nombre = binding.etSalaNombre.getText().toString();
        sala.descripcion = binding.etSalaDescripcion.getText().toString();
        sala.idRegion = spRegion.getSelectedItem().id;

        JSONObject request = new JSONObject();

        try {
            request.put("sala", new JSONObject(gson.toJson(sala)));
        } catch (JSONException ignored) {
        }

        if (detalleViewModel != null && detalleViewModel.hasSala()) {
            sala.actualizar(detalleViewModel.getSala().getValue().id, request, response -> {
                binding.clLoadingSalaForm.setVisibility(View.GONE);
                binding.lSubmitSalaForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateSalaList();
            }, error -> {
                binding.clLoadingSalaForm.setVisibility(View.GONE);
                binding.lSubmitSalaForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al actualizar sala", Toast.LENGTH_SHORT).show();
            });
        } else {
            sala.crear(request, response -> {
                binding.clLoadingSalaForm.setVisibility(View.GONE);
                binding.lSubmitSalaForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateSalaList();
            }, error -> {
                binding.clLoadingSalaForm.setVisibility(View.GONE);
                binding.lSubmitSalaForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al crear sala", Toast.LENGTH_SHORT).show();
            });
        }

    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        AdapterMaterialSpinner.onErrorChanges(errors);

    }

}