package com.example.servercraft.UI.Incidentes.Incidentes;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.example.servercraft.R;
import com.example.servercraft.ViewModels.Incidentes.Incidentes.ListarIncidentesViewModel;
import com.example.servercraft.databinding.FragmentListarIncidentesBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class ListarIncidentesFragment extends BottomSheetDialogFragment {
    public ListarIncidentesViewModel listarViewModel;
    private FragmentListarIncidentesBinding binding;
    public IncidenteItemAdapter incidenteAdapter;
    private boolean iniciado = false;

    public static ListarIncidentesFragment newInstance() {
        return new ListarIncidentesFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        listarViewModel = new ViewModelProvider(this).get(ListarIncidentesViewModel.class);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        Activity parent = getActivity();
        binding = FragmentListarIncidentesBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Elements
        ProgressBar spinner = parent.findViewById(R.id.pbHttpLoading);
        RecyclerView rvIncidentes = binding.rvIncidentes;

        // Configuración inicial de elementos
        spinner.setVisibility(View.INVISIBLE);
        rvIncidentes.setLayoutManager(new LinearLayoutManager(root.getContext()));

        if (iniciado) {
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etBuscarIncidente.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arIncidente.clear();
            listarViewModel.loadHTTPIncidentesList();
            incidenteAdapter = null;
            binding.pbHttpLoadingInicidente.setVisibility(View.VISIBLE);
        }

        // Observador de consulta HTTP
        listarViewModel.getIncidenteList().observe(getViewLifecycleOwner(), incidentes -> {
            iniciado = true;
            if (incidenteAdapter == null) {
                incidenteAdapter = new IncidenteItemAdapter(root.getContext(), incidentes, getChildFragmentManager());

                binding.rvIncidentes.setAdapter(incidenteAdapter);
                spinner.setVisibility(View.INVISIBLE);
                binding.pbHttpLoadingInicidente.setVisibility(View.INVISIBLE);
            } else {
                binding.rvIncidentes.post(new Runnable() {
                    public void run() {
                        incidenteAdapter.notifyItemRangeChanged(0, incidentes.size() - 1);
                    }
                });
            }
        });

        binding.btnBuscarInicidente.setOnClickListener(v -> {
            binding.pbHttpLoadingInicidente.setVisibility(View.VISIBLE);
            listarViewModel.blPuedeCargarMas = true;
            listarViewModel.busqueda = binding.etBuscarIncidente.getText().toString();
            listarViewModel.pagina = 0;
            listarViewModel.arIncidente.clear();
            listarViewModel.loadHTTPIncidentesList();
            incidenteAdapter = null;
        });

        binding.rvIncidentes.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                if (!listarViewModel.cargandoDatos) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == listarViewModel.arIncidente.size() - 1) {
                        listarViewModel.cargandoDatos = true;
                        listarViewModel.loadHTTPIncidentesList();
                    }
                }
            }
        });

        return root;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}