package com.example.servercraft.UI.Sistema;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.chivorn.smartmaterialspinner.SmartMaterialSpinner;
import com.example.servercraft.Models.DocumentoSistema;
import com.example.servercraft.Models.Lenguaje;
import com.example.servercraft.Models.ServicioWeb;
import com.example.servercraft.ViewModels.Sistema.DetalleSistema.DetalleSistemaViewModel;
import com.example.servercraft.ViewModels.Sistema.DetalleSistema.DetalleSistemaViewModelFactory;
import com.example.servercraft.databinding.FragmentDetalleSistemaBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class DetalleSistemaFragment extends BottomSheetDialogFragment {
    private static final String ARG_ID_SISTEMA = "id_sistema";
    private DetalleSistemaViewModel detalleViewModel;
    private FragmentDetalleSistemaBinding binding;

    // Spinners
    SmartMaterialSpinner<DocumentoSistema> spDocumento;
    SmartMaterialSpinner<Lenguaje> spLenguaje;
    SmartMaterialSpinner<ServicioWeb> spServicioWeb;

    public static DetalleSistemaFragment newInstance(int idSistema) {
        DetalleSistemaFragment fragment = new DetalleSistemaFragment();
        Bundle bundle = new Bundle();

        bundle.putInt(ARG_ID_SISTEMA, idSistema);
        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int sistemaId = 1;

        if (getArguments() != null) {
            sistemaId = getArguments().getInt(ARG_ID_SISTEMA);
        }

        detalleViewModel = new ViewModelProvider(this, new DetalleSistemaViewModelFactory(sistemaId)).get(DetalleSistemaViewModel.class);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentDetalleSistemaBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Spinners
        spDocumento = binding.spDocumentoDetalleSistema;
        spLenguaje = binding.spLenguajeDetalleSistema;
        spServicioWeb = binding.spServiciosWevDetalleSistema;

        // Observador de consulta HTTP
        detalleViewModel.getSistema().observe(getViewLifecycleOwner(), sistema -> {
            // Cargar datos cuando estén disponibles
            // 1 - Información general
            binding.tvNombreSistemaDetalleSistema.setText(sistema.nombre);

            // 2 - Equipo del Proveedor
            binding.tvEquipoProveedorDetalleSistema.setText(sistema.equipoProveedor.nombre);

            // 3 - Instancias
            InstanciaItemAdapter instanciaItemAdapter = new InstanciaItemAdapter(getContext(), sistema.instancias, getChildFragmentManager());

            binding.recyclerInstanciaDetalleSistema.setLayoutManager(new LinearLayoutManager(root.getContext()));
            binding.recyclerInstanciaDetalleSistema.setAdapter(instanciaItemAdapter);

            if (sistema.instancias.size() == 0) {
                binding.tvInstanciaDetalleSistema.setVisibility(View.VISIBLE);
            }

            // 4 - Servidor DB
            binding.tvNombreServidorDBDetalleSistema.setText(sistema.servidorDb == null ? "No posee servidor de base de datos" : sistema.servidorDb.nombre);

            // 5 - Documentos
            detalleViewModel.getDocumentoList().observe(getViewLifecycleOwner(), documento -> {
                if (sistema.documentos.size() == 0) {
                    binding.tvDocumentoDetalleSistema.setVisibility(View.VISIBLE);
                    spDocumento.setVisibility(View.GONE);
                } else {
                    spDocumento.setItem(documento);
                }
            });

            // 6 - Nivel de Seguridad
            binding.tvNombreNivelSeguridadDetalleSistema.setText(sistema.nivelSeguridad.nombre);

            // 7 - Nivel de Sensibilidad
            binding.tvNombreNivelSensibilidadDetalleSistema.setText(sistema.nivelSensibilidad == null ? "No posee nivel de sensibilidad" : sistema.nivelSensibilidad.nombre);

            // 8 - Lenguajes
            detalleViewModel.getLenguajeList().observe(getViewLifecycleOwner(), lenguaje -> {
                if (sistema.lenguajes.size() == 0) {
                    binding.tvLenguajeDetalleSistema.setVisibility(View.VISIBLE);
                    spLenguaje.setVisibility(View.GONE);
                } else {
                    spLenguaje.setItem(lenguaje);
                }
            });

            // 9 - Servicios Web
            detalleViewModel.getServicioWebList().observe(getViewLifecycleOwner(), servicioWeb -> {
                if (sistema.documentos.size() == 0) {
                    binding.tvServicioWebDetalleSistema.setVisibility(View.VISIBLE);
                    spServicioWeb.setVisibility(View.GONE);
                } else {
                    spServicioWeb.setItem(servicioWeb);
                }
            });

            // 10 - Usuario
            binding.tvUsuarioDetalleSistema.setText(sistema.usuario.nombre);

            // Ocultar vista de "cargando..."
            binding.clLoadingDetalleSistema.setVisibility(View.GONE);
            binding.llDataDetalleSistema.setVisibility(View.VISIBLE);
        });
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}