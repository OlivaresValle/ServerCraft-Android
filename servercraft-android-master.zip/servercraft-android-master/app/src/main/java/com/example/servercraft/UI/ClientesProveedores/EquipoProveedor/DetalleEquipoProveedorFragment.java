package com.example.servercraft.UI.ClientesProveedores.EquipoProveedor;

import android.os.Bundle;
import androidx.lifecycle.ViewModelProvider;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.example.servercraft.ViewModels.ClientesProveedores.EquiposProveedores.DetalleEquipoProveedor.DetalleEquipoProveedorViewModel;
import com.example.servercraft.ViewModels.ClientesProveedores.EquiposProveedores.DetalleEquipoProveedor.DetalleEquipoProveedorViewModelFactory;
import com.example.servercraft.databinding.FragmentDetalleEquipoProveedorBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class DetalleEquipoProveedorFragment extends BottomSheetDialogFragment {
    private static final String ARG_ID_EQUIPO_PROVEEDOR = "id_equipo_proveedor";
    private DetalleEquipoProveedorViewModel detalleViewModel;
    private FragmentDetalleEquipoProveedorBinding binding;

    public static DetalleEquipoProveedorFragment newInstance(int idEquipoProveedor) {
        DetalleEquipoProveedorFragment fragment = new DetalleEquipoProveedorFragment();
        Bundle bundle = new Bundle();

        bundle.putInt(ARG_ID_EQUIPO_PROVEEDOR, idEquipoProveedor);
        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int equipoProveedorId = 1;

        if (getArguments() != null) {
            equipoProveedorId = getArguments().getInt(ARG_ID_EQUIPO_PROVEEDOR);
        }

        detalleViewModel = new ViewModelProvider(this, new DetalleEquipoProveedorViewModelFactory(equipoProveedorId)).get(DetalleEquipoProveedorViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentDetalleEquipoProveedorBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Observador de consulta HTTP
        detalleViewModel.getEquipoProveedor().observe(getViewLifecycleOwner(), equipoProveedor -> {
            // Cargar datos cuando estén disponibles
            binding.tvEPTitle.setText(equipoProveedor.nombre);
            binding.tvEPProveedorData.setText(equipoProveedor.proveedorSistema.nombre);
            binding.tvEPRepresentanteData.setText(equipoProveedor.nombreRepresentante);
            binding.tvEPEmailContactoData.setText(equipoProveedor.emailContacto);
            binding.tvEPTelefonoContactoData.setText(equipoProveedor.telefonoContacto);

            // Ocultar vista de "cargando..."
            binding.clLoadingEquipoProveedor.setVisibility(View.GONE);
            binding.lEquipoProveedorTab.setVisibility(View.VISIBLE);
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}