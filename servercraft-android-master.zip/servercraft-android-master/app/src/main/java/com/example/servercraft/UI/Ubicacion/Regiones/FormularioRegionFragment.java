package com.example.servercraft.UI.Ubicacion.Regiones;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.chivorn.smartmaterialspinner.SmartMaterialSpinner;
import com.example.servercraft.Models.Pais;
import com.example.servercraft.Models.Region;

import com.example.servercraft.Utils.AdapterMaterialSpinner;
import com.example.servercraft.ViewModels.Ubicacion.Region.DetalleRegion.DetalleRegionViewModel;
import com.example.servercraft.ViewModels.Ubicacion.Region.DetalleRegion.DetalleRegionViewModelFactory;
import com.example.servercraft.ViewModels.Ubicacion.Region.FormularioRegionViewModel;
import com.example.servercraft.databinding.FragmentFormularioRegionBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class FormularioRegionFragment extends BottomSheetDialogFragment implements Validator.ValidationListener {
    public static final String ARG_REG = "ubicacion/region";
    private DetalleRegionViewModel detalleViewModel;
    private FormularioRegionViewModel formularioViewModel;
    private FragmentFormularioRegionBinding binding;
    private View root;
    private Validator validator;

    // Validaciones
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etRegionNombre;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    SmartMaterialSpinner<Pais> spPais;

    public static FormularioRegionFragment newInstance(@Nullable Region region) {
        FormularioRegionFragment fragment = new FormularioRegionFragment();

        if (region != null) {
            Bundle bundle = new Bundle();
            Gson gson = new Gson();

            bundle.putString(ARG_REG, gson.toJson(region));
            fragment.setArguments(bundle);
        }

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            Gson gson = new Gson();
            String jsonRegion = getArguments().getString(ARG_REG);
            Region region = gson.fromJson(jsonRegion, Region.class);

            detalleViewModel = new ViewModelProvider(this, new DetalleRegionViewModelFactory(region)).get(DetalleRegionViewModel.class);
        }

        formularioViewModel = new ViewModelProvider(this).get(FormularioRegionViewModel.class);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentFormularioRegionBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.registerAdapter(SmartMaterialSpinner.class, new AdapterMaterialSpinner());
        validator.setValidationListener(this);

        // Intanciamiento de los campos a validar
        etRegionNombre = binding.etRegionNombre;

        // Loading Status
        binding.clLoadingRegionForm.setVisibility(View.VISIBLE);
        binding.lSubmitRegionForm.setVisibility(View.GONE);

        // Referenciación de elementos
        spPais = binding.spPaisRegion;

        // Inicialización de spinners con API.
        formularioViewModel.getPaisList().observe(getViewLifecycleOwner(), pais -> {
            spPais.setItem(pais);
        });

        // Limpieza de errores al seleccionar
        spPais.setOnItemSelectedListener(AdapterMaterialSpinner.clearSpinner(spPais));

        // Configuración de botón de creación
        binding.btnCrearRegion.setOnClickListener(v -> {
            validator.validate();
        });

        // Modificar título en caso de que se esté intentando editar una sala
        if (detalleViewModel != null && detalleViewModel.hasRegion()) {
            binding.tvRegionFormTitle.setText("Editar región");
            binding.btnCrearRegion.setText("Actualizar región");
        }

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Solo cargar datos cuando el formulario sea de edición.
        if (detalleViewModel != null && detalleViewModel.hasRegion()) {
            detalleViewModel.getRegion().observe(getViewLifecycleOwner(), region -> {
                // 1 - Información General
                binding.etRegionNombre.setText(region.nombre);

                formularioViewModel.getPaisList().observe(getViewLifecycleOwner(), pais -> {
                    spPais.setSelection(pais.indexOf(region.pais));

                    binding.clLoadingRegionForm.setVisibility(View.GONE);
                    binding.lSubmitRegionForm.setVisibility(View.VISIBLE);
                });
            });
        } else {
            binding.clLoadingRegionForm.setVisibility(View.GONE);
            binding.lSubmitRegionForm.setVisibility(View.VISIBLE);
        }
    }

    private void updateRegionList() {
        getActivity().finish();
        getActivity().overridePendingTransition(0, 0);
        getActivity().startActivity(getActivity().getIntent());
        getActivity().overridePendingTransition(0, 0);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onValidationSucceeded() {
        // Se muestra animación de cargando
        binding.clLoadingRegionForm.setVisibility(View.VISIBLE);
        binding.lSubmitRegionForm.setVisibility(View.GONE);
        binding.tvLoadingRegion.setText("Guardando datos");

        // Manejo de datos
        Gson gson = new Gson();
        Region region = new Region();

        region.nombre = binding.etRegionNombre.getText().toString();
        region.idPais = spPais.getSelectedItem().id;

        JSONObject request = new JSONObject();

        try {
            request.put("region", new JSONObject(gson.toJson(region)));
        } catch (JSONException ignored) {
        }

        if (detalleViewModel != null && detalleViewModel.hasRegion()) {
            region.actualizar(detalleViewModel.getRegion().getValue().id, request, response -> {
                binding.clLoadingRegionForm.setVisibility(View.GONE);
                binding.lSubmitRegionForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateRegionList();
            }, error -> {
                binding.clLoadingRegionForm.setVisibility(View.GONE);
                binding.lSubmitRegionForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al actualizar región", Toast.LENGTH_SHORT).show();
            });
        } else {
            region.crear(request, response -> {
                binding.clLoadingRegionForm.setVisibility(View.GONE);
                binding.lSubmitRegionForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateRegionList();
            }, error -> {
                binding.clLoadingRegionForm.setVisibility(View.GONE);
                binding.lSubmitRegionForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al crear región", Toast.LENGTH_SHORT).show();
            });
        }
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        AdapterMaterialSpinner.onErrorChanges(errors);
    }


}