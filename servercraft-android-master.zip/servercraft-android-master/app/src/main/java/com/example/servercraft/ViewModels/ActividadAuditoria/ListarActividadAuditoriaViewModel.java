package com.example.servercraft.ViewModels.ActividadAuditoria;

import android.util.Log;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.servercraft.Models.ActividadAuditoria;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Objects;

public class ListarActividadAuditoriaViewModel extends ViewModel {
    private MutableLiveData<ArrayList<ActividadAuditoria>> mActividadAuditoria;
    public ArrayList<ActividadAuditoria> arActividadAuditoria = new ArrayList<>();

    public boolean cargandoDatos = false;
    public boolean blPuedeCargarMas = true;
    public int pagina = 0;

    //Constructor
    public ListarActividadAuditoriaViewModel() {
        mActividadAuditoria = new MutableLiveData<>();
        loadHTTPActividadAuditoriaList();
    }

    //Getters
    public MutableLiveData<ArrayList<ActividadAuditoria>> getActividadAuditoria() {
        return mActividadAuditoria;
    }

    //Setters
    public void loadHTTPActividadAuditoriaList() {
        if (blPuedeCargarMas) {
            ActividadAuditoria actividadAuditoria = new ActividadAuditoria();

            pagina = pagina + 1;

            if (arActividadAuditoria.size() != 0) {
                arActividadAuditoria.add(null);
                mActividadAuditoria.setValue(arActividadAuditoria);
            }

            actividadAuditoria.listar(10, pagina, null, response -> {
                Log.e("Listar Actividad", "Se lista la pagina " + pagina);
                try {
                    JSONArray httpActividadAuditoria = response.getJSONArray("eventos");
                    JSONObject httpMeta = response.getJSONObject("meta");

                    arActividadAuditoria.removeIf(Objects::isNull);

                    if (httpMeta.getInt("last_page") == pagina) {
                        blPuedeCargarMas = false;
                    }

                    arActividadAuditoria.addAll(mapActividadAuditoriaIntoObject(httpActividadAuditoria));

                    mActividadAuditoria.setValue(arActividadAuditoria);

                    cargandoDatos = false;
                } catch (JSONException e) {
                    Log.e("Listar ActividadAuditoria", e.toString());
                }
            }, error -> Log.d("Error de ", error.toString()));
        }
    }

    private ArrayList<ActividadAuditoria> mapActividadAuditoriaIntoObject(JSONArray httpActividad) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();
        Type ActividadAuditoriaArray = new TypeToken<ArrayList<ActividadAuditoria>>() {
        }.getType();
        ArrayList<ActividadAuditoria> actividadAuditoriasList = gson.fromJson(httpActividad.toString(), ActividadAuditoriaArray);

        return actividadAuditoriasList;
    }
}
