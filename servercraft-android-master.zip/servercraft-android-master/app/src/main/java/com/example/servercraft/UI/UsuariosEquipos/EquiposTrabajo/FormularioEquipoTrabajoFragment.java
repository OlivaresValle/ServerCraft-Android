package com.example.servercraft.UI.UsuariosEquipos.EquiposTrabajo;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import com.chivorn.smartmaterialspinner.SmartMaterialSpinner;
import com.example.servercraft.Models.EquipoTrabajo;
import com.example.servercraft.Models.UnidadNegocio;
import com.example.servercraft.Utils.AdapterMaterialSpinner;
import com.example.servercraft.ViewModels.UsuariosEquipos.EquiposTrabajo.FormularioEquipoTrabajo.FormularioEquipoTrabajoViewModel;
import com.example.servercraft.ViewModels.UsuariosEquipos.EquiposTrabajo.FormularioEquipoTrabajo.FormularioEquipoTrabajoViewModelFactory;
import com.example.servercraft.databinding.FragmentFormularioEquipoTrabajoBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.gson.Gson;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class FormularioEquipoTrabajoFragment extends BottomSheetDialogFragment implements Validator.ValidationListener {
    private static final String ARG_EQUIPO = "equipo";
    private FormularioEquipoTrabajoViewModel formularioViewModel;
    private FragmentFormularioEquipoTrabajoBinding binding;
    private View root;
    private Validator validator;

    // Validaciones
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etEquipoTrabajoNombre;

    // Spinners
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    SmartMaterialSpinner<UnidadNegocio> spUnidadNegocio;

    public static FormularioEquipoTrabajoFragment newInstance(@Nullable EquipoTrabajo equipoTrabajo) {
        FormularioEquipoTrabajoFragment fragment = new FormularioEquipoTrabajoFragment();

        if (equipoTrabajo != null) {
            Bundle bundle = new Bundle();
            Gson gson = new Gson();

            bundle.putString(ARG_EQUIPO, gson.toJson(equipoTrabajo));
            fragment.setArguments(bundle);
        }

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EquipoTrabajo equipoTrabajo = null;

        if (getArguments() != null) {
            Gson gson = new Gson();
            equipoTrabajo = gson.fromJson(getArguments().getString(ARG_EQUIPO), EquipoTrabajo.class);
        }

        formularioViewModel = new ViewModelProvider(this, new FormularioEquipoTrabajoViewModelFactory(equipoTrabajo)).get(FormularioEquipoTrabajoViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentFormularioEquipoTrabajoBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        // Intanciamiento de los campos a validar
        etEquipoTrabajoNombre = binding.etEquipoTrabajoNombre;

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.registerAdapter(SmartMaterialSpinner.class, new AdapterMaterialSpinner());
        validator.setValidationListener(this);

        // Loading Status
        binding.clLoadingEquipoTrabajoForm.setVisibility(View.VISIBLE);
        binding.lSubmitEquipoTrabajoForm.setVisibility(View.GONE);

        // Referenciación de Spinners
        spUnidadNegocio = binding.spEquipoTrabajoUnidad;

        // Inicialización de spinners con API.
        formularioViewModel.getUnidadesNegocioList().observe(getViewLifecycleOwner(), unidades -> {
            spUnidadNegocio.setItem(unidades);
        });

        // Limpieza de errores al seleccionar
        spUnidadNegocio.setOnItemSelectedListener(AdapterMaterialSpinner.clearSpinner(spUnidadNegocio));

        // Configuración de botón de creación
        binding.btnCrearUnidadNegocio.setOnClickListener(v -> {
            validator.validate();
        });

        // Modificar título en caso de que se esté intentando editar un servidor
        if (formularioViewModel != null && formularioViewModel.hasEquipoTrabajo()) {
            binding.tvEquipoTrabajoFormTitle.setText("Editar equipo de trabajo");
            binding.btnCrearUnidadNegocio.setText("Actualizar equipo");
        }

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Solo cargar datos cuando el formulario sea de edición.
        if (formularioViewModel != null && formularioViewModel.hasEquipoTrabajo()) {
            formularioViewModel.getEquipoTrabajo().observe(getViewLifecycleOwner(), equipoTrabajo -> {
                binding.etEquipoTrabajoNombre.setText(equipoTrabajo.nombre);

                formularioViewModel.getUnidadesNegocioList().observe(getViewLifecycleOwner(), unidades -> {
                    spUnidadNegocio.setSelection(unidades.indexOf(equipoTrabajo.unidadNegocio));
                });
            });
        }

        binding.clLoadingEquipoTrabajoForm.setVisibility(View.GONE);
        binding.lSubmitEquipoTrabajoForm.setVisibility(View.VISIBLE);
    }

    private void updateEquipoTrabajoList() {
        getActivity().finish();
        getActivity().overridePendingTransition(0, 0);
        getActivity().startActivity(getActivity().getIntent());
        getActivity().overridePendingTransition(0, 0);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }


    @Override
    public void onValidationSucceeded() {
        // Se muestra animación de cargando
        binding.clLoadingEquipoTrabajoForm.setVisibility(View.VISIBLE);
        binding.lSubmitEquipoTrabajoForm.setVisibility(View.GONE);
        binding.tvLoadingEquipoTrabajo.setText("Guardando datos");

        // Manejo de datos
        Gson gson = new Gson();
        EquipoTrabajo equipoTrabajo = new EquipoTrabajo();

        equipoTrabajo.nombre = binding.etEquipoTrabajoNombre.getText().toString();
        equipoTrabajo.idUnidadNegocio = spUnidadNegocio.getSelectedItem().id;

        JSONObject request = new JSONObject();

        try {
            request.put("equipoTrabajo", new JSONObject(gson.toJson(equipoTrabajo)));
        } catch (JSONException ignored) {
        }

        if (formularioViewModel != null && formularioViewModel.hasEquipoTrabajo()) {
            equipoTrabajo.actualizar(formularioViewModel.getEquipoTrabajo().getValue().id, request, response -> {
                binding.clLoadingEquipoTrabajoForm.setVisibility(View.GONE);
                binding.lSubmitEquipoTrabajoForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateEquipoTrabajoList();
            }, error -> {
                binding.clLoadingEquipoTrabajoForm.setVisibility(View.GONE);
                binding.lSubmitEquipoTrabajoForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al actualizar equipo de trabajo", Toast.LENGTH_SHORT).show();
            });
        } else {
            equipoTrabajo.crear(request, response -> {
                binding.clLoadingEquipoTrabajoForm.setVisibility(View.GONE);
                binding.lSubmitEquipoTrabajoForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateEquipoTrabajoList();
            }, error -> {
                binding.clLoadingEquipoTrabajoForm.setVisibility(View.GONE);
                binding.lSubmitEquipoTrabajoForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al crear equipo de trabajo", Toast.LENGTH_SHORT).show();
            });
        }
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        AdapterMaterialSpinner.onErrorChanges(errors);

    }
}