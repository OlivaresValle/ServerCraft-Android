package com.example.servercraft.ViewModels.ServidoresRacksSalas.Salas;

import android.util.Log;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.servercraft.Models.Lenguaje;
import com.example.servercraft.Models.Sala;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Objects;

public class ListarSalasViewModel extends ViewModel {
    private MutableLiveData<ArrayList<Sala>> mSalasList;
    public ArrayList<Sala> arSalas = new ArrayList<>();

    public boolean cargandoDatos = false;
    public boolean blPuedeCargarMas = true;
    public int pagina = 0;
    public String busqueda = "";

    // Constructor
    public ListarSalasViewModel() {
        mSalasList = new MutableLiveData<>();
        loadHTTPSalasList();
    }

    // Getters
    public MutableLiveData<ArrayList<Sala>> getSalasList() {
        return mSalasList;
    }

    // Setters
    public void loadHTTPSalasList() {

        if (blPuedeCargarMas) {
            Sala sala = new Sala();

            pagina = pagina + 1;

            if (arSalas.size() != 0) {
                arSalas.add(null);
                mSalasList.setValue(arSalas);
            }

        sala.listar(10,pagina,busqueda,null, response -> {
            try {
                JSONArray httpSalas = response.getJSONArray("salas");
                JSONObject httpMeta = response.getJSONObject("meta");

                Log.d("Resultados",httpSalas.toString());

                arSalas.removeIf(Objects::isNull);


                if (httpMeta.getInt("last_page") == pagina) {
                    blPuedeCargarMas = false;
                }

                arSalas.addAll(mapSalasIntoObject(httpSalas));

                mSalasList.setValue(arSalas);

                cargandoDatos = false;
            } catch (JSONException e) {
                Log.e("Listar leng", e.toString());
            }
        }, error -> Log.d("Error de ", error.toString()));
        }
    }

    private ArrayList<Sala> mapSalasIntoObject(JSONArray httpSalas) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type SalaArray = new TypeToken<ArrayList<Sala>>() {
        }.getType();
        ArrayList<Sala> salasList = gson.fromJson(httpSalas.toString(), SalaArray);

        return salasList;
    }
}
