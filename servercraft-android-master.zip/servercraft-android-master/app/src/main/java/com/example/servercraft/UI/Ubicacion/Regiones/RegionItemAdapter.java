package com.example.servercraft.UI.Ubicacion.Regiones;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.servercraft.Models.Region;
import com.example.servercraft.R;
import com.example.servercraft.UI.LenguajesProgramacion.LenguajeItemAdapter;

import java.util.ArrayList;

public class RegionItemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;

    LayoutInflater inflater;
    ArrayList<Region> model;
    FragmentManager fragmentManager;
    Context context;

    public RegionItemAdapter(Context context, ArrayList<Region> model, FragmentManager fm) {
        this.inflater = LayoutInflater.from(context);
        this.model = model;
        this.fragmentManager = fm;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = inflater.inflate(R.layout.item_list_general, parent, false);

            return new RegionItemAdapter.ItemViewHolder(view);
        } else {
            View view = inflater.inflate(R.layout.item_list_loading, parent, false);

            return new RegionItemAdapter.LoadingViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        if (holder instanceof RegionItemAdapter.ItemViewHolder) {
            populateItemRows((RegionItemAdapter.ItemViewHolder) holder, position);
        } else if (holder instanceof RegionItemAdapter.LoadingViewHolder) {
            showLoadingView((RegionItemAdapter.LoadingViewHolder) holder, position);
        }
    }

    @Override
    public int getItemCount() {
        return model == null ? 0 : model.size();
    }

    @Override
    public int getItemViewType(int position) {
        return model.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }


    public class ItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ConstraintLayout clItemData, clItemActions;
        TextView nombre, descripcion;
        Button btnView, btnEdit, btnDelete;


        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);

            nombre = itemView.findViewById(R.id.tvItemTitle);
            descripcion = itemView.findViewById(R.id.tvItemDescription);
            clItemData = itemView.findViewById(R.id.clItemData);
            clItemActions = itemView.findViewById(R.id.clItemActions);
            btnView = itemView.findViewById(R.id.btnView);
            btnEdit = itemView.findViewById(R.id.btnUpdate);
            btnDelete = itemView.findViewById(R.id.btnDelete);

            clItemData.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int adapterPosition =  getAbsoluteAdapterPosition();
            Region region = model.get(adapterPosition);
            region.isFullyVisible = !region.isFullyVisible;

            notifyItemChanged(adapterPosition);
        }
    }

    private class LoadingViewHolder extends RecyclerView.ViewHolder {

        public LoadingViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    private void showLoadingView(LoadingViewHolder viewHolder, int position) {
        //ProgressBar would be displayed

    }

    private void populateItemRows(RegionItemAdapter.ItemViewHolder holder, int position) {
        // Obtención de objeto
        Region region = model.get(position);

        // Seteo de valores en view holder
        holder.nombre.setText(region.nombre);
        holder.descripcion.setVisibility(View.GONE);
        holder.clItemActions.setVisibility(region.isFullyVisible ? View.VISIBLE : View.GONE);

        // Click listeners
        holder.btnView.setOnClickListener(v -> {
            DetalleRegionesFragment detalleRegion = DetalleRegionesFragment.newInstance(region);
            detalleRegion.show(fragmentManager, detalleRegion.getTag());
        });

        holder.btnEdit.setOnClickListener(v -> {
            FormularioRegionFragment formRegion = FormularioRegionFragment.newInstance(region);
            formRegion.show(fragmentManager, formRegion.getTag());
        });

        holder.btnDelete.setOnClickListener(v -> {
            AlertDialog.Builder confirmation = new AlertDialog.Builder(context);
            confirmation.setTitle("Advertencia")
                    .setMessage("¿Estás seguro de qué deseas eliminar la región: \""+region.nombre+"\"?")
                    .setCancelable(false)
                    .setPositiveButton("Eliminar", (dialog, which) -> {
                        region.eliminar(region.id, response -> {
                            ((Activity) context).finish();
                            ((Activity) context).overridePendingTransition(0, 0);
                            ((Activity) context).startActivity(((Activity) context).getIntent());
                            ((Activity) context).overridePendingTransition(0, 0);
                        }, error -> {
                            Toast.makeText(context, "Error al eliminar región.", Toast.LENGTH_SHORT).show();
                        });
                    }).setNegativeButton("Cancelar", (dialog, which) -> {
                dialog.dismiss();
            });
            confirmation.create().show();
        });

    }
}
