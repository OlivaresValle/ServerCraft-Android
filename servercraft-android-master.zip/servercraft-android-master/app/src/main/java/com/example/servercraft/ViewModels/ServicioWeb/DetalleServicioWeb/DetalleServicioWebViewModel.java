package com.example.servercraft.ViewModels.ServicioWeb.DetalleServicioWeb;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.ServicioWeb;
import org.jetbrains.annotations.Nullable;

public class DetalleServicioWebViewModel extends ViewModel {
    private MutableLiveData<ServicioWeb> mServicioWeb;

    public DetalleServicioWebViewModel(@Nullable ServicioWeb servicioWeb) {
        mServicioWeb = new MutableLiveData<>();

        mServicioWeb.setValue(servicioWeb);
    }

    public MutableLiveData<ServicioWeb> getServicioWeb() {
        return mServicioWeb;
    }

    public boolean hasServicioWeb() {
        return mServicioWeb != null;
    }
}
