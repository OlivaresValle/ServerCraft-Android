package com.example.servercraft.UI.Incidentes.TiposProblema;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.servercraft.Models.TipoProblema;
import com.example.servercraft.R;
import com.example.servercraft.UI.Incidentes.Incidentes.IncidenteItemAdapter;
import com.example.servercraft.UI.Incidentes.TiposProblema.FormularioTipoProblemaFragment;
import com.example.servercraft.UI.Incidentes.TiposProblema.TipoProblemaItemAdapter;
import com.example.servercraft.Utils.UserInfo;

import java.util.ArrayList;

public class TipoProblemaItemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;

    LayoutInflater inflater;
    ArrayList<TipoProblema> model;
    FragmentManager fragmentManager;
    Context context;

    public TipoProblemaItemAdapter(Context context, ArrayList<TipoProblema> model, FragmentManager fm) {
        this.inflater = LayoutInflater.from(context);
        this.model = model;
        this.fragmentManager = fm;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = inflater.inflate(R.layout.item_list_simple, parent, false);

            return new TipoProblemaItemAdapter.ItemViewHolder(view);
        }else{
            View view = inflater.inflate(R.layout.item_list_loading, parent, false);

            return new TipoProblemaItemAdapter.LoadingViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof TipoProblemaItemAdapter.ItemViewHolder) {
            populateItemRows((TipoProblemaItemAdapter.ItemViewHolder) holder, position);
        } else if (holder instanceof TipoProblemaItemAdapter.LoadingViewHolder) {
            showLoadingView((TipoProblemaItemAdapter.LoadingViewHolder) holder, position);
        }
    }


    @Override
    public int getItemViewType(int position) {
        return model.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }

    @Override
    public int getItemCount() {
        return model == null ? 0 : model.size();
    }

    private class ItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ConstraintLayout clItemData, clItemActions;
        TextView nombre, tipo;
        Button btnEdit, btnDelete;
        ImageView ivChevronDown;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);

            nombre = itemView.findViewById(R.id.tvItemTitle);
            tipo = itemView.findViewById(R.id.tvItemDescription);
            clItemData = itemView.findViewById(R.id.clItemData);
            clItemActions = itemView.findViewById(R.id.clItemActions);
            btnEdit = itemView.findViewById(R.id.btnUpdate);
            btnDelete = itemView.findViewById(R.id.btnDelete);
            ivChevronDown = itemView.findViewById(R.id.ivChevronDown);

            int userRol = new UserInfo().getUserRol();

            if (userRol == 2) {
                btnDelete.setVisibility(View.GONE);
            }

            if (userRol == 3 || userRol == 4) {
                btnEdit.setVisibility(View.GONE);
                btnDelete.setVisibility(View.GONE);
                ivChevronDown.setVisibility(View.GONE);
            }

            clItemData.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int adapterPosition = getAbsoluteAdapterPosition();
            TipoProblema tipoProblema = model.get(adapterPosition);
            tipoProblema.isFullyVisible = !tipoProblema.isFullyVisible;

            notifyItemChanged(adapterPosition);
        }
    }



    private class LoadingViewHolder extends RecyclerView.ViewHolder {

        public LoadingViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    private void showLoadingView(TipoProblemaItemAdapter.LoadingViewHolder viewHolder, int position) {
        //ProgressBar would be displayed

    }

    private void populateItemRows(TipoProblemaItemAdapter.ItemViewHolder holder, int position) {

        // Obtención de objeto
        TipoProblema tipoProblema = model.get(position);

        // Seteo de valores en view holder
        holder.nombre.setText(tipoProblema.nombre);
        holder.clItemActions.setVisibility(tipoProblema.isFullyVisible ? View.VISIBLE : View.GONE);

        // Click listeners
        holder.btnEdit.setOnClickListener(v -> {
            FormularioTipoProblemaFragment formulario = FormularioTipoProblemaFragment.newInstance(tipoProblema);
            formulario.show(fragmentManager, formulario.getTag());
        });

        holder.btnDelete.setOnClickListener(v -> {
            AlertDialog.Builder confirmation = new AlertDialog.Builder(context);
            confirmation.setTitle("Advertencia")
                    .setMessage("¿Estás seguro de qué deseas eliminar el tipo de problema: \"" + tipoProblema.nombre  + "\"?")
                    .setCancelable(false)
                    .setPositiveButton("Eliminar", (dialog, which) -> {
                        tipoProblema.eliminar(tipoProblema.id, response -> {
                            ((Activity) context).finish();
                            ((Activity) context).overridePendingTransition(0, 0);
                            context.startActivity(((Activity) context).getIntent());
                            ((Activity) context).overridePendingTransition(0, 0);
                        }, error -> {
                            Toast.makeText(context, "Error al eliminar tipo de problema.", Toast.LENGTH_SHORT).show();
                        });
                    }).setNegativeButton("Cancelar", (dialog, which) -> {
                dialog.dismiss();
            });

            confirmation.create().show();
        });
    }
}
