package com.example.servercraft.UI.Sistema;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.servercraft.Models.Sistema;
import com.example.servercraft.R;
import com.example.servercraft.Utils.UserInfo;

import java.util.ArrayList;

public class SistemaItemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;
    LayoutInflater inflater;
    ArrayList<Sistema> model;
    FragmentManager fragmentManager;
    Context context;

    public SistemaItemAdapter(Context context, ArrayList<Sistema> model, FragmentManager fm) {
        this.inflater = LayoutInflater.from(context);
        this.model = model;
        this.fragmentManager = fm;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = inflater.inflate(R.layout.item_list_general, parent, false);

            return new ItemViewHolder(view);
        } else {
            View view = inflater.inflate(R.layout.item_list_loading, parent, false);

            return new LoadingViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        if (holder instanceof ItemViewHolder) {
            populateItemRows((ItemViewHolder) holder, position);
        } else if (holder instanceof LoadingViewHolder) {
            showLoadingView((LoadingViewHolder) holder, position);
        }
    }

    @Override
    public int getItemCount() {
        return model == null ? 0 : model.size();
    }

    @Override
    public int getItemViewType(int position) {
        return model.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }


    private class ItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ConstraintLayout clItemData, clItemActions;
        TextView nombre, estadoInstancia;
        Button btnView, btnEdit, btnDelete;
        ImageView ivChevronDown;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);

            nombre = itemView.findViewById(R.id.tvItemTitle);
            estadoInstancia = itemView.findViewById(R.id.tvItemDescription);
            clItemData = itemView.findViewById(R.id.clItemData);
            clItemActions = itemView.findViewById(R.id.clItemActions);
            btnView = itemView.findViewById(R.id.btnView);
            btnEdit = itemView.findViewById(R.id.btnUpdate);
            btnDelete = itemView.findViewById(R.id.btnDelete);
            ivChevronDown = itemView.findViewById(R.id.ivChevronDown);

            int userRol = new UserInfo().getUserRol();

            if (userRol == 2) {
                btnDelete.setVisibility(View.GONE);
            }

            if (userRol == 3 || userRol == 4) {
                btnEdit.setVisibility(View.GONE);
                btnDelete.setVisibility(View.GONE);
                ivChevronDown.setVisibility(View.GONE);
            }

            if (userRol == 4) {
                btnView.setVisibility(View.GONE);
            }

            clItemData.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int adapterPosition = getAbsoluteAdapterPosition();
            Sistema sistema = model.get(adapterPosition);
            sistema.isFullyVisible = !sistema.isFullyVisible;

            notifyItemChanged(adapterPosition);
        }
    }

    private class LoadingViewHolder extends RecyclerView.ViewHolder {

        public LoadingViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    private void showLoadingView(LoadingViewHolder viewHolder, int position) {
        //ProgressBar would be displayed

    }


    private void populateItemRows(ItemViewHolder holder, int position) {

        Sistema sistema = model.get(position);
        holder.nombre.setText(sistema.nombre);
        holder.estadoInstancia.setText(sistema.obtenerEstado(sistema.instancias));
        holder.clItemActions.setVisibility(sistema.isFullyVisible ? View.VISIBLE : View.GONE);

        holder.btnView.setOnClickListener(v -> {
            DetalleSistemaFragment detalleSistema = DetalleSistemaFragment.newInstance(sistema.id);
            detalleSistema.show(fragmentManager, detalleSistema.getTag());
        });

        holder.btnEdit.setOnClickListener(v -> {
            FormularioSistemaFragment formSistema = FormularioSistemaFragment.newInstance(sistema.id);
            formSistema.show(fragmentManager, formSistema.getTag());
        });

        holder.btnDelete.setOnClickListener(v -> {
            AlertDialog.Builder confirmation = new AlertDialog.Builder(context);
            confirmation.setTitle("Advertencia")
                    .setMessage("¿Estás seguro de qué deseas eliminar el sistema: \""+ sistema.nombre  +"\"?")
                    .setCancelable(false)
                    .setPositiveButton("Eliminar", (dialog, which) -> {
                        sistema.eliminar(sistema.id, response -> {
                            ((Activity) context).finish();
                            ((Activity) context).overridePendingTransition(0, 0);
                            ((Activity) context).startActivity(((Activity) context).getIntent());
                            ((Activity) context).overridePendingTransition(0, 0);
                        }, error -> {
                            Toast.makeText(context, "Error al eliminar sistema.", Toast.LENGTH_SHORT).show();
                        });
                    }).setNegativeButton("Cancelar", (dialog, which) -> {
                dialog.dismiss();
            });

            confirmation.create().show();
        });

        switch (sistema.obtenerEstado(sistema.instancias)) {
            case "Operativo":
                holder.estadoInstancia.setTextColor(ContextCompat.getColor(context, R.color.success_500));
                break;

            case "En mantención":
                holder.estadoInstancia.setTextColor(ContextCompat.getColor(context, R.color.warning_500));
                break;

            case "Con errores":
                holder.estadoInstancia.setTextColor(ContextCompat.getColor(context, R.color.danger_500));
                break;

            default:
                holder.estadoInstancia.setTextColor(ContextCompat.getColor(context, R.color.gray_500));
                break;
        }
    }
}
