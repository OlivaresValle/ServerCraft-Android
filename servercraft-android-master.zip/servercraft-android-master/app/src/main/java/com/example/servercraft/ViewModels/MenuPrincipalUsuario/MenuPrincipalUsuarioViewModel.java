package com.example.servercraft.ViewModels.MenuPrincipalUsuario;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.Menu;
import com.example.servercraft.R;
import com.example.servercraft.Utils.UserInfo;

import java.util.ArrayList;

public class MenuPrincipalUsuarioViewModel extends ViewModel {
    private MutableLiveData<ArrayList<Menu>> mMenuList;

    public MenuPrincipalUsuarioViewModel() {
        mMenuList = new MutableLiveData<>();
        mMenuList.setValue(obtenerMenu());
    }

    public LiveData<ArrayList<Menu>> getMenuList() {
        return mMenuList;
    }

    private ArrayList<Menu> obtenerMenu() {
        ArrayList<Menu> list = new ArrayList<>();

        int userRol = new UserInfo().getUserRol();

        if (userRol != 4) list.add(new Menu(R.drawable.server_icon, "Salas, Racks y Servidores", "Listar, crear, editar o eliminar salas, racks y servidores"));
        list.add(new Menu(R.drawable.system_icon, "Sistemas o aplicaciones", "Listar, crear, editar o eliminar sistemas"));
        if (userRol != 4) list.add(new Menu(R.drawable.users_icon, "Usuarios y equipos", "Administrar usuarios y equipos de trabajo"));
        if (userRol != 4) list.add(new Menu(R.drawable.customer_icon, "Clientes y proveedores", "Administrar clientes y proveedores de sistemas"));
        if (userRol != 4) list.add(new Menu(R.drawable.programming_icon, "Lenguajes de programación", "Administrar lenguajes utilizados en Homero"));
        if (userRol == 1 || userRol == 2) list.add(new Menu(R.drawable.database_icon, "Motores de bases de datos", "Administrar motores disponibles"));
        if (userRol != 4) list.add(new Menu(R.drawable.services_icon, "Servicios Auxiliares", "Administrar servicios disponibles para aplicaciones"));
        if (userRol == 1) list.add(new Menu(R.drawable.location_icon, "Ubicaciones", "Administrar ubicaciones físicas disponibles"));

        return list;
    }
}