package com.example.servercraft.UI.SplashScreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.example.servercraft.Models.Usuario;
import com.example.servercraft.UI.Login.LoginActivity;
import com.example.servercraft.UI.MenuPrincipalUsuario.MenuPrincipal;
import com.example.servercraft.Utils.Preferences;
import com.example.servercraft.Utils.UserInfo;
import com.example.servercraft.databinding.ActivitySplashBinding;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONObject;

public class SplashActivity extends AppCompatActivity {
    ActivitySplashBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Configuración Binding
        super.onCreate(savedInstanceState);
        binding = ActivitySplashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Preferences auth = new Preferences("auth");

        if (auth.getString("token") != "") {
            Usuario usuario = new Usuario();


            usuario.obtener(0, response -> {
                try {
                    JSONObject httpUsuario = response.getJSONObject("usuario");
                    Usuario objectUsuario = mapUsuarioIntoObject(httpUsuario);

                    new UserInfo().setUserRol(objectUsuario.rol.id);
                    new UserInfo().setUserImage(objectUsuario.imagen.url);
                } catch (Exception e) {
                    new UserInfo().setUserImage("");
                }

                Intent menuPrincipal = new Intent(SplashActivity.this, MenuPrincipal.class);

                startActivity(menuPrincipal);
                finish();
            }, error -> {
                goToLogin();
            }, null);
        } else {
            goToLogin();
        }
    }

    private void goToLogin() {
        Intent login = new Intent(SplashActivity.this, LoginActivity.class);
        new UserInfo().setUserImage("");
        new UserInfo().setUserRol(0);

        startActivity(login);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }

    private Usuario mapUsuarioIntoObject(JSONObject httpUsuario) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Usuario usuario = gson.fromJson(httpUsuario.toString(), Usuario.class);

        return usuario;
    }
}