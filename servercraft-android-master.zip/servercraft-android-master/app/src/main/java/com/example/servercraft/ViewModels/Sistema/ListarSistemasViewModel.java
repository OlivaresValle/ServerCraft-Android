package com.example.servercraft.ViewModels.Sistema;

import android.util.Log;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.Sistema;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.JSONArray;
import org.json.JSONException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import org.json.JSONObject;
import java.util.Objects;

public class ListarSistemasViewModel extends ViewModel {
    private MutableLiveData<ArrayList<Sistema>> mSistemaList;
    public ArrayList<Sistema> arSistema = new ArrayList<>();

    public boolean cargandoDatos = false;
    public boolean blPuedeCargarMas = true;
    public int pagina = 0;
    public String busqueda="";

    // Constructor
    public ListarSistemasViewModel() {
        mSistemaList = new MutableLiveData<>();

        loadHTTPSistemaList();
    }

    // Getters
    public MutableLiveData<ArrayList<Sistema>> getSistemaList() {
        return mSistemaList;
    }

    // Setters
    public void loadHTTPSistemaList() {
        if (blPuedeCargarMas) {
            Sistema sistema = new Sistema();

            pagina = pagina + 1;

            if (arSistema.size() != 0) {
                arSistema.add(null);
                mSistemaList.setValue(arSistema);
            }

            sistema.listar(10, pagina, busqueda, null, response -> {
                try {
                    JSONArray httpSistema = response.getJSONArray("sistema");
                    JSONObject httpMeta = response.getJSONObject("meta");

                    arSistema.removeIf(Objects::isNull);


                    if (httpMeta.getInt("last_page") == pagina) {
                        blPuedeCargarMas = false;
                    }

                    arSistema.addAll(mapSistemaIntoObject(httpSistema));

                    mSistemaList.setValue(arSistema);

                    cargandoDatos = false;
                } catch (JSONException e) {
                    Log.e("Listar leng", e.toString());
                }
            }, error -> Log.d("Error de ", error.toString()));
        }
    }

    private ArrayList<Sistema> mapSistemaIntoObject(JSONArray httpSistemas) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type SistemaArray = new TypeToken<ArrayList<Sistema>>() {
        }.getType();
        ArrayList<Sistema> sistemaList = gson.fromJson(httpSistemas.toString(), SistemaArray);

        return sistemaList;
    }
}
