package com.example.servercraft.ViewModels.Ubicacion.Pais.FormularioPais;

import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.servercraft.Models.Pais;

import java.util.ArrayList;

public class FormularioPaisViewModel extends ViewModel {
    private MutableLiveData<Pais> mPais;

    // Constructor
    public FormularioPaisViewModel(@Nullable Pais pais) {
        if (pais != null) {
            mPais = new MutableLiveData<>();

            mPais.setValue(pais);
        }
    }

    // Getters
    public MutableLiveData<Pais> getPais() {
        return mPais;
    }

    public boolean hasPais() {
        return mPais != null;
    }

}
