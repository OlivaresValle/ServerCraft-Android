package com.example.servercraft.ViewModels.Ubicacion.Pais.FormularioPais;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.example.servercraft.Models.Pais;

import org.jetbrains.annotations.Nullable;

public class FormularioPaisViewModelFactory implements ViewModelProvider.Factory {
    private Pais mPais;

    public FormularioPaisViewModelFactory(@Nullable Pais pais){
        if (pais != null){
            this.mPais = pais;
        }
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass){
        return (T) new FormularioPaisViewModel(mPais);
    }

}
