package com.example.servercraft.UI.MenuPrincipalUsuario;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.servercraft.Models.Menu;
import com.example.servercraft.R;
import java.util.ArrayList;

public class MenuItemAdapter extends RecyclerView.Adapter<MenuItemAdapter.ViewHolder> implements View.OnClickListener {
    LayoutInflater inflater;
    ArrayList<Menu> model;
    private View.OnClickListener listener;

    public MenuItemAdapter(Context context, ArrayList<Menu> model) {
        this.inflater = LayoutInflater.from(context);
        this.model = model;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.item_list_menu_prinicipal, parent, false);
        view.setOnClickListener(this);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        int icono = model.get(position).getIcono();
        String titulo = model.get(position).getTitulo();
        String descripcion = model.get(position).getDescripcion();

        holder.icono.setImageResource(icono);
        holder.titulo.setText(titulo);
        holder.descripcion.setText(descripcion);
    }

    @Override
    public int getItemCount() {
        return model.size();
    }

    public void setOnClickListener(View.OnClickListener listener) {
        this.listener = listener;
    }

    @Override
    public void onClick(View view) {
        if (listener != null) {
            listener.onClick(view);
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView titulo, descripcion;
        ImageView icono;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            icono = itemView.findViewById(R.id.ivIcono);
            titulo = itemView.findViewById(R.id.tvTituloMenu);
            descripcion = itemView.findViewById(R.id.tvDescripcionMenu);
        }
    }
}
