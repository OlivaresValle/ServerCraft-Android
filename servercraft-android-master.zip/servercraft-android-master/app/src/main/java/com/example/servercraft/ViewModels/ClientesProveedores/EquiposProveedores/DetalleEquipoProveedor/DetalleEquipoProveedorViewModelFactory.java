package com.example.servercraft.ViewModels.ClientesProveedores.EquiposProveedores.DetalleEquipoProveedor;

import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

public class DetalleEquipoProveedorViewModelFactory implements ViewModelProvider.Factory {
    private Integer mEquipoId;

    public DetalleEquipoProveedorViewModelFactory(@Nullable Integer equipoId) {
        if (equipoId != null) {
            this.mEquipoId = equipoId;
        }
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        return (T) new DetalleEquipoProveedorViewModel(mEquipoId);
    }
}
