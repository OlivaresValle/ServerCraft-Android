package com.example.servercraft.ViewModels.LenguajesProgramacion.FormularioLenguaje;

import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.Lenguaje;

public class FormularioLenguajeViewModel extends ViewModel {
    private MutableLiveData<Lenguaje> mLenguaje;

    // Constructor
    public FormularioLenguajeViewModel(@Nullable Lenguaje lenguaje) {
        if (lenguaje != null) {
            mLenguaje = new MutableLiveData<>();

            mLenguaje.setValue(lenguaje);
        }
    }

    // Getters
    public MutableLiveData<Lenguaje> getLenguaje() {
        return mLenguaje;
    }

    public boolean hasLenguaje() {
        return mLenguaje != null;
    }
}
