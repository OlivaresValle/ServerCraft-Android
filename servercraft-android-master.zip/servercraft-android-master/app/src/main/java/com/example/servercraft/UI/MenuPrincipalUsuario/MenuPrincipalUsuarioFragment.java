package com.example.servercraft.UI.MenuPrincipalUsuario;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.servercraft.UI.BaseDeDatos.ListarBaseDatos;
import com.example.servercraft.UI.LenguajesProgramacion.ListarLenguajesProgramacion;
import com.example.servercraft.UI.ServicioWeb.ListarServicioWeb;
import com.example.servercraft.UI.Sistema.ListarSistemas;
import com.example.servercraft.UI.ClientesProveedores.ClientesProveedores;
import com.example.servercraft.UI.ServidoresRacksSalas.ServidoresRacksSalas;
import com.example.servercraft.UI.UsuariosEquipos.UsuariosEquipos;
import com.example.servercraft.UI.Ubicacion.Ubicaciones;
import com.example.servercraft.ViewModels.MenuPrincipalUsuario.MenuPrincipalUsuarioViewModel;
import com.example.servercraft.databinding.FragmentMenuPrincipalBinding;

public class MenuPrincipalUsuarioFragment extends Fragment {
    private FragmentMenuPrincipalBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Configuración Binding
        MenuPrincipalUsuarioViewModel menuPrincipalUsuarioViewModel = new ViewModelProvider(this).get(MenuPrincipalUsuarioViewModel.class);
        binding = FragmentMenuPrincipalBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        menuPrincipalUsuarioViewModel.getMenuList().observe(getViewLifecycleOwner(), menus -> {
            MenuItemAdapter menuAdapter = new MenuItemAdapter(root.getContext(), menus);
            binding.rvMenuPrincipalUsuario.setLayoutManager(new LinearLayoutManager(root.getContext()));

            menuAdapter.setOnClickListener(v -> {
                String titulo = menus.get(binding.rvMenuPrincipalUsuario.getChildAdapterPosition(v)).getTitulo();

                switch (titulo) {
                    case "Salas, Racks y Servidores": {
                        Intent i = new Intent(root.getContext(), ServidoresRacksSalas.class);
                        startActivity(i);
                        break;
                    }

                    case "Sistemas o aplicaciones": {
                        Intent i = new Intent(root.getContext(), ListarSistemas.class);
                        startActivity(i);
                        break;
                    }

                    case "Usuarios y equipos": {
                        Intent i = new Intent(root.getContext(), UsuariosEquipos.class);
                        startActivity(i);
                        break;
                    }

                    case "Clientes y proveedores": {
                        Intent i = new Intent(root.getContext(), ClientesProveedores.class);
                        startActivity(i);
                        break;
                    }

                    case "Lenguajes de programación": {
                        Intent i = new Intent(root.getContext(), ListarLenguajesProgramacion.class);
                        startActivity(i);
                        break;
                    }

                    case "Motores de bases de datos": {
                        Intent i = new Intent(root.getContext(), ListarBaseDatos.class);
                        startActivity(i);
                        break;
                    }

                    case "Servicios Auxiliares": {
                        Intent i = new Intent(root.getContext(), ListarServicioWeb.class);
                        startActivity(i);
                        break;
                    }

                    case "Ubicaciones":{
                        Intent i = new Intent(root.getContext(), Ubicaciones.class);
                        startActivity(i);
                        break;
                    }
                }
            });

            binding.rvMenuPrincipalUsuario.setAdapter(menuAdapter);
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
