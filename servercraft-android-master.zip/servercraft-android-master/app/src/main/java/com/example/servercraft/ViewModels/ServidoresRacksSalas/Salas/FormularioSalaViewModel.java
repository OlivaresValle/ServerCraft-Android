package com.example.servercraft.ViewModels.ServidoresRacksSalas.Salas;

import android.util.Log;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.Region;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.JSONArray;
import org.json.JSONException;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class FormularioSalaViewModel extends ViewModel {
    private MutableLiveData<ArrayList<Region>> mRegiones;

    // Constructor
    public FormularioSalaViewModel() {
        mRegiones = new MutableLiveData<>();

        loadHTTPRegionList();
    }

    // Getters
    public MutableLiveData<ArrayList<Region>> getRegionesList() {
        return mRegiones;
    }

    // Setters
    private void loadHTTPRegionList() {
        Region region = new Region();

        region.listar(1000,1 ,null,null, response -> {
            try {
                JSONArray httpRegiones = response.getJSONArray("regiones");

                ArrayList<Region> objectRegiones = mapSalaIntoObject(httpRegiones);

                mRegiones.setValue(objectRegiones);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<Region> mapSalaIntoObject(JSONArray httpRegiones) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type RegionArray = new TypeToken<ArrayList<Region>>() {
        }.getType();
        ArrayList<Region> regionesList = gson.fromJson(httpRegiones.toString(), RegionArray);

        return regionesList;
    }
}
