package com.example.servercraft.ViewModels.Sistema.DetalleSistema;

import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

public class DetalleSistemaViewModelFactory implements ViewModelProvider.Factory {
    private Integer mSistemaId;

    public DetalleSistemaViewModelFactory(@Nullable Integer sistemaId) {
        if (sistemaId != null) {
            this.mSistemaId = sistemaId;
        }
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        return (T) new DetalleSistemaViewModel(mSistemaId);
    }
}
