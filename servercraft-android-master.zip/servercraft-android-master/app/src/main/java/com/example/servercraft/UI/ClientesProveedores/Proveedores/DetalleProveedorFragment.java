package com.example.servercraft.UI.ClientesProveedores.Proveedores;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import com.example.servercraft.ViewModels.ClientesProveedores.Proveedores.DetalleProveedor.DetalleProveedorViewModel;
import com.example.servercraft.ViewModels.ClientesProveedores.Proveedores.DetalleProveedor.DetalleProveedorViewModelFactory;
import com.example.servercraft.databinding.FragmentDetalleProveedorBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class DetalleProveedorFragment extends BottomSheetDialogFragment {
    private static final String ARG_ID_PROVEEDOR = "id_proveedor";
    private DetalleProveedorViewModel detalleViewModel;
    private FragmentDetalleProveedorBinding binding;

    public static DetalleProveedorFragment newInstance(int idProveedor) {
        DetalleProveedorFragment fragment = new DetalleProveedorFragment();
        Bundle bundle = new Bundle();

        bundle.putInt(ARG_ID_PROVEEDOR, idProveedor);
        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int proveedorId = 1;

        if (getArguments() != null) {
            proveedorId = getArguments().getInt(ARG_ID_PROVEEDOR);
        }

        detalleViewModel = new ViewModelProvider(this, new DetalleProveedorViewModelFactory(proveedorId)).get(DetalleProveedorViewModel.class);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentDetalleProveedorBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Observador de consulta HTTP
        detalleViewModel.getProveedor().observe(getViewLifecycleOwner(), proveedorSistema -> {
            // Cargar datos cuando estén disponibles
            binding.tvProveedorTitle.setText(proveedorSistema.nombre);
            binding.tvPRepresentanteData.setText(proveedorSistema.nombreRepresentante);
            binding.tvPEmailContactoData.setText(proveedorSistema.emailContacto);
            binding.tvPTelefonoContactoData.setText(proveedorSistema.telefonoContacto);

            // Ocultar vista de "cargando..."
            binding.clLoadingProveedor.setVisibility(View.GONE);
            binding.lProveedorTab.setVisibility(View.VISIBLE);
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}