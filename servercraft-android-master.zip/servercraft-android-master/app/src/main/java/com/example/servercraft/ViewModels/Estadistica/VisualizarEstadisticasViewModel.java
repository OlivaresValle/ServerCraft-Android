package com.example.servercraft.ViewModels.Estadistica;

import android.util.Log;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.servercraft.Models.Estadistica;
import com.example.servercraft.Models.EstadisticaCliente;
import com.example.servercraft.Models.EstadisticaIncidente;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class VisualizarEstadisticasViewModel extends ViewModel {
    // Arrays mutables para ocupar observer
    private MutableLiveData<ArrayList<EstadisticaCliente>> mEstadisticaCliente;
    private MutableLiveData<ArrayList<EstadisticaIncidente>> mEstadisticaIncidente;

    // Arrays simples para manejar los datos
    public ArrayList<EstadisticaCliente> arEstadisticaCliente = new ArrayList<>();
    public ArrayList<EstadisticaIncidente> arEstadisticaIncidente = new ArrayList<>();

    // Constructor
    public VisualizarEstadisticasViewModel() {
        mEstadisticaCliente = new MutableLiveData<>();
        mEstadisticaIncidente = new MutableLiveData<>();
        loadHTTPEstadisticasList();
    }

    // Getters
    public MutableLiveData<ArrayList<EstadisticaCliente>> getEstadisticaClienteList() {
        return mEstadisticaCliente;
    }

    public MutableLiveData<ArrayList<EstadisticaIncidente>> getEstadisticaIncidenteList() {
        return mEstadisticaIncidente;
    }

    // Setters
    public void loadHTTPEstadisticasList() {
        // Clientes
        Estadistica estadistica = new Estadistica();

        estadistica.obtenerClientesNuevos(response -> {
            try {
                JSONArray httpEstadisticaClientes = response.getJSONArray("data");

                arEstadisticaCliente.addAll(mapEstadisticaClienteIntoObject(httpEstadisticaClientes));

                mEstadisticaCliente.setValue(arEstadisticaCliente);
            } catch (JSONException e) {
                Log.e("Listar estadistica clientes", e.toString());
            }
        }, error -> Log.d("Error de ", error.toString()));

        estadistica.obtenerIncidentesActivos(response -> {
            try {
                JSONArray httpEstadisticaIncidentes = response.getJSONArray("data");

                arEstadisticaIncidente.addAll(mapEstadisticaIncidenteIntoObject(httpEstadisticaIncidentes));

                mEstadisticaIncidente.setValue(arEstadisticaIncidente);
            } catch (JSONException e) {
                Log.e("Listar estadistica incidentes", e.toString());
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<EstadisticaCliente> mapEstadisticaClienteIntoObject(JSONArray httpEstadisticaCliente) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type EstadisticaClienteArray = new TypeToken<ArrayList<EstadisticaCliente>>() {
        }.getType();
        ArrayList<EstadisticaCliente> estadisticaClienteList = gson.fromJson(httpEstadisticaCliente.toString(), EstadisticaClienteArray);

        return estadisticaClienteList;
    }

    private ArrayList<EstadisticaIncidente> mapEstadisticaIncidenteIntoObject(JSONArray httpEstadisticaIncidente) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type EstadisticaIncidenteArray = new TypeToken<ArrayList<EstadisticaIncidente>>() {
        }.getType();
        ArrayList<EstadisticaIncidente> estadisticaIncidenteList = gson.fromJson(httpEstadisticaIncidente.toString(), EstadisticaIncidenteArray);

        return estadisticaIncidenteList;
    }
}
