package com.example.servercraft.ViewModels.ServidoresRacksSalas.Racks;

import android.util.Log;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.servercraft.Models.Lenguaje;
import com.example.servercraft.Models.Rack;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Objects;

public class ListarRacksViewModel extends ViewModel {
    private MutableLiveData<ArrayList<Rack>> mRackList;
    public ArrayList<Rack> arRack = new ArrayList<>();

    public boolean cargandoDatos = false;
    public boolean blPuedeCargarMas = true;
    public int pagina = 0;
    public String busqueda = "";


    // Constructor
    public ListarRacksViewModel() {
        mRackList = new MutableLiveData<>();

        loadHTTPRackList();
    }

    // Getters
    public MutableLiveData<ArrayList<Rack>> getRackList() {
        return mRackList;
    }

    // Setters
    public void loadHTTPRackList() {
        if (blPuedeCargarMas) {
            Rack rack = new Rack();

            pagina = pagina + 1;

            if (arRack.size() != 0) {
                arRack.add(null);
                mRackList.setValue(arRack);
            }


        rack.listar(10,pagina,busqueda,null, response -> {
            try {
                JSONArray httpRacks = response.getJSONArray("racks");
                JSONObject httpMeta = response.getJSONObject("meta");

                Log.d("Resultados",httpRacks.toString());

                arRack.removeIf(Objects::isNull);


                if (httpMeta.getInt("last_page") == pagina) {
                    blPuedeCargarMas = false;
                }

                arRack.addAll(mapServerIntoObject(httpRacks));

                mRackList.setValue(arRack);

                cargandoDatos = false;
            } catch (JSONException e) {
                Log.e("Listar leng", e.toString());
            }
        }, error -> Log.d("Error de ", error.toString()));
        }
    }

    private ArrayList<Rack> mapServerIntoObject(JSONArray httpRacks) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type RackArray = new TypeToken<ArrayList<Rack>>() {
        }.getType();
        ArrayList<Rack> rackList = gson.fromJson(httpRacks.toString(), RackArray);

        return rackList;
    }
}
