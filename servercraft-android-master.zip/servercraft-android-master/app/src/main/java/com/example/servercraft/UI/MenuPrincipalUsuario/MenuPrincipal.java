package com.example.servercraft.UI.MenuPrincipalUsuario;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;
import android.Manifest;
import android.os.Bundle;
import com.example.servercraft.R;
import com.example.servercraft.Utils.UserInfo;
import com.example.servercraft.databinding.ActivityMenuPrincipalBinding;
import com.squareup.picasso.Picasso;


public class MenuPrincipal extends AppCompatActivity {
    private ActivityMenuPrincipalBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);

        // Configuración Binding
        super.onCreate(savedInstanceState);
        binding = ActivityMenuPrincipalBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Toolbar
        setSupportActionBar(binding.includeToolbar.tbMain);
        binding.includeToolbar.tbMain.setElevation(16);

        String userImage = new UserInfo().getUserImage();

        if (!userImage.equals("")) {
            Picasso.get().load(userImage).into(binding.includeToolbar.ivTbUsuario);
        }

        // Navbar
        NavController navController = Navigation.findNavController(this, R.id.fMainContainer);
        NavigationUI.setupWithNavController(binding.navView, navController);

        navController.addOnDestinationChangedListener((controller, destination, arguments) -> {
            switch (destination.getId()) {
                case R.id.navigation_menu:
                case R.id.navigation_incidentes:
                    binding.includeToolbar.tbMain.setElevation(16);
                    binding.includeToolbar.tvTbTitle.setText("Menu Principal");
                    binding.includeToolbar.tvTbDescripcion.setText("Selecciona una de las opciones disponibles");
                    break;
                case R.id.navigation_perfil:
                    binding.includeToolbar.tbMain.setElevation(0);
                    binding.includeToolbar.tvTbTitle.setText("Perfil de usuario");
                    binding.includeToolbar.tvTbDescripcion.setText("Administra tu cuenta e información personal");
                    break;
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}