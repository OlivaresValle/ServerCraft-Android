package com.example.servercraft.ViewModels.Incidentes.Incidentes;

import android.util.Log;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.servercraft.Models.Incidente;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Objects;

public class ListarIncidentesViewModel extends ViewModel {
    private MutableLiveData<ArrayList<Incidente>> mIncidentesList;
    public ArrayList<Incidente> arIncidente = new ArrayList<>();

    public boolean cargandoDatos = false;
    public boolean blPuedeCargarMas = true;
    public int pagina = 0;
    public String busqueda = "";

    // Constructor
    public ListarIncidentesViewModel() {
        mIncidentesList = new MutableLiveData<>();
        loadHTTPIncidentesList();
    }

    // Getters
    public MutableLiveData<ArrayList<Incidente>> getIncidenteList() {
        return mIncidentesList;
    }

    // Setters
    public void loadHTTPIncidentesList() {

        if (blPuedeCargarMas) {
            Incidente incidente = new Incidente();

            pagina = pagina + 1;

            if (arIncidente.size() != 0) {
                arIncidente.add(null);
                mIncidentesList.setValue(arIncidente);
            }


            incidente.listar(10, pagina, busqueda, null, response -> {

                try {
                    JSONArray httpIncidentes = response.getJSONArray("incidentes");
                    JSONObject httpMeta = response.getJSONObject("meta");

                    arIncidente.removeIf(Objects::isNull);

                    if (httpMeta.getInt("last_page") == pagina) {
                        blPuedeCargarMas = false;
                    }

                    arIncidente.addAll(mapIncidenteIntoObject(httpIncidentes));

                    mIncidentesList.setValue(arIncidente);
                    cargandoDatos = false;

                } catch (JSONException e) {
                }
            }, error -> Log.d("Error de ", error.toString()));
        }
    }


    private ArrayList<Incidente> mapIncidenteIntoObject(JSONArray httpIncidentes) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type IncidenteArray = new TypeToken<ArrayList<Incidente>>() {
        }.getType();
        ArrayList<Incidente> incidenteList = gson.fromJson(httpIncidentes.toString(), IncidenteArray);

        return incidenteList;
    }
}
