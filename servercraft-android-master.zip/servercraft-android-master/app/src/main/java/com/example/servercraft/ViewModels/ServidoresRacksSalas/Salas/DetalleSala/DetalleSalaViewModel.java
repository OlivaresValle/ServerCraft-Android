package com.example.servercraft.ViewModels.ServidoresRacksSalas.Salas.DetalleSala;

import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.Sala;

public class DetalleSalaViewModel extends ViewModel {
    private MutableLiveData<Sala> mSala;

    // Constructor
    public DetalleSalaViewModel(@Nullable Sala sala) {
        mSala = new MutableLiveData<>();

        mSala.setValue(sala);
    }

    // Getters
    public MutableLiveData<Sala> getSala() {
        return mSala;
    }

    public boolean hasSala() {
        return mSala != null;
    }
}
