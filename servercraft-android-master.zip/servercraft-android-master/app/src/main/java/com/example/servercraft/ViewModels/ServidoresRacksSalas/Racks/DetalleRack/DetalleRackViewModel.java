package com.example.servercraft.ViewModels.ServidoresRacksSalas.Racks.DetalleRack;

import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.Rack;

public class DetalleRackViewModel extends ViewModel {
    private MutableLiveData<Rack> mRack;

    // Constructor
    public DetalleRackViewModel(@Nullable Rack rack) {
        mRack = new MutableLiveData<>();

        mRack.setValue(rack);
    }

    // Getters
    public MutableLiveData<Rack> getRack() {
        return mRack;
    }

    public boolean hasRack() {
        return mRack != null;
    }
}
