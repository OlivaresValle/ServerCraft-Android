package com.example.servercraft.ViewModels.UsuariosEquipos.Usuarios;

import android.util.Log;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.EquipoTrabajo;
import com.example.servercraft.Models.Rol;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.JSONArray;
import org.json.JSONException;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class FormularioUsuarioViewModel extends ViewModel {
    private MutableLiveData<ArrayList<Rol>> mRoles;
    private MutableLiveData<ArrayList<EquipoTrabajo>> mEquipos;
    public int pagina = 1;
    public String busqueda = "";


    // Constructor
    public FormularioUsuarioViewModel() {
        mRoles = new MutableLiveData<>();
        mEquipos = new MutableLiveData<>();

        loadHTTPRolList();
        loadHTTPEquipoTrabajoList();
    }

    // Getters
    public MutableLiveData<ArrayList<Rol>> getRolList() {
        return mRoles;
    }

    public MutableLiveData<ArrayList<EquipoTrabajo>> getEquipoTrabajoList() {
        return mEquipos;
    }

    // Setters
    // 1 - Roles
    private void loadHTTPRolList() {
        Rol rol = new Rol();

        rol.listar(null, response -> {
            try {
                JSONArray httpRoles = response.getJSONArray("rol");

                ArrayList<Rol> objectRolList = mapRolesIntoObject(httpRoles);

                mRoles.setValue(objectRolList);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<Rol> mapRolesIntoObject(JSONArray httpRol) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type RolArray = new TypeToken<ArrayList<Rol>>() {
        }.getType();
        ArrayList<Rol> rolList = gson.fromJson(httpRol.toString(), RolArray);

        return rolList;
    }

    // 2 - Equipos de Trabajo
    private void loadHTTPEquipoTrabajoList() {
        EquipoTrabajo equipoTrabajo = new EquipoTrabajo();

        equipoTrabajo.listar(100000,pagina,null,null, response -> {
            try {
                JSONArray httpEquipos = response.getJSONArray("equipos_trabajo");

                ArrayList<EquipoTrabajo> objectEquipos = mapEquiposIntoObject(httpEquipos);

                mEquipos.setValue(objectEquipos);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private ArrayList<EquipoTrabajo> mapEquiposIntoObject(JSONArray httpEquipos) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Type EquiposTrabajoArray = new TypeToken<ArrayList<EquipoTrabajo>>() {}.getType();
        ArrayList<EquipoTrabajo> equiposTrabajoList = gson.fromJson(httpEquipos.toString(), EquiposTrabajoArray);

        return equiposTrabajoList;
    }
}
