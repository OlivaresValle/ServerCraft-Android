package com.example.servercraft.Models;

public class UsuarioResponse {
    public boolean status;
    public String message;
    public Usuario usuario;
}
