package com.example.servercraft.UI.Incidentes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.example.servercraft.UI.Incidentes.Incidentes.FormularioIncidenteFragment;
import com.example.servercraft.UI.Incidentes.TiposProblema.FormularioTipoProblemaFragment;
import com.example.servercraft.UI.Incidentes.TiposSolucion.FormularioTipoSolucionFragment;
import com.example.servercraft.Utils.UserInfo;
import com.example.servercraft.databinding.ActivityIncidentesBinding;
import com.google.android.material.tabs.TabLayout;

public class IncidentesTab extends AppCompatActivity {
    ActivityIncidentesBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Configuración binding de layout
        super.onCreate(savedInstanceState);
        binding = ActivityIncidentesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Botón flotante
        binding.btnCrearIncidenteMenu.setOnClickListener(v -> {
            FormularioIncidenteFragment formulario = FormularioIncidenteFragment.newInstance(null);
            formulario.show(getSupportFragmentManager(), formulario.getTag());
        });

        // Toolbar
        Toolbar tbMain = binding.tbMainIncidentes.tbMain;
        TextView tbTitle = binding.tbMainIncidentes.tvTbTitle;

        setSupportActionBar(tbMain);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        binding.tbMainIncidentes.cvUsuarioMenuPrincipal.setVisibility(View.GONE);
        tbTitle.setText("Incidentes");
        tbMain.setContentInsetStartWithNavigation(0);
        tbMain.setNavigationOnClickListener(v -> {
            finish();
        });

        // Configuración Tabs
        IncidentesPagerAdapter sectionsPagerAdapter = new IncidentesPagerAdapter(this, getSupportFragmentManager());

        ViewPager viewPager = binding.vpIncidentes;
        viewPager.setAdapter(sectionsPagerAdapter);

        TabLayout tabs = binding.tabIncidentes;
        tabs.setupWithViewPager(viewPager);

        int userRol = new UserInfo().getUserRol();

        if (userRol == 3 || userRol == 4) {
            binding.btnCrearIncidenteMenu.setVisibility(View.GONE);
        }

        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                switch (position) {
                    case 0:
                        tbTitle.setText("Incidentes");

                        binding.btnCrearIncidenteMenu.setOnClickListener(v -> {
                            FormularioIncidenteFragment formulario = FormularioIncidenteFragment.newInstance(null);
                            formulario.show(getSupportFragmentManager(), formulario.getTag());
                        });

                        break;
                    case 1:
                        tbTitle.setText("Tipos de problema");

                        binding.btnCrearIncidenteMenu.setOnClickListener(v -> {
                            FormularioTipoProblemaFragment formulario = FormularioTipoProblemaFragment.newInstance(null);
                            formulario.show(getSupportFragmentManager(), formulario.getTag());
                        });

                        break;
                    case 2:
                        tbTitle.setText("Tipos de solución");

                        binding.btnCrearIncidenteMenu.setOnClickListener(v -> {
                            FormularioTipoSolucionFragment formulario = FormularioTipoSolucionFragment.newInstance(null);
                            formulario.show(getSupportFragmentManager(), formulario.getTag());
                        });
                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

    }
}