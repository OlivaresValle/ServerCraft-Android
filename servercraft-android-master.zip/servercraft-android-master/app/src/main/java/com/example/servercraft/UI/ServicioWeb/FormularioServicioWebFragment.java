package com.example.servercraft.UI.ServicioWeb;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.ViewModelProvider;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.servercraft.Models.ServicioWeb;
import com.example.servercraft.R;
import com.example.servercraft.Utils.AdapterMaterialSpinner;
import com.example.servercraft.ViewModels.ServicioWeb.DetalleServicioWeb.DetalleServicioWebViewModel;
import com.example.servercraft.ViewModels.ServicioWeb.DetalleServicioWeb.DetalleServicioWebViewModelFactory;
import com.example.servercraft.ViewModels.ServicioWeb.FormularioServicioWebViewModel;
import com.example.servercraft.databinding.FragmentFormularioServicioWebBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class FormularioServicioWebFragment extends BottomSheetDialogFragment implements Validator.ValidationListener {
    // Configuración de View Model
    private static final String ARG_SW = "servicio_web";
    private DetalleServicioWebViewModel detalleViewModel;
    private FormularioServicioWebViewModel formularioViewModel;
    private FragmentFormularioServicioWebBinding binding;

    private Validator validator;
    private View root;

    // Validaciones
    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etNombreServicios;

    @NonNull
    @NotEmpty(message = "Campo obligatorio")
    EditText etDescripcionServicios;

    EditText etNombre, etDescripcion;


    ConstraintLayout clLoading;
    LinearLayout lServicioWebForm;

    // Botón Submit
    MaterialButton btnCrearServicioWeb;

    public static FormularioServicioWebFragment newInstance(@Nullable ServicioWeb servicioWeb) {
        FormularioServicioWebFragment fragment = new FormularioServicioWebFragment();

        if (servicioWeb != null) {
            Bundle bundle = new Bundle();
            Gson gson = new Gson();

            bundle.putString(ARG_SW, gson.toJson(servicioWeb));
            fragment.setArguments(bundle);
        }

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            Gson gson = new Gson();
            String jsonServicioWeb = getArguments().getString(ARG_SW);
            ServicioWeb servicioWeb = gson.fromJson(jsonServicioWeb, ServicioWeb.class);

            detalleViewModel = new ViewModelProvider(this, new DetalleServicioWebViewModelFactory(servicioWeb)).get(DetalleServicioWebViewModel.class);
        }

        formularioViewModel = new ViewModelProvider(this).get(FormularioServicioWebViewModel.class);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentFormularioServicioWebBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        // Instanciamiento del validador
        validator = new Validator(this);
        validator.setValidationListener(this);

        // Intanciamiento de los campos a validar
        etNombreServicios = binding.etServicioWebNombreCrear;
        etDescripcionServicios = binding.etServicioWebDescripcionCrear;

        // Loading Status
        clLoading = root.findViewById(R.id.clLoadingServicioWebCrearForm);
        clLoading.setVisibility(View.VISIBLE);

        lServicioWebForm = root.findViewById(R.id.lSubmitServicioWebForm);
        lServicioWebForm.setVisibility(View.GONE);


        // Referenciación de elementos
        etNombre = root.findViewById(R.id.etServicioWebNombreCrear);
        etDescripcion = root.findViewById(R.id.etServicioWebDescripcionCrear);

        // Botón Creación
        btnCrearServicioWeb = root.findViewById(R.id.btnSericioWebCrear);

        // Configuración de botón de creación
        btnCrearServicioWeb.setOnClickListener(v -> {
            validator.validate();

        });

        // Modificar título en caso de que se esté intentando editar una Base de Datos
        TextView tvTitle = root.findViewById(R.id.tvServicioWebCrearFormTitle);

        if (detalleViewModel != null && detalleViewModel.hasServicioWeb()) {
            tvTitle.setText("Editar servicio auxiliar");
            btnCrearServicioWeb.setText("Actualizar servicio auxiliar");
        }

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Solo cargar datos cuando el formulario sea de edición.
        if (detalleViewModel != null && detalleViewModel.hasServicioWeb()) {
            detalleViewModel.getServicioWeb().observe(getViewLifecycleOwner(), servicioWeb -> {
                // 1 - Información General
                etNombre.setText(servicioWeb.nombre);
                etDescripcion.setText(servicioWeb.descripcion);
                clLoading.setVisibility(View.GONE);
                lServicioWebForm.setVisibility(View.VISIBLE);
            });
        } else {
            clLoading.setVisibility(View.GONE);
            lServicioWebForm.setVisibility(View.VISIBLE);
        }
    }

    private void updateServicioWebList() {
        getActivity().finish();
        getActivity().overridePendingTransition(0, 0);
        getActivity().startActivity(getActivity().getIntent());
        getActivity().overridePendingTransition(0, 0);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }


    @Override
    public void onValidationSucceeded() {
        // Se muestra animación de cargando
        clLoading.setVisibility(View.VISIBLE);
        lServicioWebForm.setVisibility(View.GONE);
        TextView tvLoading = root.findViewById(R.id.tvLoadingServicioWebCrear);
        tvLoading.setText("Guardando datos");

        // Manejo de datos
        Gson gson = new Gson();
        ServicioWeb servicioWeb = new ServicioWeb();

        servicioWeb.nombre = etNombreServicios.getText().toString();
        servicioWeb.descripcion = etDescripcionServicios.getText().toString();

        JSONObject request = new JSONObject();

        try {
            request.put("servicioWeb", new JSONObject(gson.toJson(servicioWeb)));
        } catch (JSONException ignored) {
        }

        if (detalleViewModel != null && detalleViewModel.hasServicioWeb()) {
            servicioWeb.actualizar(detalleViewModel.getServicioWeb().getValue().id, request, response -> {
                clLoading.setVisibility(View.GONE);
                lServicioWebForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateServicioWebList();
            }, error -> {
                clLoading.setVisibility(View.GONE);
                lServicioWebForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al actualizar servicio auxiliar", Toast.LENGTH_SHORT).show();
            });
        } else {
            servicioWeb.crear(request, response -> {
                clLoading.setVisibility(View.GONE);
                lServicioWebForm.setVisibility(View.VISIBLE);

                dismiss();

                // Actualizar listado al finalizar
                updateServicioWebList();
            }, error -> {
                clLoading.setVisibility(View.GONE);
                lServicioWebForm.setVisibility(View.VISIBLE);
                Toast.makeText(root.getContext(), "Error al crear servicio auxiliar", Toast.LENGTH_SHORT).show();
            });
        }
    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        AdapterMaterialSpinner.onErrorChanges(errors);
    }
}