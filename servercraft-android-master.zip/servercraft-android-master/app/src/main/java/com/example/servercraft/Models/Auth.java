package com.example.servercraft.Models;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.servercraft.Utils.ServercraftApplication;
import org.json.JSONObject;
import java.util.Map;

public class Auth extends BaseHTTP {
    // Constants
    private final String ENDPOINT_LOGIN = super.HOST + "/auth/login";
    private final String ENDPOINT_LOGOUT = super.HOST + "/auth/logout";

    // Attributes
    private Token token;
    private Usuario usuario;

    // Constructor
    public Auth () {
        super();
    }

    // Getters & Setters
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Token getToken() {
        return token;
    }

    // HTTP Methods
    public void login (JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        JsonObjectRequest loginRequest = new JsonObjectRequest (Request.Method.POST, ENDPOINT_LOGIN, request, onSuccess, onError);

        queue.add(loginRequest);
    }

    public void logout (Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        JsonObjectRequest logoutRequest = new JsonObjectRequest (Request.Method.POST, ENDPOINT_LOGOUT, null, onSuccess, onError) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                return super.getHeaders();
            }
        };

        queue.add(logoutRequest);
    }
}
