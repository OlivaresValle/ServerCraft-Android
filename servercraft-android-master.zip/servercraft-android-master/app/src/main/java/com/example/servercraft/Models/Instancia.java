package com.example.servercraft.Models;

import androidx.annotation.Nullable;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.servercraft.Utils.ServercraftApplication;
import org.json.JSONObject;
import java.util.Map;
import java.util.Objects;

public class Instancia extends BaseHTTP{
    // Constants
    private final String ENDPOINT_BASE = super.HOST + "/instancia";

    // Attributes
    public int id;
    public int idEstadoInstancia;
    public int idTipoInstancia;

    // Relations
    public TipoInstancia tipoInstancia;
    public EstadoInstancia estadoInstancia;
    public Sistema sistema;
    public Servidor servidor;

    public boolean isFullyVisible = false;

    // Constructor
    public Instancia() {
        super();
    }

    // To String
    @Override
    public String toString() {
        return sistema.nombre + " - " + tipoInstancia.nombre;
    }

    // Equals
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Instancia that = (Instancia) o;

        return id == that.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(ENDPOINT_BASE, id, tipoInstancia.nombre);
    }

    // HTTP Methods
    public void listar (@Nullable JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError, @Nullable int por_pagina, @Nullable int pagina) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_INDEX = ENDPOINT_BASE + "?limit="+ por_pagina +"&page=" + pagina;

        JsonObjectRequest listarInstancias = new JsonObjectRequest(Request.Method.GET, ENDPOINT_INDEX, request, onSuccess, onError){
            @Override
            public Map<String, String> getHeaders() {
                return Instancia.super.headers;
            }
        };

        queue.add(listarInstancias);
    }

    public void crear (JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());

        JsonObjectRequest crearInstancia = new JsonObjectRequest (Request.Method.POST, ENDPOINT_BASE, request, onSuccess, onError){
            @Override
            public Map<String, String> getHeaders() {
                return Instancia.super.headers;
            }
        };

        queue.add(crearInstancia);
    }

    public void actualizar (int idInstancia, JSONObject request, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/" + idInstancia;

        JsonObjectRequest actualizarInstancia = new JsonObjectRequest (Request.Method.PUT, ENDPOINT_DETAIL, request, onSuccess, onError){
            @Override
            public Map<String, String> getHeaders() {
                return Instancia.super.headers;
            }
        };

        queue.add(actualizarInstancia);
    }

    public void eliminar (int idInstancia, Response.Listener<JSONObject> onSuccess, Response.ErrorListener onError) {
        RequestQueue queue = Volley.newRequestQueue(ServercraftApplication.getAppContext());
        final String ENDPOINT_DETAIL = ENDPOINT_BASE + "/" + idInstancia;

        JsonObjectRequest eliminarInstancia = new JsonObjectRequest (Request.Method.DELETE, ENDPOINT_DETAIL, null, onSuccess, onError){
            @Override
            public Map<String, String> getHeaders() {
                return Instancia.super.headers;
            }
        };

        queue.add(eliminarInstancia);
    }
}
