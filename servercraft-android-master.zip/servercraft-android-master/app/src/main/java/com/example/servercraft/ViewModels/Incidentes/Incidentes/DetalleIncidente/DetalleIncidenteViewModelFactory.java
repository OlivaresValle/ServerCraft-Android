package com.example.servercraft.ViewModels.Incidentes.Incidentes.DetalleIncidente;

import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

public class DetalleIncidenteViewModelFactory implements ViewModelProvider.Factory {
    private Integer mIncidenteId;

    public DetalleIncidenteViewModelFactory(@Nullable Integer incidenteId) {
        if (incidenteId != null) {
            this.mIncidenteId = incidenteId;
        }
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        return (T) new DetalleIncidenteViewModel(mIncidenteId);
    }
}
