package com.example.servercraft.UI.UsuariosEquipos.UnidadesNegocio;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.servercraft.Models.Lenguaje;
import com.example.servercraft.Models.UnidadNegocio;
import com.example.servercraft.R;
import com.example.servercraft.UI.LenguajesProgramacion.FormularioLenguajeProgramacionFragment;
import com.example.servercraft.UI.LenguajesProgramacion.LenguajeItemAdapter;
import com.example.servercraft.Utils.UserInfo;
import java.util.ArrayList;

public class UnidadNegocioItemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    LayoutInflater inflater;
    ArrayList<UnidadNegocio> model;
    FragmentManager fragmentManager;
    Context context;
    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;

    public UnidadNegocioItemAdapter(Context context, ArrayList<UnidadNegocio> model, FragmentManager fm) {
        this.inflater = LayoutInflater.from(context);
        this.model = model;
        this.fragmentManager = fm;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = inflater.inflate(R.layout.item_list_simple, parent, false);

            return new UnidadNegocioItemAdapter.ItemViewHolder(view);
        }else{
            View view = inflater.inflate(R.layout.item_list_loading, parent, false);

            return new UnidadNegocioItemAdapter.LoadingViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof UnidadNegocioItemAdapter.ItemViewHolder) {
            populateItemRows((UnidadNegocioItemAdapter.ItemViewHolder) holder, position);
        } else if (holder instanceof UnidadNegocioItemAdapter.LoadingViewHolder) {
            showLoadingView((UnidadNegocioItemAdapter.LoadingViewHolder) holder, position);
        }
    }
    @Override
    public int getItemCount() {
        return model == null ? 0 : model.size();
    }

    @Override
    public int getItemViewType(int position) {
        return model.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ConstraintLayout clItemData, clItemActions;
        TextView nombre;
        Button btnEdit, btnDelete;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);

            nombre = itemView.findViewById(R.id.tvItemTitle);
            clItemData = itemView.findViewById(R.id.clItemData);
            clItemActions = itemView.findViewById(R.id.clItemActions);
            btnEdit = itemView.findViewById(R.id.btnUpdate);
            btnDelete = itemView.findViewById(R.id.btnDelete);

            clItemData.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int adapterPosition = getBindingAdapterPosition();
            UnidadNegocio unidadNegocio = model.get(adapterPosition);
            unidadNegocio.isFullyVisible = !unidadNegocio.isFullyVisible;

            notifyItemChanged(adapterPosition);
        }
    }

    private class LoadingViewHolder extends RecyclerView.ViewHolder {

        public LoadingViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    private void showLoadingView(UnidadNegocioItemAdapter.LoadingViewHolder viewHolder, int position) {
        //ProgressBar would be displayed

    }

    private void populateItemRows(UnidadNegocioItemAdapter.ItemViewHolder holder, int position) {
        // Obtención de objeto
        UnidadNegocio unidadNegocio = model.get(position);

        // Seteo de valores en view holder
        holder.nombre.setText(unidadNegocio.nombre);
        holder.clItemActions.setVisibility(unidadNegocio.isFullyVisible ? View.VISIBLE : View.GONE);

        // Click listeners
        holder.btnEdit.setOnClickListener(v -> {
            FormularioUnidadNegocioFragment formUnidad = FormularioUnidadNegocioFragment.newInstance(unidadNegocio);
            formUnidad.show(fragmentManager, formUnidad.getTag());
        });

        holder.btnDelete.setOnClickListener(v -> {
            AlertDialog.Builder confirmation = new AlertDialog.Builder(context);
            confirmation.setTitle("Advertencia")
                    .setMessage("¿Estás seguro de qué deseas eliminar la unidad de negocio: \""+unidadNegocio.nombre+"\"?")
                    .setCancelable(false)
                    .setPositiveButton("Eliminar", (dialog, which) -> {
                        unidadNegocio.eliminar(unidadNegocio.id, response -> {
                            ((Activity) context).finish();
                            ((Activity) context).overridePendingTransition(0, 0);
                            ((Activity) context).startActivity(((Activity) context).getIntent());
                            ((Activity) context).overridePendingTransition(0, 0);
                        }, error -> {
                            Toast.makeText(context, "Error al eliminar unidad de negocio.", Toast.LENGTH_SHORT).show();
                        });
                    }).setNegativeButton("Cancelar", (dialog, which) -> {
                dialog.dismiss();
            });

            confirmation.create().show();
        });
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ConstraintLayout clItemData, clItemActions;
        TextView nombre;
        Button btnEdit, btnDelete;
        ImageView ivChevronDown;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

        int userRol = new UserInfo().getUserRol();

            nombre = itemView.findViewById(R.id.tvItemTitle);
            clItemData = itemView.findViewById(R.id.clItemData);
            clItemActions = itemView.findViewById(R.id.clItemActions);
            btnEdit = itemView.findViewById(R.id.btnUpdate);
            btnDelete = itemView.findViewById(R.id.btnDelete);
            ivChevronDown = itemView.findViewById(R.id.ivChevronDown);

            if (userRol == 2 || userRol == 3) {
                btnEdit.setVisibility(View.GONE);
                btnDelete.setVisibility(View.GONE);
                ivChevronDown.setVisibility(View.GONE);
            }

            clItemData.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int adapterPosition = getBindingAdapterPosition();
            UnidadNegocio unidadNegocio = model.get(adapterPosition);
            unidadNegocio.isFullyVisible = !unidadNegocio.isFullyVisible;

            notifyItemChanged(adapterPosition);
        }
    }
}
