package com.example.servercraft.Models;

public class EstadisticaCliente {
    // Attributes
    public int mes;
    public int clientes;

    // Constructor
    public EstadisticaCliente() {
        super();
    }

    // To String
    @Override
    public String toString() {
        return "mes " + mes + " clientes " + clientes;
    }
}
