package com.example.servercraft.ViewModels.ServidoresRacksSalas.Servidores.DetalleServidor;

import android.util.Log;
import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.servercraft.Models.Servidor;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.json.JSONException;
import org.json.JSONObject;

public class DetalleServidorViewModel extends ViewModel {
    private MutableLiveData<Integer> serverId;
    private MutableLiveData<Servidor> mServer;

    // Constructor
    public DetalleServidorViewModel(@Nullable Integer idServidor) {
        serverId = new MutableLiveData<>();
        mServer = new MutableLiveData<>();

        if (idServidor != null) {
            serverId.setValue(idServidor);
            loadHTTPServer();
        }
    }

    // Getters
    public MutableLiveData<Servidor> getServer() {
        return mServer;
    }

    public Integer getServerId() {
        return serverId.getValue();
    }

    public boolean hasServer() {
        return serverId.getValue() != null;
    }

    // Setters
    private void loadHTTPServer() {
        Servidor servidor = new Servidor();

        servidor.obtener(serverId.getValue(), response -> {
            try {
                JSONObject httpServer = response.getJSONObject("servidor");
                Servidor objectServer = mapServerIntoObject(httpServer);

                mServer.setValue(objectServer);
            } catch (JSONException e) {
            }
        }, error -> Log.d("Error de ", error.toString()));
    }

    private Servidor mapServerIntoObject(JSONObject httpServer) {
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

        Servidor server = gson.fromJson(httpServer.toString(), Servidor.class);

        return server;
    }
}
