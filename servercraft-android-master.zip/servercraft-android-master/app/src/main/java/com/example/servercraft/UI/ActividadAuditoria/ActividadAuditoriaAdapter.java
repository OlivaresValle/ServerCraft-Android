package com.example.servercraft.UI.ActividadAuditoria;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.servercraft.Models.ActividadAuditoria;
import com.example.servercraft.R;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class ActividadAuditoriaAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;
    LayoutInflater inflater;
    ArrayList<ActividadAuditoria> model;
    FragmentManager fragmentManager;
    Context context;

    public ActividadAuditoriaAdapter(Context context, ArrayList<ActividadAuditoria> model, FragmentManager fm) {
        this.inflater = LayoutInflater.from(context);
        this.model = model;
        this.fragmentManager = fm;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = inflater.inflate(R.layout.item_list_general, parent, false);

            return new ItemViewHolder(view);
        } else {
            View view = inflater.inflate(R.layout.item_list_loading, parent, false);

            return new LoadingViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof ItemViewHolder) {
            populateItemRows((ItemViewHolder) holder, position);
        } else if (holder instanceof LoadingViewHolder) {
            showLoadingView((LoadingViewHolder) holder, position);
        }
    }

    @Override
    public int getItemViewType(int position) {
        return model.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }

    @Override
    public int getItemCount() {
        return model == null ? 0 : model.size();
    }

    private class ItemViewHolder extends RecyclerView.ViewHolder {
        ConstraintLayout clItemData, clItemActions;
        ImageView ivChevronDown;
        TextView nombre, hora;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);

            nombre = itemView.findViewById(R.id.tvItemTitle);
            hora = itemView.findViewById(R.id.tvItemDescription);
            clItemData = itemView.findViewById(R.id.clItemData);
            clItemActions = itemView.findViewById(R.id.clItemActions);
            ivChevronDown = itemView.findViewById(R.id.ivChevronDown);
        }
    }

    private class LoadingViewHolder extends RecyclerView.ViewHolder {

        public LoadingViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    private void showLoadingView(LoadingViewHolder viewHolder, int position) {
        //ProgressBar would be displayed
    }

    private void populateItemRows(ItemViewHolder holder, int position) {
        //Obtención del Objecto
        ActividadAuditoria actividadAuditoria = model.get(position);

        //Seteo de Valores en ViewHolder
        holder.nombre.setText(actividadAuditoria.detalleActividad);

        //Seteo de Hora y Fecha
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yy HH:mm:ss");
        String timeStamp = ZonedDateTime.parse(actividadAuditoria.fechaHora).format(formatter);
        holder.hora.setText(timeStamp);

        holder.clItemActions.setVisibility(View.GONE);
        holder.ivChevronDown.setVisibility(View.GONE);
    }
}
