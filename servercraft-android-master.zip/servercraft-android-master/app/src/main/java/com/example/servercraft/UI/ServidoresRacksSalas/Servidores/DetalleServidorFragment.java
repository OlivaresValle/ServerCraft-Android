package com.example.servercraft.UI.ServidoresRacksSalas.Servidores;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import com.example.servercraft.ViewModels.ServidoresRacksSalas.Servidores.DetalleServidor.DetalleServidorViewModel;
import com.example.servercraft.ViewModels.ServidoresRacksSalas.Servidores.DetalleServidor.DetalleServidorViewModelFactory;
import com.example.servercraft.databinding.FragmentDetalleServidorBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class DetalleServidorFragment extends BottomSheetDialogFragment {
    private static final String ARG_ID_SERVIDOR = "id_servidor";
    private DetalleServidorViewModel detalleViewModel;
    private FragmentDetalleServidorBinding binding;

    public static DetalleServidorFragment newInstance(int idServidor) {
        DetalleServidorFragment fragment = new DetalleServidorFragment();
        Bundle bundle = new Bundle();

        bundle.putInt(ARG_ID_SERVIDOR, idServidor);
        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int serverId = 1;

        if (getArguments() != null) {
            serverId = getArguments().getInt(ARG_ID_SERVIDOR);
        }

        detalleViewModel = new ViewModelProvider(this, new DetalleServidorViewModelFactory(serverId)).get(DetalleServidorViewModel.class);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Context Management
        binding = FragmentDetalleServidorBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Observador de consulta HTTP
        detalleViewModel.getServer().observe(getViewLifecycleOwner(), servidor -> {
            // Cargar datos cuando estén disponibles
            // 1 - Información general
            binding.tvServerTitle.setText(servidor.nombre);
            binding.tvDetalleTipoServidor.setText(servidor.tipoServidor.nombre);
            binding.tvIp.setText(servidor.ip);
            binding.tvDetalleSistemaOperativo.setText(servidor.sistemaOperativo.nombre);
            binding.tvDetalleBaseDatos.setText(servidor.baseDatos == null ? "No aplica" : servidor.baseDatos.nombre);
            binding.tvDetalleAlmacenamiento.setText(servidor.disco + " GB");
            binding.tvDetalleMemoria.setText(servidor.memoria + " GB");

            // 2 - Credenciales de acceso
            binding.tvUser.setText(servidor.usuarioIngreso == null ? "No posees permisos" : servidor.usuarioIngreso);
            binding.tvPassword.setText(servidor.contrasenaIngreso == null ? "No posees permisos" : servidor.contrasenaIngreso);

            // 3 - Contacto mantención
            binding.tvNombreMantencion.setText(servidor.nombreContactoMantencion);
            binding.tvEmailMantencion.setText(servidor.emailContactoMantencion);
            binding.tvPhoneMantencion.setText(servidor.telefonoContactoMantencion);
            binding.tvPoseeGarantia.setText(servidor.poseeGarantia ? "Si" : "No");

            // 4 - Ubicación Física
            binding.tvRDSala.setText(servidor.rack.nombre);
            binding.tvSala.setText(servidor.rack.sala.nombre);
            binding.tvRegion.setText(servidor.rack.sala.region.nombre);
            binding.tvPais.setText(servidor.rack.sala.region.pais.nombre);

            // Ocultar vista de "cargando..."
            binding.clLoadingRack.setVisibility(View.GONE);
            binding.llData.setVisibility(View.VISIBLE);
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}